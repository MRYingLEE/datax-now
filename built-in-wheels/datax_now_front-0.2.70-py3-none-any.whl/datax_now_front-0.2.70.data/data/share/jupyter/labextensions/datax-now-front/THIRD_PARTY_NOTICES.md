Third-Party Notices

This product includes dependencies and build tooling that are licensed under their own open-source licenses. In some generated assets (for example, compiled JavaScript and CSS bundles), you may find embedded license headers from those third-party components (e.g., MIT, Apache). These notices are preserved as required by the respective licenses.

Such third-party notices do not alter the overall license of this product, which is governed by the accompanying commercial LICENSE.

For full details, refer to the licenses included with the dependencies in node_modules and the source repositories of those projects.
