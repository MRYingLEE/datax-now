"""jupyterlite-xeus-x — kernel bundle for JupyterLite."""
__version__ = '20260916.1470.0'
