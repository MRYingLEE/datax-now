import type { JSONObject } from '@lumino/coreutils';
export type DisplayOptions = {
    display_id?: string;
    update?: boolean;
    metadata?: JSONObject;
};
export declare class DisplayAdapter {
    private static getGlobal;
    private static getInterpreter;
    private static getMarkdownFn;
    private static getDisplayDataFns;
    static data(data: Record<string, unknown>, metadata?: JSONObject, transient?: JSONObject, update?: boolean): boolean;
    static markdown(text: string, options?: DisplayOptions): void;
    static details(summary: string, explanation?: string, closed?: boolean, displayId?: string): void;
    static updateDetails(summary: string, explanation?: string, closed?: boolean, displayId?: string): void;
}
//# sourceMappingURL=display-adapter.d.ts.map