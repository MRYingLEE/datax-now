import { compressOutput, wrapCode, wrapCodeForDisplay, wrapJSON, wrapSection, extractCode, } from './output-processor.js';
import { DisplayAdapter } from './display-adapter.js';
import { DisplayManager } from './display-manager.js';
import { retryUntil } from './retry.js';
import { CONSTANTS, LanguageType_Lowercase, deFencedCode, extractFencedBlocks, resolveWindow } from './utilities.js';
import { resolveMetadata as resolveMetadataShared } from './cell-ai_agents-context.js';
import { createLogger } from './logger.js';
import { getLLM, getActiveProviderConfig, getLLMRequestOptions, isNonEmptyString, } from './llm-factory.js';
import { render, renderKernel } from './prompts/template-engine.js';
import { jsonSchema } from 'ai';
import { buildSkillAwarePrompt } from './agent-skills.js';
import { getErrorStatusInfo, normalizeAIError, } from './ai-error-utils.js';
import { createNativeObjectAgent, createNativeTextAgent, } from './native-agent.js';
import packageJson from './package.json' with { type: 'json' };
/**
 * Combine multiple AbortSignals into one that aborts when any of them fires.
 * Falls back to a manual EventListener approach when `AbortSignal.any` is
 * not yet available in the runtime (pre-Chrome 116 / pre-Node 20.3).
 */
function combineAbortSignals(...signals) {
    const defined = signals.filter((s) => s !== undefined);
    if (defined.length === 0)
        return undefined;
    if (defined.length === 1)
        return defined[0];
    if (typeof AbortSignal.any === 'function') {
        return AbortSignal.any(defined);
    }
    // Manual fallback
    const ctrl = new AbortController();
    for (const sig of defined) {
        if (sig.aborted) {
            ctrl.abort(sig.reason);
            break;
        }
        sig.addEventListener('abort', () => ctrl.abort(sig.reason), { once: true });
    }
    return ctrl.signal;
}
function toAbortLikeError(signal) {
    const reason = signal?.reason;
    if (reason instanceof Error) {
        return reason;
    }
    const err = new Error(typeof reason === 'string' && reason.length > 0 ? reason : 'Aborted');
    const reasonName = reason?.name;
    err.name = typeof reasonName === 'string' && reasonName.length > 0 ? reasonName : 'AbortError';
    return err;
}
function throwIfAborted(signal) {
    if (signal?.aborted) {
        throw toAbortLikeError(signal);
    }
}
async function nextWithAbort(iterator, signal) {
    throwIfAborted(signal);
    if (!signal) {
        return iterator.next();
    }
    return await new Promise((resolve, reject) => {
        const onAbort = () => {
            signal.removeEventListener('abort', onAbort);
            _debug('Stream abort observed locally');
            void iterator.return?.();
            reject(toAbortLikeError(signal));
        };
        signal.addEventListener('abort', onAbort, { once: true });
        iterator.next().then((value) => {
            signal.removeEventListener('abort', onAbort);
            resolve(value);
        }, (error) => {
            signal.removeEventListener('abort', onAbort);
            reject(error);
        });
    });
}
async function collectAgentTextWithStreamingFallback(agent, promptOrMessages, signal, onText) {
    const callOptions = {
        ...(Array.isArray(promptOrMessages)
            ? { messages: promptOrMessages }
            : { prompt: promptOrMessages }),
        ...(signal ? { abortSignal: signal } : {}),
    };
    const result = await agent.stream(callOptions);
    let fullText = '';
    const iterator = result.textStream[Symbol.asyncIterator]();
    try {
        while (true) {
            const next = await nextWithAbort(iterator, signal);
            if (next.done) {
                break;
            }
            throwIfAborted(signal);
            fullText += next.value;
            if (onText) {
                await onText(fullText);
            }
        }
    }
    finally {
        await iterator.return?.();
    }
    if (fullText.length > 0 || signal?.aborted) {
        return { text: fullText, usedFallback: false };
    }
    _info('LLM stream returned no text; retrying once with non-streaming generate()');
    const generated = await agent.generate(callOptions);
    return {
        text: typeof generated.text === 'string' ? generated.text : '',
        usedFallback: true,
    };
}
/**
 * Display an inline anywidget "Stop" button in the cell output.
 *
 * Returns an `AbortController` whose signal is aborted the moment the user
 * clicks the button (frontend → kernel comm round-trip).
 * Call `cleanup()` after the operation finishes to hide the button.
 *
 * @internal
/** Stringified error info for debug objects. */
function _errorInfo(error) {
    return getErrorStatusInfo(error);
}
// Simple runtime marker to verify which bundle version is loaded in the browser.
// Intentionally does not include any secrets.
const AI_AGENTS_BUNDLE_MARKER = 'ai_agents-bundle-marker:2026-07-11-cache-debug-v2';
const AI_AGENTS_REPO_VERSION = packageJson.version;
const { debug: _debug, info: _info } = createLogger('[AI_Agents]');
globalThis.__AI_AGENTS_BUNDLE_MARKER__ = AI_AGENTS_BUNDLE_MARKER;
globalThis.__AI_AGENTS_REPO_VERSION__ = AI_AGENTS_REPO_VERSION;
_info(`Initialized repo version ${AI_AGENTS_REPO_VERSION}`);
function getAIAgentsLLMDebug() {
    const g = globalThis;
    const existing = g.__AI_AGENTS_LLM_DEBUG__;
    if (existing && typeof existing === 'object') {
        return existing;
    }
    const init = { marker: AI_AGENTS_BUNDLE_MARKER, provider: 'none' };
    g.__AI_AGENTS_LLM_DEBUG__ = init;
    return init;
}
// isNonEmptyString is imported from llm-factory.ts
export function getAIAgentsConfigSummary() {
    const dbg = getAIAgentsLLMDebug();
    const config = getActiveProviderConfig();
    return {
        marker: AI_AGENTS_BUNDLE_MARKER,
        hasJupyterAI: !!config,
        provider: dbg.provider,
        modelName: config?.model ?? dbg.modelName,
        baseURL: config?.baseURL ?? dbg.baseURL,
        providerType: config?.provider,
        hasApiKey: isNonEmptyString(config?.apiKey),
    };
}
/**
 * Create LLM instance from the active `window.jupyter_ai` provider.
 * @param temperature Optional temperature override.
 */
function createLLMFromConfig(temperature, model) {
    const llm = getLLM(temperature, model);
    if (!llm) {
        console.error('[AI_Agents] No active provider configured in window.jupyter_ai');
        return null;
    }
    const dbg = getAIAgentsLLMDebug();
    const config = getActiveProviderConfig();
    if (config) {
        dbg.provider = 'jupyter_ai';
        dbg.modelName = config.model;
        dbg.baseURL = config.baseURL;
        globalThis.__AI_AGENTS_LLM_DEBUG__ = dbg;
    }
    return llm;
}
const DATAFRAME_PROMPT_SAMPLE_ROWS = 3;
function isDataframeLikeForPrompt(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value)
        && value.__xeus_x_dataframe__ === true;
}
function parseCsvLine(line) {
    const values = [];
    let current = '';
    let inQuotes = false;
    for (let index = 0; index < line.length; index += 1) {
        const char = line[index];
        if (char === '"') {
            if (inQuotes && line[index + 1] === '"') {
                current += '"';
                index += 1;
            }
            else {
                inQuotes = !inQuotes;
            }
            continue;
        }
        if (char === ',' && !inQuotes) {
            values.push(current);
            current = '';
            continue;
        }
        current += char;
    }
    values.push(current);
    return values;
}
function buildDataframeProfileForPrompt(value) {
    const profile = {
        __xeus_x_dataframe_profile__: true,
    };
    if (typeof value.format === 'string' && value.format.trim().length > 0) {
        profile.format = value.format;
    }
    const csv = typeof value.csv === 'string' ? value.csv : '';
    const lines = csv
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter((line) => line.length > 0);
    if (lines.length > 0) {
        const columns = parseCsvLine(lines[0]);
        if (columns.length > 0) {
            profile.columns = columns;
            profile.ncols = columns.length;
        }
        const sampleRows = lines.slice(1, 1 + DATAFRAME_PROMPT_SAMPLE_ROWS).map((line) => {
            const values = parseCsvLine(line);
            return Object.fromEntries(values.map((cell, index) => [columns[index] || `column_${index + 1}`, cell]));
        });
        if (sampleRows.length > 0) {
            profile.sample_rows = sampleRows;
        }
        if (typeof value.nrows !== 'number') {
            profile.nrows = Math.max(lines.length - 1, 0);
        }
    }
    if (typeof value.nrows === 'number' && Number.isFinite(value.nrows)) {
        profile.nrows = value.nrows;
    }
    return profile;
}
function sanitizeContextValueForPrompt(value) {
    if (Array.isArray(value)) {
        return value.map((item) => sanitizeContextValueForPrompt(item));
    }
    if (!value || typeof value !== 'object') {
        return value;
    }
    if (isDataframeLikeForPrompt(value)) {
        return buildDataframeProfileForPrompt(value);
    }
    return Object.fromEntries(Object.entries(value).map(([key, entryValue]) => [key, sanitizeContextValueForPrompt(entryValue)]));
}
function stringifyContextForPrompt(context) {
    if (typeof context === 'string') {
        const trimmed = context.trim();
        if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
            try {
                return JSON.stringify(sanitizeContextValueForPrompt(JSON.parse(trimmed)), null, 2);
            }
            catch {
                return context;
            }
        }
        return context;
    }
    return JSON.stringify(sanitizeContextValueForPrompt(context), null, 2);
}
function sanitizeRequirementForPrompt(requirement) {
    return requirement.replace(/JSON\.parse\(("(?:\\.|[^"\\])*")\)/g, (match, stringLiteral) => {
        try {
            const jsonText = JSON.parse(stringLiteral);
            const parsed = JSON.parse(jsonText
                .replace(/\r/g, '\\r')
                .replace(/\n/g, '\\n')
                .replace(/\t/g, '\\t'));
            const sanitized = sanitizeContextValueForPrompt(parsed);
            if (JSON.stringify(parsed) === JSON.stringify(sanitized)) {
                return match;
            }
            return `JSON.parse(${JSON.stringify(JSON.stringify(sanitized))})`;
        }
        catch {
            return match;
        }
    });
}
// NOTE (WASM / no-extra-installs):
// The xeus-x runtime evaluates the injected bundle as a plain script in a
// worker environment. The Vercel AI SDK is bundled via webpack; avoid
// runtime `require(...)` calls that would break kernel startup.
/**
 * Generate a unique session ID - standalone utility function
 */
export function generateSessionId(prefix) {
    const g = globalThis;
    const cryptoObj = g?.crypto;
    // Prefer standards-based UUID when available.
    if (cryptoObj?.randomUUID) {
        return prefix + '_' + cryptoObj.randomUUID().replace(/-/g, '_');
    }
    // Fallback: use secure random values when possible.
    if (cryptoObj?.getRandomValues) {
        const bytes = new Uint8Array(16);
        cryptoObj.getRandomValues(bytes);
        let hex = '';
        for (const b of bytes) {
            hex += b.toString(16).padStart(2, '0');
        }
        return `${prefix}_${hex}`;
    }
    // Last resort fallback (non-cryptographic).
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}
/**
 * Ask AI a question - standalone function
 * @param question The question to ask
 * @param streaming Whether to stream the response
 * @param displayId Display ID for output updates
 * @param metadata Optional metadata including lastExecuteIO for context
 * @param systemPromptOverride Optional override for the default ask system prompt
 */
export async function askAI(question, streaming = true, displayId = '', metadata, abortSignal, timeoutMs, showStopButton = true, systemPromptOverride) {
    // Create an inline stop-button widget so the user can cancel mid-stream.
    let _stopCleanup;
    let _stopSignal;
    let localUpdate = true;
    if (displayId.length === 0) {
        displayId = generateSessionId('ask');
        localUpdate = false;
    }
    DisplayAdapter.markdown('Thinking...', {
        display_id: displayId,
        update: localUpdate,
    });
    if (showStopButton) {
        try {
            const { controller, cleanup } = await DisplayManager.createStopButton();
            _stopCleanup = cleanup;
            _stopSignal = controller.signal;
        }
        catch (err) {
            globalThis?._console?.warn('[AI_Agents] DisplayManager.createStopButton failed:', err);
        }
    }
    const _abortSignal = combineAbortSignals(abortSignal, _stopSignal, timeoutMs !== undefined ? AbortSignal.timeout(timeoutMs) : undefined);
    try {
        // Check if jupyter_ai provider is available
        if (!getActiveProviderConfig()) {
            const errorMsg = 'AI Engine is not available. Please ensure AI services are properly configured.';
            DisplayAdapter.markdown(errorMsg, {
                display_id: displayId,
                update: true,
            });
            return errorMsg;
        }
        const defaultConvention = resolveWindow()?.dataxNow?.ai?.getPromptConvention?.() || '';
        const template = systemPromptOverride ?? await render('system/ask', { defaultConvention });
        // Create LLM from the active window.jupyter_ai provider.
        const llm = createLLMFromConfig();
        if (!llm) {
            const errorMsg = 'AI Language Model is not available. Please check AI service configuration.';
            DisplayAdapter.markdown(errorMsg, {
                display_id: displayId,
                update: true,
            });
            return errorMsg;
        }
        const runStream = async (label) => {
            if (label) {
                DisplayAdapter.markdown(label, {
                    display_id: displayId,
                    update: true,
                });
            }
            const requestOptions = getLLMRequestOptions();
            const builtPrompt = buildSkillAwarePrompt(template, question);
            const agent = createNativeTextAgent({
                model: llm,
                instructions: builtPrompt.instructions,
                ...(requestOptions.temperature !== undefined ? { temperature: requestOptions.temperature } : {}),
                ...(requestOptions.maxOutputTokens !== undefined
                    ? { maxOutputTokens: requestOptions.maxOutputTokens }
                    : {}),
            });
            if (streaming) {
                const { text: fulltext } = await collectAgentTextWithStreamingFallback(agent, builtPrompt.prompt, _abortSignal, async (fulltext) => {
                    if (fulltext.length > 1) {
                        DisplayAdapter.markdown(fulltext, {
                            display_id: displayId,
                            update: true,
                        });
                    }
                });
                return fulltext;
            }
            else {
                const result = await agent.generate({
                    prompt: builtPrompt.prompt,
                    ...(_abortSignal ? { abortSignal: _abortSignal } : {}),
                });
                const fulltext = result.text;
                DisplayAdapter.markdown(fulltext, {
                    display_id: displayId,
                    update: true,
                });
                return fulltext;
            }
        };
        return await runStream();
    }
    catch (error) {
        const dbg = getAIAgentsLLMDebug();
        dbg.lastError = _errorInfo(error);
        const normalizedError = normalizeAIError(error);
        const errName = normalizedError.ename;
        if (errName === 'AbortError') {
            const msg = 'AI request was cancelled.';
            DisplayAdapter.markdown(msg, { display_id: displayId, update: true });
            return msg;
        }
        if (errName === 'TimeoutError') {
            const msg = `AI request timed out after ${timeoutMs ?? 0} ms.`;
            DisplayAdapter.markdown(msg, { display_id: displayId, update: true });
            return msg;
        }
        const message = normalizedError.evalue || 'Unknown error';
        const baseURL = dbg.baseURL || '';
        const model = dbg.modelName || '';
        let hint = '';
        if (_errorInfo(error).status === 404) {
            hint =
                '\n\nHint: the model or endpoint may be misconfigured.' +
                    (model ? ` Current model: ${model}.` : '') +
                    (baseURL ? ` Base URL: ${baseURL}.` : '');
        }
        const errorMsg = `AI request failed: ${message}${hint}`;
        DisplayAdapter.markdown(errorMsg, {
            display_id: displayId,
            update: true,
        });
        return errorMsg;
    }
    finally {
        if (_stopCleanup) {
            _stopCleanup().catch(() => { });
        }
    }
}
/**
 * Get language configuration for script type - standalone utility function
 */
export function getLanguageConfig(scriptType) {
    switch (scriptType) {
        case ScriptType.JsOnly:
            return {
                wrapLanguage: 'javascript',
                suggestedLanguage: 'pure javascript/markdown',
            };
        case ScriptType.PyOnly:
            return {
                wrapLanguage: 'python',
                suggestedLanguage: 'pure python/markdown',
            };
        case ScriptType.ROnly:
            return {
                wrapLanguage: 'r',
                suggestedLanguage: 'pure R/markdown',
            };
        case ScriptType.PyJS:
            return {
                wrapLanguage: '',
                suggestedLanguage: 'pure Python/JavaScript/markdown, or a mix of all',
            };
        case ScriptType.PyR:
            return {
                wrapLanguage: '',
                suggestedLanguage: 'pure Python/R/markdown, or a mix of both',
            };
        case ScriptType.PyRJS:
            return {
                wrapLanguage: '',
                suggestedLanguage: 'pure Python/R/JavaScript/markdown, or a mix of all',
            };
    }
}
export function usesDetailsProgressDisplay(purpose) {
    return purpose === Purpose.AutoSuggest || purpose === Purpose.AutoImplement;
}
export function buildInProgressCodeMarkdown(scriptType, fullText) {
    if (fullText.length === 0) {
        return '';
    }
    const { wrapLanguage } = getLanguageConfig(scriptType);
    return wrapLanguage ? wrapCodeForDisplay(fullText, wrapLanguage, false) : fullText;
}
function shouldShowStopButtonTryLabel(purpose) {
    return purpose !== Purpose.AutoSuggest && purpose !== Purpose.AutoImplement;
}
function formatStopButtonLabel(attempt, purpose) {
    if (!shouldShowStopButtonTryLabel(purpose)) {
        return '⏹ Stop';
    }
    return `⏹ Stop (try ${String(Math.max(1, attempt))})`;
}
/**
 * Get kernel configuration for script type - standalone utility function.
 * Now async because kernel context is loaded from Handlebars templates at runtime.
 *
 * @param scriptType     Target script type
 * @param disallowedPackages  Legacy: Python-only disallowed packages (Set). Preserved for
 *                            backward compatibility. When `packageConstraints` is supplied
 *                            this parameter is ignored.
 * @param packageConstraints  Full required/optional/prohibited package constraints for all
 *                            languages. Supersedes `disallowedPackages` when present.
 */
export async function getKernelConfig(scriptType, disallowedPackages = new Set(), packageConstraints) {
    let kernel = '';
    let disallowedPackagesStr = '';
    try {
        const kernelTemplateMap = {
            [ScriptType.JsOnly]: 'kernel/javascript',
            [ScriptType.PyOnly]: 'kernel/python',
            [ScriptType.ROnly]: 'kernel/r',
            [ScriptType.PyJS]: 'kernel/python_javascript',
            [ScriptType.PyR]: 'kernel/python_r',
            [ScriptType.PyRJS]: 'kernel/python_r_javascript',
        };
        const templateName = kernelTemplateMap[scriptType];
        if (templateName) {
            kernel = await renderKernel(templateName);
        }
        if (packageConstraints) {
            // Full constraints provided — build a language-agnostic section for all
            // three lists and all relevant script types.
            const required = (packageConstraints.required ?? []).filter(Boolean);
            const optional = (packageConstraints.optional ?? []).filter(Boolean);
            const prohibited = (packageConstraints.prohibited ?? []).filter(Boolean);
            const lines = [];
            if (required.length > 0)
                lines.push(`- **MUST use** (required imports): ${required.join(', ')}`);
            if (optional.length > 0)
                lines.push(`- **Prefer** (optional): ${optional.join(', ')}`);
            if (prohibited.length > 0)
                lines.push(`- **MUST NOT use** (prohibited imports): ${prohibited.join(', ')}`);
            if (lines.length > 0) {
                disallowedPackagesStr = `## Package Constraints\n${lines.join('\n')}`;
            }
        }
        else {
            // Legacy path: Python-only disallowed set
            const hasPython = scriptType === ScriptType.PyOnly ||
                scriptType === ScriptType.PyJS ||
                scriptType === ScriptType.PyR ||
                scriptType === ScriptType.PyRJS;
            if (hasPython && disallowedPackages.size > 0) {
                disallowedPackagesStr = `# Disallowed Python packages: [${Array.from(disallowedPackages).join(',')}]`;
            }
        }
    }
    catch (error) {
        const g = globalThis;
        g._console?.error('[AI_Agents] Error in getKernelConfig:', error);
    }
    return { kernel, disallowedPackagesStr };
}
// ---------------------------------------------------------------------------
// Helpers: extract code blocks / prose from markdown
// ---------------------------------------------------------------------------
function normalizeStructuredCodeBlockLanguage(language) {
    const lower = String(language ?? '').trim().toLowerCase();
    if (lower === 'python' || lower === 'py') {
        return 'python';
    }
    if (lower === 'javascript' || lower === 'js' || lower === 'typescript' || lower === 'ts' || lower === 'tsx') {
        return 'javascript';
    }
    if (lower === 'r' || lower === 'rlang') {
        return 'r';
    }
    return 'unknown';
}
function normalizeSmartAskCodeBlock(block) {
    return {
        language: normalizeStructuredCodeBlockLanguage(block?.language ?? ''),
        code: typeof block?.code === 'string' ? deFencedCode(block.code, block.language ?? '') : '',
    };
}
function normalizeStructuredResponse(response) {
    return {
        answer: typeof response.answer === 'string' ? response.answer.trim() : '',
        codeBlocks: Array.isArray(response.codeBlocks)
            ? response.codeBlocks.map((block) => normalizeSmartAskCodeBlock(block))
            : [],
        shouldExecute: response.shouldExecute === true,
        executionReason: typeof response.executionReason === 'string' ? response.executionReason.trim() : '',
    };
}
function structuredResponseToRawMarkdown(response) {
    const sections = [];
    if (response.answer.length > 0) {
        sections.push(response.answer);
    }
    for (const block of response.codeBlocks) {
        const fenceLanguage = block.language === 'unknown' ? '' : block.language;
        sections.push(`\`\`\`${fenceLanguage}\n${block.code}\n\`\`\``.trim());
    }
    return sections.join('\n\n').trim();
}
function structuredPreviewFromPartialResponse(response) {
    const answer = typeof response?.answer === 'string' ? response.answer.trim() : '';
    const codeBlocks = Array.isArray(response?.codeBlocks)
        ? response.codeBlocks
            .map((block) => normalizeSmartAskCodeBlock(block))
            .filter((block) => block.code.trim().length > 0)
        : [];
    return structuredResponseToRawMarkdown({
        answer,
        codeBlocks,
        shouldExecute: response?.shouldExecute === true,
        executionReason: typeof response?.executionReason === 'string' ? response.executionReason : '',
    });
}
/**
 * Extract all fenced code blocks from a markdown string.
 * Returns them in order of appearance with a normalised language tag.
 * Delegates to the shared extractFencedBlocks parser (utilities.ts) so that
 * cache lookups and smartAsk both parse identically.
 */
export function extractCodeBlocks(markdown) {
    return extractFencedBlocks(markdown).map(({ language: rawLang, code }) => ({
        language: normalizeStructuredCodeBlockLanguage(rawLang),
        code,
    }));
}
/**
 * Strip fenced code blocks from markdown, returning prose only.
 * Preserves paragraph spacing.
 */
export function extractProse(markdown) {
    // Remove complete fenced blocks (``` or ~~~) except mermaid
    let prose = markdown.replace(/^[ \t]*(```|~~~)[ \t]*([a-zA-Z0-9_+-]*)[ \t]*\n([\s\S]*?)(?:\n[ \t]*\1[ \t]*(?:\n|(?![^]))|(?![^]))/gm, (match, fence, lang, code) => {
        if (lang && lang.toLowerCase() === 'mermaid') {
            return match; // Do not remove mermaid
        }
        return '';
    });
    // Collapse runs of 3+ blank lines into 2
    prose = prose.replace(/\n{3,}/g, '\n\n');
    return prose.trim();
}
/**
 * Unified AI interaction that lets the model decide whether to respond with
 * prose, code, or both.  The caller receives a structured result and can
 * optionally execute any generated code blocks.
 *
 * @param question  Natural-language question or instruction
 * @param options   See {@link ISmartAskOptions}
 * @returns         Structured result — see {@link ISmartAskResult}
 *
 * @example
 * ```typescript
 * // Prose-only answer (AI decides no code is needed)
 * const r1 = await smartAsk('What is a DataFrame?');
 * console.log(r1.answer);     // explanation text
 * console.log(r1.hasCode);    // false
 *
 * // Code included (AI decides code helps)
 * const r2 = await smartAsk('Sort a list in Python');
 * console.log(r2.codeBlocks); // [{ language: 'python', code: '...' }]
 *
 * // Auto-execute the returned code blocks
 * const r3 = await smartAsk('Create a bar chart of sales data', {
 *   execute: true,
 *   preferredLanguage: 'python',
 *   context: { sales: [10, 20, 30] },
 * });
 * // r3.executed === true, r3.codeBlocks[0].executionResult populated
 * ```
 */
export async function smartAsk(question, options = {}) {
    const { streaming = true, displayId: providedDisplayId, metadata, preferredLanguage, context, system_prompt, executionPolicy, execute, maxRetries = 3, model, _skipExecution = false, abortSignal: callerSignal, timeoutMs, showStopButton = true, } = options;
    // Create an internal stop-button widget and combine its signal with any
    // caller-supplied signal and the optional timeout.
    let _stopCleanup;
    let _stopSignal;
    const resolvedExecutionPolicy = executionPolicy ??
        (typeof execute === 'boolean' ? (execute ? 'always' : 'never') : 'ai');
    const policyFromLegacyExecute = executionPolicy === undefined && typeof execute === 'boolean';
    const displayId = providedDisplayId || generateSessionId('smart');
    const localUpdate = !!providedDisplayId;
    DisplayAdapter.markdown('Thinking...', {
        display_id: displayId,
        update: localUpdate,
    });
    if (showStopButton) {
        try {
            const { controller, cleanup } = await DisplayManager.createStopButton();
            _stopCleanup = cleanup;
            _stopSignal = controller.signal;
        }
        catch (err) {
            // Non-fatal: if widget creation fails, continue without stop button.
            globalThis?._console?.warn('[AI_Agents] DisplayManager.createStopButton failed:', err);
        }
    }
    // Build a combined AbortSignal that fires when any source requests stop.
    const abortSignal = combineAbortSignals(callerSignal, _stopSignal, timeoutMs !== undefined ? AbortSignal.timeout(timeoutMs) : undefined);
    // Helper: build an error result
    function resolveDecisionSource() {
        if (policyFromLegacyExecute)
            return 'legacy-execute';
        if (resolvedExecutionPolicy === 'always')
            return 'policy-always';
        if (resolvedExecutionPolicy === 'never')
            return 'policy-never';
        return 'ai';
    }
    const errorResult = (msg, ename = 'SmartAskError') => ({
        status: 'error',
        rawResponse: '',
        answer: msg,
        codeBlocks: [],
        hasCode: false,
        shouldExecute: false,
        executionDecisionSource: resolveDecisionSource(),
        executionReason: 'Error before execution decision could be applied.',
        executed: false,
        ename,
        evalue: msg,
        traceback: [],
    });
    if (options.maxRetries !== undefined &&
        (!Number.isInteger(options.maxRetries) || options.maxRetries < 1 || options.maxRetries > 100)) {
        return errorResult('maxRetries must be an integer between 1 and 100', 'ValidationError');
    }
    try {
        const g = globalThis;
        if (!getActiveProviderConfig()) {
            const msg = 'AI Engine is not available. Please ensure AI services are properly configured.';
            DisplayAdapter.markdown(msg, { display_id: displayId, update: true });
            return errorResult(msg, 'ConfigurationError');
        }
        // ---- Build hybrid system prompt ----
        const defaultConvention = resolveWindow()?.dataxNow?.ai?.getPromptConvention?.() || '';
        const languageHint = preferredLanguage || '';
        // Optionally inject kernel context for better code quality
        let kernelContext = '';
        if (preferredLanguage || context) {
            let scriptType;
            switch (preferredLanguage) {
                case 'r':
                    scriptType = ScriptType.ROnly;
                    break;
                case 'javascript':
                    scriptType = ScriptType.JsOnly;
                    break;
                default:
                    scriptType = ScriptType.PyOnly;
                    break;
            }
            const { kernel } = await getKernelConfig(scriptType);
            kernelContext = kernel;
        }
        let contextSection = '';
        if (context) {
            const ctxStr = stringifyContextForPrompt(context);
            if (ctxStr.trim().length > 0) {
                contextSection = ctxStr;
            }
        }
        const systemPrompt = system_prompt ?? await render('system/smartAsk', {
            defaultConvention,
            languageHint,
            kernelContext,
            contextSection,
        });
        // ---- Create LLM ----
        const llm = createLLMFromConfig(undefined, model);
        if (!llm) {
            const msg = 'AI Language Model is not available. Please check AI service configuration.';
            DisplayAdapter.markdown(msg, { display_id: displayId, update: true });
            return errorResult(msg, 'ConfigurationError');
        }
        const builtPrompt = buildSkillAwarePrompt(systemPrompt, question);
        const requestOptions = getLLMRequestOptions({}, model);
        const structuredResponseSchema = jsonSchema({
            type: 'object',
            additionalProperties: false,
            required: ['answer', 'codeBlocks', 'shouldExecute', 'executionReason'],
            properties: {
                answer: { type: 'string' },
                codeBlocks: {
                    type: 'array',
                    items: {
                        type: 'object',
                        additionalProperties: false,
                        required: ['language', 'code'],
                        properties: {
                            language: {
                                type: 'string',
                                enum: ['python', 'javascript', 'r', 'unknown'],
                            },
                            code: { type: 'string' },
                        },
                    },
                },
                shouldExecute: { type: 'boolean' },
                executionReason: { type: 'string' },
            },
        });
        // ---- Stream / invoke with skills ----
        const runStructuredStream = async (model, label) => {
            if (label) {
                DisplayAdapter.markdown(label, { display_id: displayId, update: true });
            }
            const agent = createNativeObjectAgent({
                model,
                instructions: builtPrompt.instructions,
                schema: structuredResponseSchema,
                schemaName: 'smartAskResponse',
                schemaDescription: 'Structured assistant response containing prose, executable code blocks, and execution guidance.',
                ...(requestOptions.temperature !== undefined ? { temperature: requestOptions.temperature } : {}),
                ...(requestOptions.maxOutputTokens !== undefined
                    ? { maxOutputTokens: requestOptions.maxOutputTokens }
                    : {}),
            });
            if (streaming) {
                const streamResult = await agent.stream({
                    prompt: builtPrompt.prompt,
                    ...(abortSignal ? { abortSignal } : {}),
                });
                let latestPreview = '';
                for await (const partial of streamResult.partialObjectStream) {
                    const preview = structuredPreviewFromPartialResponse(partial);
                    if (preview.length > 1 && preview !== latestPreview) {
                        latestPreview = preview;
                        DisplayAdapter.markdown(preview, { display_id: displayId, update: true });
                    }
                }
                return normalizeStructuredResponse(await streamResult.object);
            }
            const result = await agent.generate({
                prompt: builtPrompt.prompt,
                ...(abortSignal ? { abortSignal } : {}),
            });
            const structured = normalizeStructuredResponse(result.output);
            const preview = structuredResponseToRawMarkdown(structured);
            DisplayAdapter.markdown(preview, { display_id: displayId, update: true });
            return structured;
        };
        // ---- Primary attempt with retries + URL fallback ----
        // Each transient failure is retried up to maxRetries times on the primary
        // URL before attempting the secondary URL candidate.
        // Do NOT retry on abort/timeout — propagate immediately.
        let structuredResponse = null;
        {
            let lastError;
            let succeeded = false;
            for (let attempt = 1; attempt <= Math.max(1, maxRetries) && !succeeded; attempt++) {
                try {
                    structuredResponse = await runStructuredStream(llm, attempt > 1 ? `Retry attempt ${attempt}…` : undefined);
                    succeeded = true;
                }
                catch (err) {
                    if (err?.name === 'AbortError' || err?.name === 'TimeoutError')
                        throw err;
                    lastError = err;
                }
            }
            if (!succeeded) {
                throw lastError;
            }
        }
        structuredResponse = normalizeStructuredResponse(structuredResponse ?? {
            answer: '',
            codeBlocks: [],
            shouldExecute: false,
            executionReason: '',
        });
        const rawResponse = structuredResponseToRawMarkdown(structuredResponse);
        const codeBlocks = structuredResponse.codeBlocks;
        const answer = structuredResponse.answer;
        // Make code blocks collapsible in the raw response for display
        const collapsibleResponse = rawResponse.replace(/^[ \t]*(```|~~~)[ \t]*([a-zA-Z0-9_+-]*)[ \t]*\n([\s\S]*?)(?:\n[ \t]*\1[ \t]*(?:\n|(?![^]))|(?![^]))/gm, (match, fence, lang, code) => {
            if (lang && lang.toLowerCase() === 'mermaid') {
                return match; // Do not collapse mermaid
            }
            const langName = lang ? lang.charAt(0).toUpperCase() + lang.slice(1) : '';
            const summary = langName ? `Generated ${langName} code` : 'Generated code';
            return `<details ><summary>${summary}</summary><br>\n\n${fence}${lang}\n${code}\n${fence}\n</details>\n`;
        });
        let shouldExecute = false;
        let executionReason = '';
        let executionDecisionSource;
        if (resolvedExecutionPolicy === 'always') {
            shouldExecute = true;
            executionDecisionSource = resolveDecisionSource();
            executionReason = 'Execution policy is always.';
        }
        else if (resolvedExecutionPolicy === 'never') {
            shouldExecute = false;
            executionDecisionSource = resolveDecisionSource();
            executionReason = 'Execution policy is never.';
        }
        else if (codeBlocks.length === 0) {
            // Short-circuit: no code blocks produced — skip the second LLM round-trip.
            shouldExecute = false;
            executionDecisionSource = resolveDecisionSource();
            executionReason = 'No executable fenced code blocks were generated.';
        }
        else {
            shouldExecute = structuredResponse.shouldExecute;
            executionDecisionSource = resolveDecisionSource();
            executionReason =
                structuredResponse.executionReason.trim().length > 0
                    ? structuredResponse.executionReason.trim()
                    : 'AI decision unavailable; defaulting to non-execution.';
        }
        // Keep the generated-code preview only when the response will not be
        // auto-executed. In respond mode, the execution output is the answer.
        DisplayAdapter.markdown(shouldExecute ? '' : collapsibleResponse, { display_id: displayId, update: true });
        const result = {
            status: 'ok',
            rawResponse,
            answer,
            codeBlocks,
            hasCode: codeBlocks.length > 0,
            shouldExecute,
            executionDecisionSource,
            executionReason,
            executed: false,
        };
        // Execution is handled by xeus-x's execution layer (datax-exec.js).
        // This function only returns the generation + decision result.
        return result;
    }
    catch (error) {
        const dbg = getAIAgentsLLMDebug();
        dbg.lastError = _errorInfo(error);
        const normalizedError = normalizeAIError(error);
        const errName = normalizedError.ename;
        let errorMsg;
        if (errName === 'AbortError') {
            errorMsg = 'AI request was cancelled.';
            DisplayAdapter.markdown(errorMsg, { display_id: displayId, update: true });
            return errorResult(errorMsg, 'AbortError');
        }
        if (errName === 'TimeoutError') {
            errorMsg = `AI request timed out after ${timeoutMs ?? 0} ms.`;
            DisplayAdapter.markdown(errorMsg, { display_id: displayId, update: true });
            return errorResult(errorMsg, 'TimeoutError');
        }
        const message = normalizedError.evalue || 'Unknown error';
        errorMsg = `AI request failed: ${message}`;
        DisplayAdapter.markdown(errorMsg, { display_id: displayId, update: true });
        return errorResult(errorMsg);
    }
    finally {
        // Always hide the stop button when the operation ends (success, error, or cancel).
        if (_stopCleanup) {
            _stopCleanup().catch(() => { });
        }
    }
}
export var Purpose;
(function (Purpose) {
    Purpose[Purpose["FirstGen"] = 0] = "FirstGen";
    Purpose[Purpose["FixRuntimeIssue"] = 1] = "FixRuntimeIssue";
    Purpose[Purpose["FixStaticIssue"] = 2] = "FixStaticIssue";
    Purpose[Purpose["Review"] = 3] = "Review";
    Purpose[Purpose["AutoSuggest"] = 4] = "AutoSuggest";
    Purpose[Purpose["AutoSuggestOrFirstGen"] = 5] = "AutoSuggestOrFirstGen";
    Purpose[Purpose["AutoImplement"] = 6] = "AutoImplement";
})(Purpose || (Purpose = {}));
export var ScriptType;
(function (ScriptType) {
    ScriptType["JsOnly"] = "web Javascript";
    ScriptType["PyOnly"] = "python";
    ScriptType["ROnly"] = "R";
    ScriptType["PyJS"] = "both Python and web Javascript";
    ScriptType["PyR"] = "both Python and R";
    ScriptType["PyRJS"] = "Python, R and web Javascript";
})(ScriptType || (ScriptType = {}));
export async function genCode(options) {
    const { currentPrompt, realCode, currentContext, scriptType, modules = [], sessionId: rawSessionId = '', summary_going = '', summary_done = '', closed = false, finalClosed = false, maxTries = 5, purpose = Purpose.FirstGen, usingPackages = [], disallowedPackages = new Set(), metadata = {}, cellIdOverride, abortSignal, showStopButton = true, model, } = options;
    let sessionId = rawSessionId;
    // Create an inline stop-button widget for user-initiated cancellation.
    let _stopCleanup;
    let _effectiveAbortSignal = abortSignal;
    let _setStopButtonLabel;
    const resolvedMetadata = resolveMetadataShared(metadata);
    if (typeof cellIdOverride === 'string' && cellIdOverride.length > 0) {
        resolvedMetadata.cellId = cellIdOverride;
    }
    const lastExecuteIO = resolvedMetadata.lastExecuteIO;
    const localUpdate = sessionId === '';
    if (sessionId === '') {
        sessionId = generateSessionId('code');
    }
    const useDetailsProgress = usesDetailsProgressDisplay(purpose);
    const initialSummary = summary_going || 'Generating code...';
    try {
        try {
            if (useDetailsProgress) {
                if (localUpdate) {
                    DisplayAdapter.details(initialSummary, '', closed, sessionId);
                }
                else {
                    DisplayAdapter.updateDetails(initialSummary, '', closed, sessionId);
                }
            }
            else {
                DisplayAdapter.markdown('', { display_id: sessionId, update: !localUpdate });
            }
        }
        catch (err) {
            console.error('[AI_Agents] Error initializing generation display:', err);
        }
        if (showStopButton) {
            try {
                const { controller, cleanup, setLabel } = await DisplayManager.createStopButton(formatStopButtonLabel(1, purpose));
                _stopCleanup = cleanup;
                _setStopButtonLabel = setLabel;
                _effectiveAbortSignal = combineAbortSignals(abortSignal, controller.signal);
            }
            catch (err) {
                globalThis?._console?.warn('[AI_Agents] DisplayManager.createStopButton failed:', err);
            }
        }
        const { result } = await retryUntil(maxTries, async (attempt) => {
            _setStopButtonLabel?.(formatStopButtonLabel(attempt, purpose));
            const trySummary = summary_going + ' (Try ' + String(attempt) + ')';
            if (useDetailsProgress) {
                try {
                    DisplayAdapter.updateDetails(trySummary, '', closed, sessionId);
                }
                catch (err) {
                    console.error('[AI_Agents] Error calling update_display_details:', err);
                }
            }
            const prompt4AI = await createPromptForCodeReview(lastExecuteIO, currentPrompt, realCode, currentContext, modules, purpose, scriptType, usingPackages);
            _info('Prompt for AI:', prompt4AI);
            const markdownContent = await generateCodeWithLLM(prompt4AI, purpose, scriptType, sessionId, summary_going, summary_done, closed, finalClosed, disallowedPackages, currentPrompt, resolvedMetadata, _effectiveAbortSignal, model);
            return extractCode(markdownContent);
        }, (value) => typeof value === 'string' && value.trim().length > 0);
        return typeof result === 'string' ? result : '';
    }
    finally {
        if (_stopCleanup) {
            _stopCleanup().catch(() => { });
        }
    }
}
/**
 * Attempts to automatically fix failed code execution by regenerating code with AI
 *
 * @param result The execution result from code execution
 * @param code The original code that failed
 * @param metadata Execution metadata including lastExecuteIO
 * @param language Language type (Python, JavaScript, or R)
 * @param globalVars Global variables (for Python)
 * @param imports Available imports (for Python)
 * @param sharedNamespace Shared namespace (for JS/R)
 * @returns Standardized execution result (error result)
 */
export async function fixCode(result, code, metadata, language, context, imports, cellIdOverride) {
    const fixNeeded = result?.status !== 'ok';
    if (!fixNeeded) {
        return (result || {
            status: 'error',
            execution_count: result?.execution_count || 0,
            ename: 'ExecutionError',
            evalue: `${language} execution failed`,
            traceback: [],
        });
    }
    const requirement = code;
    // Get context based on language — already pre-selected by the C++ kernel
    const contextStr = stringifyContextForPrompt(context ?? {});
    const langConfig = {
        [LanguageType_Lowercase.Python]: {
            context: contextStr,
            modules: imports || [],
            scriptType: ScriptType.PyOnly,
            prefix: '@pygo',
            fixingMessage: CONSTANTS.FIXING_PYTHON_CODE,
            fixedMessage: CONSTANTS.FIXED_PYTHON_CODE,
        },
        [LanguageType_Lowercase.JavaScript]: {
            context: contextStr,
            modules: [],
            scriptType: ScriptType.JsOnly,
            prefix: '@jsgo',
            fixingMessage: CONSTANTS.FIXING_JAVASCRIPT_CODE,
            fixedMessage: CONSTANTS.FIXED_JAVASCRIPT_CODE,
        },
        [LanguageType_Lowercase.R]: {
            context: contextStr,
            modules: [],
            scriptType: ScriptType.ROnly,
            prefix: '@rgo',
            fixingMessage: CONSTANTS.FIXING_R_CODE,
            fixedMessage: CONSTANTS.FIXED_R_CODE,
        },
    };
    const cfg = langConfig[language];
    if (!cfg) {
        return {
            status: 'error',
            execution_count: result?.execution_count || 0,
            ename: 'ExecutionError',
            evalue: `Unknown language: ${language}`,
            traceback: [`Unsupported language type: ${language}`],
        };
    }
    const sessionId = `${cfg.prefix}_${crypto.randomUUID().replace(/-/g, '_')}`;
    // Generate fixed code using AI
    await genCode({
        currentPrompt: requirement,
        realCode: false,
        currentContext: cfg.context,
        modules: cfg.modules,
        scriptType: cfg.scriptType,
        sessionId,
        summary_going: cfg.fixingMessage,
        summary_done: cfg.fixedMessage,
        purpose: Purpose.AutoSuggest,
        metadata,
        cellIdOverride,
        // Keep auto-fix aligned with pygen/genCode UX: users can stop the AI stream
        // with the same inline stop control shown by other agent flows.
        showStopButton: true,
    });
    // Return error result (the fixed code is displayed via genCode)
    return {
        status: 'error',
        execution_count: result?.execution_count || 0,
        ename: 'ExecutionError',
        evalue: result.error || `Unknown ${language} execution error`,
        traceback: result.error ? [result.error] : [],
    };
}
/**
 * Auto-implementation: given a code cell containing placeholder markers, ask the AI
 * to generate a concrete implementation and replace the cell source in-place (just like
 * auto-fix). The generated code is streamed back via genCode / Purpose.AutoSuggest so
 * the unified-diff view works the same way as auto-fix.
 *
 * @param request   Parsed auto-implementation request (placeholders, etc.)
 * @param code      The full cell source (after magic stripping)
 * @param metadata  Cell metadata (must contain cellId so the cell can be updated)
 * @param language  Target language ('python' | 'javascript' | 'r')
 * @param globalVars  Current global variables for the active sub-kernel
 * @param imports     Detected imports / loaded packages
 * @param sharedNamespace  Shared cross-language namespace snapshot
 * @param cellIdOverride  Optional cell id override (takes priority over metadata.cellId)
 */
export async function implementCode(request, code, metadata, language, context, imports, cellIdOverride) {
    const requirement = code;
    // Context already pre-selected by the C++ kernel
    const contextStr = stringifyContextForPrompt(context ?? {});
    const langConfig = {
        [LanguageType_Lowercase.Python]: {
            context: contextStr,
            modules: imports || [],
            scriptType: ScriptType.PyOnly,
            prefix: '@pygo',
            implementingMessage: CONSTANTS.GENERATING_PYTHON_CODE,
            implementedMessage: CONSTANTS.GENERATED_PYTHON_CODE,
        },
        [LanguageType_Lowercase.JavaScript]: {
            context: contextStr,
            modules: [],
            scriptType: ScriptType.JsOnly,
            prefix: '@jsgo',
            implementingMessage: CONSTANTS.GENERATING_JAVASCRIPT_CODE,
            implementedMessage: CONSTANTS.GENERATED_JAVASCRIPT_CODE,
        },
        [LanguageType_Lowercase.R]: {
            context: contextStr,
            modules: [],
            scriptType: ScriptType.ROnly,
            prefix: '@rgo',
            implementingMessage: CONSTANTS.GENERATING_R_CODE,
            implementedMessage: CONSTANTS.GENERATED_R_CODE,
        },
        'typescript': {
            context: contextStr,
            modules: [],
            scriptType: ScriptType.JsOnly,
            prefix: '@tsgo',
            implementingMessage: CONSTANTS.GENERATING_JAVASCRIPT_CODE,
            implementedMessage: CONSTANTS.GENERATED_JAVASCRIPT_CODE,
        },
    };
    const cfg = langConfig[language];
    if (!cfg) {
        return {
            status: 'error',
            ename: 'ImplementationError',
            evalue: `Unknown language: ${language}`,
            traceback: [`Unsupported language type: ${language}`],
        };
    }
    const sessionId = `${cfg.prefix}_impl_${crypto.randomUUID().replace(/-/g, '_')}`;
    await genCode({
        currentPrompt: requirement,
        realCode: false,
        currentContext: cfg.context,
        modules: cfg.modules,
        scriptType: cfg.scriptType,
        sessionId,
        summary_going: cfg.implementingMessage,
        summary_done: cfg.implementedMessage,
        purpose: Purpose.AutoImplement,
        metadata,
        cellIdOverride,
        // Auto-implementation uses the same stop-button widget as pygen/genCode.
        showStopButton: true,
    });
    return { status: 'ok' };
}
/**
 * Create prompt for code review/generation
 */
export async function createPromptForCodeReview(lastRun, currentRequirement, realCode, currentContext, modules = [], purpose, scriptType, usingPackages = []) {
    const { wrapLanguage, suggestedLanguage } = getLanguageConfig(scriptType);
    // ------------------------------------------------------------------
    // Resolve current requirement
    // NOTE: In previous implementation we incorrectly accessed only the first
    // character of lastRun.prompt via [0] and mixed operator precedence.
    // lastRun?.["prompt"] is expected to be a string. Fix logic here.
    // ------------------------------------------------------------------
    // Normalized view of lastRun (avoid repeated unsafe casts)
    const lastRunObj = typeof lastRun === 'object' && lastRun !== null ? lastRun : {};
    if (currentRequirement.trim().length === 0) {
        const priorPrompt = lastRunObj['prompt'];
        if (typeof priorPrompt === 'string' && priorPrompt.trim().length > 0) {
            currentRequirement = priorPrompt;
        }
    }
    if (currentRequirement.trim().length === 0) {
        globalThis._console?.error('[AI_Agents] Empty requirement provided');
        return '';
    }
    currentRequirement = sanitizeRequirementForPrompt(currentRequirement);
    // ------------------------------------------------------------------
    // Attempt to extract previously generated concrete code from output_model
    // when lastRun.code is just an instruction (e.g. "@rgo say hi ...")
    // Output model example contains display_data with markdown encapsulating
    // a details block and fenced code. We parse that so we can show the real
    // prior code in the new prompt (improves regeneration quality especially
    // for FirstGen follow-ups or fixes).
    // ------------------------------------------------------------------
    let extractedPrev = '';
    const outputModelRaw = lastRunObj['output_model'];
    if (Array.isArray(outputModelRaw)) {
        try {
            for (const item of outputModelRaw) {
                const md = item?.data?.['text/markdown'];
                if (typeof md === 'string' && md.includes('```')) {
                    const extracted = extractCode(md).trim();
                    if (extracted.length > 0) {
                        extractedPrev = extracted;
                        break;
                    }
                }
            }
        }
        catch (err) {
            globalThis._console?.warn('[AI_Agents] Failed to extract code from output_model:', err);
        }
    }
    const explicitFailedCode = typeof lastRunObj['generated_code'] === 'string'
        ? lastRunObj['generated_code'].trim()
        : '';
    const explicitCodeLanguage = typeof lastRunObj['code_language'] === 'string'
        ? String(lastRunObj['code_language']).trim().toLowerCase()
        : '';
    // If lastRun.code equals the prompt (likely just an instruction) and we
    // successfully extracted real code from the output, treat that as prior code.
    let priorGeneratedCode = explicitFailedCode ||
        (typeof lastRunObj['code'] === 'string' ? lastRunObj['code'] : '') ||
        '';
    if (!explicitFailedCode &&
        typeof priorGeneratedCode === 'string' &&
        typeof lastRunObj['prompt'] === 'string' &&
        priorGeneratedCode === lastRunObj['prompt'] &&
        extractedPrev.length > 0) {
        priorGeneratedCode = extractedPrev;
    }
    // convert scriptType to string for prompt
    const scriptTypeMap = {
        [ScriptType.JsOnly]: 'JavaScript',
        [ScriptType.PyOnly]: 'Python',
        [ScriptType.ROnly]: 'R',
        [ScriptType.PyJS]: 'Python and JavaScript',
        [ScriptType.PyR]: 'Python and R',
        [ScriptType.PyRJS]: 'Python, R and JavaScript',
    };
    const scriptTypeStr = scriptTypeMap[scriptType] ?? '';
    // ------------------------------------------------------------------
    // Build the prompt for the AI using Handlebars templates
    // ------------------------------------------------------------------
    // Build context sections - handle both object and string types
    let contextWrapped = '';
    const contextStr = stringifyContextForPrompt(currentContext);
    _debug(`createPromptForCodeReview: contextStr.length=${contextStr.length}, contextStr.empty=${contextStr.trim().length === 0}, contextStr=${contextStr.slice(0, 200)}`);
    if (contextStr.trim().length > 0) {
        contextWrapped = `\n${wrapCode(contextStr, scriptTypeStr)}`;
    }
    let outputModelWrapped = '';
    if (Array.isArray(lastRunObj.output_model) && lastRunObj.output_model.length > 0) {
        const compressedOutputModel = compressOutput(lastRunObj['output_model']);
        outputModelWrapped = wrapJSON(JSON.stringify(compressedOutputModel));
    }
    let tracebackStr = '';
    const traceback = lastRunObj?.execution_result?.traceback;
    if (traceback && Array.isArray(traceback)) {
        const allStrings = traceback.every((item) => typeof item === 'string');
        if (allStrings && traceback.length > 0) {
            tracebackStr = traceback[traceback.length - 1];
        }
    }
    const defaultConvention = resolveWindow()?.dataxNow?.ai?.getPromptConvention?.() || '';
    const effectiveWrapLang = wrapLanguage || explicitCodeLanguage || 'markdown';
    // Select the appropriate template based on purpose and realCode
    let prompt;
    if (purpose === Purpose.AutoImplement) {
        // Use the dedicated auto-implement template that instructs the LLM to classify
        // the task (semantic → TypedAgent wrapper, algorithmic → deterministic code).
        prompt = await render('task/auto_implement', {
            defaultConvention,
            currentCodeWrapped: wrapCode(currentRequirement, effectiveWrapLang),
            contextWrapped,
            suggestedLanguage,
        });
    }
    else if (purpose === Purpose.FixRuntimeIssue ||
        purpose === Purpose.FixStaticIssue) {
        const execResult = lastRunObj?.execution_result;
        const hasErrorContext = !!execResult?.ename ||
            !!execResult?.evalue ||
            (Array.isArray(execResult?.traceback) && execResult.traceback.length > 0);
        if (execResult?.status === 'ok' || !hasErrorContext) {
            globalThis._console?.error('The code has no error. No need to fix.');
            // Fall through to default template for the return value
            prompt = await render(realCode ? 'task/refine_code' : 'task/gen_from_scratch', {
                defaultConvention,
                currentCodeWrapped: wrapCode(currentRequirement, effectiveWrapLang),
                requirementWrapped: wrapSection(currentRequirement),
                contextWrapped,
                suggestedLanguage,
            });
            return prompt;
        }
        prompt = await render('task/fix_error', {
            requirementWrapped: wrapSection(currentRequirement),
            priorCodeWrapped: wrapCode(priorGeneratedCode || '', effectiveWrapLang),
            outputModelWrapped,
            errorName: execResult?.ename,
            errorValue: execResult?.evalue,
            tracebackStr,
            contextWrapped,
        });
    }
    else if (purpose === Purpose.FirstGen) {
        // Provide history only if we have distinct prior generated code (extracted or explicit)
        const priorPrompt = lastRunObj['prompt'];
        const priorCode = priorGeneratedCode;
        const haveHistory = typeof priorPrompt === 'string' &&
            priorPrompt.trim().length > 0 &&
            typeof priorCode === 'string' &&
            priorCode.trim().length > 0 &&
            lastRunObj['output_model'] &&
            priorCode !== currentRequirement; // avoid echo of current requirement
        if (haveHistory && priorPrompt === currentRequirement) {
            prompt = await render('task/regen_same_req', {
                defaultConvention,
                requirementWrapped: wrapSection(sanitizeRequirementForPrompt(priorPrompt)),
                priorCodeWrapped: wrapCode(priorCode, effectiveWrapLang),
                outputModelWrapped,
                contextWrapped,
            });
        }
        else if (haveHistory) {
            prompt = await render('task/regen_changed_req', {
                defaultConvention,
                priorRequirementWrapped: wrapSection(sanitizeRequirementForPrompt(priorPrompt)),
                priorCodeWrapped: wrapCode(priorCode, effectiveWrapLang),
                outputModelWrapped,
                requirementWrapped: wrapSection(currentRequirement),
                contextWrapped,
            });
        }
        else if (realCode) {
            prompt = await render('task/refine_code', {
                defaultConvention,
                currentCodeWrapped: wrapCode(currentRequirement, effectiveWrapLang),
                contextWrapped,
            });
        }
        else {
            prompt = await render('task/gen_from_scratch', {
                defaultConvention,
                requirementWrapped: wrapSection(currentRequirement),
                contextWrapped,
                suggestedLanguage,
            });
        }
    }
    else if (realCode) {
        prompt = await render('task/refine_code', {
            defaultConvention,
            currentCodeWrapped: wrapCode(currentRequirement, effectiveWrapLang),
            contextWrapped,
        });
    }
    else {
        prompt = await render('task/gen_from_scratch', {
            defaultConvention,
            requirementWrapped: wrapSection(currentRequirement),
            contextWrapped,
            suggestedLanguage,
        });
    }
    return prompt;
}
// ---------------------------------------------------------------------------
// TypedAgent-aware auto-implementation task builder
// ---------------------------------------------------------------------------
/**
 * Returns the TypedAgent wrapper syntax example for the given language.
 * Includes both a pure semantic (single-wrapper) example and a hybrid example
 * where deterministic code embeds `datax.typedagent()` calls for semantic sub-steps.
 * @internal exported for testing
 */
export function buildTypedAgentExample(scriptType) {
    if (scriptType === ScriptType.PyOnly) {
        return `Python semantic example (pure TypedAgent wrapper):
\`\`\`python
def analyze_email(email_text: str) -> dict:
    return datax.typedagent(
        name="analyze_email",
        instruction="Extract the product name, company, and renewal risk from this email.",
        inputs={"email_text": email_text},
        output_schema={
            "type": "object",
            "properties": {
                "product_name": {"type": "string"},
                "company": {"type": "string"},
                "renewal_risk": {"type": "string", "enum": ["low", "medium", "high"]}
            },
            "required": ["product_name", "company", "renewal_risk"]
        }
    )
\`\`\`

Python hybrid example (deterministic code with embedded TypedAgent sub-step):
\`\`\`python
def enrich_customers(records: list) -> list:
    HIGH_RISK_SECTORS = {"finance", "insurance", "legal"}
    results = []
    for record in records:
        # Note: each datax.typedagent() call is sequential (N × latency).
        # For parallel batch processing, use a %%js cell with Promise.all.
        normalized = datax.typedagent(
            name="enrich_customers_step",
            instruction="Normalize the free-form industry description to the closest standard SIC category name.",
            inputs={"industry": record.get("industry", "")},
            output_schema={
                "type": "object",
                "properties": {"sic_category": {"type": "string"}},
                "required": ["sic_category"]
            }
        )
        age_years = record.get("account_age_days", 0) / 365.0
        risk = 1.0 / (1.0 + age_years) if normalized["sic_category"].lower() in HIGH_RISK_SECTORS else 0.1
        results.append({**record, "sic_category": normalized["sic_category"], "risk_score": round(risk, 3)})
    return results
\`\`\``;
    }
    if (scriptType === ScriptType.ROnly) {
        return `R semantic example (pure TypedAgent wrapper):
\`\`\`r
get_sentiment <- function(text) {
    datax$typedagent(
        name = "get_sentiment",
        instruction = "Classify the sentiment of the text. Return a structured result.",
        inputs = list(text = text),
        output_schema = list(
            type = "object",
            properties = list(
                sentiment = list(type = "string", enum = list("negative", "neutral", "positive"))
            ),
            required = list("sentiment")
        )
    )
}
\`\`\`

R hybrid example (deterministic code with embedded TypedAgent sub-step):
\`\`\`r
enrich_items <- function(items) {
    results <- lapply(items, function(item) {
        classification <- datax$typedagent(
            name = "enrich_items_step",
            instruction = "Classify the sentiment and urgency of this support message.",
            inputs = list(message = item$text),
            output_schema = list(
                type = "object",
                properties = list(
                    sentiment = list(type = "string", enum = list("negative", "neutral", "positive")),
                    urgency   = list(type = "string", enum = list("low", "medium", "high"))
                ),
                required = list("sentiment", "urgency")
            )
        )
        c(item, classification)
    })
    do.call(rbind, lapply(results, as.data.frame))
}
\`\`\``;
    }
    return `JavaScript semantic example (pure TypedAgent wrapper):
\`\`\`javascript
async function getSentiment(text) {
    return await datax.typedagent({
        name: "getSentiment",
        instruction: "Classify the sentiment of the text. Return a structured result.",
        inputs: { text },
        output_schema: {
            type: "object",
            properties: { sentiment: { type: "string", enum: ["negative", "neutral", "positive"] } },
            required: ["sentiment"]
        }
    });
}
\`\`\`

TypeScript semantic example (pure TypedAgent wrapper):
\`\`\`typescript
type SentimentResponse = { sentiment: "negative" | "neutral" | "positive" };
async function getSentiment(text: string): Promise<SentimentResponse> {
    return await datax.typedagent<SentimentResponse>({
        name: "getSentiment",
        instruction: "Classify the sentiment of the text. Return a structured result.",
        inputs: { text },
        output_schema: {
            type: "object",
            properties: { sentiment: { type: "string", enum: ["negative", "neutral", "positive"] } },
            required: ["sentiment"]
        }
    });
}
\`\`\`

JavaScript hybrid example (deterministic outer structure with parallel TypedAgent sub-steps):
\`\`\`javascript
async function categorizeItems(items) {
    const normalized = items.map(item => item.trim().toLowerCase());
    // Parallel semantic classification — avoids N × latency of sequential calls.
    const classifications = await Promise.all(
        normalized.map(text => datax.typedagent({
            name: "categorizeItems_step",
            instruction: "Classify the topic of this text into one of the predefined categories.",
            inputs: { text },
            output_schema: {
                type: "object",
                properties: { category: { type: "string", enum: ["tech", "finance", "health", "other"] } },
                required: ["category"]
            }
        }))
    );
    return normalized.map((text, i) => ({ text, category: classifications[i].category }));
}
\`\`\``;
}
/**
 * Returns the system prompt that classifies a function as semantic / algorithmic / hybrid
 * and instructs the LLM on how to implement each pattern.
 * @internal exported for testing
 */
export function buildAutoImplementTask(scriptType) {
    const example = buildTypedAgentExample(scriptType);
    return `Replace implementation placeholders with complete working code. \
Treat empty function bodies containing only \`{}\` and \`__DATAX_IMPLEMENT__\` markers \
as instructions to implement, not as code to preserve.

## Task classification

Before writing code, classify the function into exactly one of three patterns:

- **Semantic** (AI is the best executor): the entire function purpose is sentiment analysis, \
entity or information extraction, text classification, semantic normalization, summarization \
into a fixed schema, labeling, or any task where the correct output cannot be computed deterministically.
- **Algorithmic** (deterministic code is best): all steps are deterministic — math, sorting, \
filtering, string formatting, data transformation, API calls with known schemas, file I/O, numerical computation.
- **Hybrid** (algorithmic outer structure with semantic sub-steps): the function has a \
deterministic outer structure (loop, pipeline, conditional branching) but one or more inner \
steps require semantic interpretation that cannot be expressed as deterministic logic.

## Semantic tasks — generate a \`datax.typedagent(...)\` wrapper

When the task is semantic, generate a wrapper that calls \`datax.typedagent(...)\` with:
- \`name\`: the exact function name (string)
- \`instruction\`: a clear, complete semantic task description derived from the function's \
docstring, comments, or name (do **not** truncate or paraphrase loosely)
- \`inputs\`: all function parameters passed by name
- \`output_schema\`: a JSON Schema object derived from the return type annotation, \
inline type declarations, or the docstring — embedded as a **literal** in the generated code

${example}

## Algorithmic tasks — generate normal deterministic code

When the task is clearly algorithmic, generate ordinary deterministic code as usual.

## Hybrid tasks — deterministic code with embedded TypedAgent sub-steps

When the task has an algorithmic outer structure (loop, pipeline, conditional branch) \
but contains one or more sub-steps that require semantic reasoning, generate deterministic \
code that calls \`datax.typedagent(...)\` only for those semantic sub-steps.

Hybrid detection signals:
- Iteration over a collection where each item needs interpretation or semantic labeling
- Multi-stage pipeline: deterministic validation/transformation → semantic extraction/classification → deterministic aggregation
- Conditional semantic dispatch: the semantic step is only needed on a specific branch
- Mixed return type: the output combines computed numeric fields with AI-extracted structured fields

Sub-step naming convention: use \`"{outer_function_name}_step"\` as the \`name\` for each \
embedded \`datax.typedagent()\` call. For example, a hybrid implementation of \`enrich_customers\` \
uses \`name="enrich_customers_step"\` for the per-item TypedAgent call.

**Over-use guard**: Do NOT use TypedAgent for simple string comparisons, regex matches, \
lookup-table operations, or any step straightforwardly expressible as deterministic code. \
TypedAgent calls carry network latency and LLM cost — use them only when deterministic logic \
genuinely cannot solve the sub-step. A function with only one logical step should not become \
hybrid; classify it as Semantic or Algorithmic instead.

Preserve the surrounding function signature, comments, imports, magic prefix, and language. \
Output only the full updated code in fenced blocks, matching the required language.`;
}
/**
 * Generate code using LLM
 */
export async function generateCodeWithLLM(prompt, purpose, scriptType, sessionId = '', summary_going = '', summary_done = '', closed = false, finalClosed = true, disallowedPackages = new Set(), currentPrompt = '', metadata = {}, abortSignal, model) {
    const { kernel: kernelContext, disallowedPackagesStr } = await getKernelConfig(scriptType, disallowedPackages);
    const outputRequirement = await renderKernel('kernel/output_requirement');
    async function buildRolePrompt(baseTask) {
        return render('system/codegen', {
            scriptType,
            kernelContext,
            outputRequirement,
            disallowedPackages: disallowedPackagesStr,
            task: baseTask,
        });
    }
    const role_coder = purpose === Purpose.AutoSuggest
        ? await buildRolePrompt('Improve the current code while preserving its overall structure and intent. Fix typos and minimal issues; add short inline comments only when a change is non-obvious. Output updated code in fenced blocks, matching the required language(s).')
        : purpose === Purpose.AutoImplement
            ? await buildRolePrompt(buildAutoImplementTask(scriptType))
            : await buildRolePrompt('Generate code that fulfills the request. Prefer correctness and clarity.');
    const inplaceUpdate = purpose === Purpose.AutoSuggest || purpose === Purpose.AutoImplement;
    let inplaceUpdateEnabled = inplaceUpdate;
    let fallbackDisplayInitialized = false;
    const renderFallbackDetails = (summary, content, collapsed) => {
        if (!fallbackDisplayInitialized) {
            DisplayAdapter.details(summary, content, collapsed, sessionId);
            fallbackDisplayInitialized = true;
            return;
        }
        DisplayAdapter.updateDetails(summary, content, collapsed, sessionId);
    };
    const normalizeNewSourceForUnifiedDiff = (args) => {
        const normalizeNewlines = (s) => s.replace(/\r\n/g, '\n');
        const stripLeadingBlankLines = (s) => s.replace(/^\n+/, '');
        const stripTrailingBlankLines = (s) => s.replace(/\n+$/, '');
        const stripOuterFences = (text) => {
            const src = normalizeNewlines(text);
            // Extract all complete fenced blocks: ```lang?\n...\n```
            const blocks = [];
            const fenceRegex = /```[^\n`]*\n([\s\S]*?)```/g;
            for (let match = fenceRegex.exec(src); match; match = fenceRegex.exec(src)) {
                blocks.push(match[1] ?? '');
            }
            if (blocks.length > 0) {
                // Keep only the LAST fenced code block (matches user intent and makes diffs stable).
                for (let i = blocks.length - 1; i >= 0; i -= 1) {
                    const candidate = stripTrailingBlankLines(stripLeadingBlankLines(blocks[i] ?? ''));
                    if (candidate.trim().length > 0) {
                        return candidate;
                    }
                }
                return '';
            }
            // Handle an opening fence without a closing fence: ```lang?\n...EOF
            const openFence = src.match(/```[^\n`]*\n([\s\S]*)$/);
            if (openFence) {
                return stripTrailingBlankLines(stripLeadingBlankLines(openFence[1] ?? ''));
            }
            // No fences present: return as-is (trim only trailing whitespace/newlines).
            return stripTrailingBlankLines(src);
        };
        const stripLeadingMagicLine = (text) => {
            const src = normalizeNewlines(text);
            const firstLineEnd = src.indexOf('\n');
            const firstLine = (firstLineEnd >= 0 ? src.slice(0, firstLineEnd) : src).trim();
            if (firstLine.startsWith('%')) {
                return firstLineEnd >= 0 ? src.slice(firstLineEnd + 1) : '';
            }
            return src;
        };
        const detectIndicatorFromCurrentPrompt = (promptText) => {
            const src = normalizeNewlines(promptText);
            const trimmedStart = src.replace(/^\s+/, '');
            const firstLineEnd = trimmedStart.indexOf('\n');
            const firstLineRaw = firstLineEnd >= 0 ? trimmedStart.slice(0, firstLineEnd) : trimmedStart;
            const firstLine = firstLineRaw.trimEnd();
            if (firstLine.startsWith('%')) {
                return { kind: 'magic', line: firstLine };
            }
            if (firstLine.startsWith('```')) {
                const hasClosingFence = /\n```\s*$/.test(src.trimEnd());
                return { kind: 'fence', openLine: firstLine, hasClosingFence };
            }
            return { kind: 'none' };
        };
        const indicator = detectIndicatorFromCurrentPrompt(args.currentPrompt);
        // Step 1: keep only defenced code from the model output.
        // Also strip any leading magic line the model might have produced.
        let codeOnly = stripOuterFences(args.fullText);
        codeOnly = stripLeadingMagicLine(codeOnly);
        codeOnly = stripTrailingBlankLines(stripLeadingBlankLines(normalizeNewlines(codeOnly)));
        // Step 2: adapt indicator style to match currentPrompt as closely as possible.
        let next = '';
        if (indicator.kind === 'magic') {
            next = `${indicator.line}\n${codeOnly}`;
        }
        else if (indicator.kind === 'fence') {
            next = `${indicator.openLine}\n${codeOnly}`;
            if (indicator.hasClosingFence) {
                next += '\n```';
            }
        }
        else {
            // Default when currentPrompt has no explicit indicator: plain Python cells
            // should remain plain Python; non-default languages need their magic prefix.
            const defaultMagic = args.scriptType === ScriptType.ROnly
                ? '%%R'
                : args.scriptType === ScriptType.JsOnly
                    ? '%%ts'
                    : '';
            next = defaultMagic ? `${defaultMagic}\n${codeOnly}` : codeOnly;
        }
        // Keep trailing newline if the user had one (makes diffs less noisy).
        const wantsTrailingNewline = /\n\s*$/.test(normalizeNewlines(args.currentPrompt));
        if (wantsTrailingNewline && !next.endsWith('\n')) {
            next += '\n';
        }
        return next;
    };
    const role_coder_real = role_coder;
    // Create LLM from the active window.jupyter_ai provider.
    // Temperature is left to the provider's configured value.
    const llm = createLLMFromConfig(undefined, model);
    if (!llm) {
        const err = Object.assign(new Error('Failed to create LLM for code generation. Please check AI service configuration.'), { name: 'ProviderConfigurationError' });
        throw err;
    }
    const g = globalThis;
    // Log metadata sources for debugging
    const metadataCellId = metadata.cellId;
    const dataxCellTarget = g?.datax?.cell?.target;
    const dataxCellExecId = g?.datax?.cell?.exec_id;
    const dataxCellId = g?.datax?.cell?.id;
    _debug('cellId resolution:', {
        metadataCellId,
        dataxCellTarget,
        dataxCellExecId,
        dataxCellId,
        metadataKeys: Object.keys(metadata || {}),
        dataxCellKeys: g?.datax?.cell ? Object.keys(g.datax.cell) : [],
        purpose: purpose
    });
    // For in-place AI updates, prioritize metadataCellId (which comes from C++ kernel)
    // to avoid using stale globalThis.datax.cell values.
    let cellId;
    if (purpose === Purpose.AutoSuggest || purpose === Purpose.AutoImplement) {
        // Auto-fix/auto-implementation MUST use metadata cellId - don't fallback to stale datax.cell.
        cellId = metadataCellId;
        if (!cellId) {
            g?._console?.error?.('[AI_Agents] In-place AI update missing cellId in metadata - cannot update cell', { purpose });
        }
        else {
            _debug(`In-place AI update targeting cell: ${cellId}`);
        }
    }
    else {
        // Normal code generation can use fallback logic
        cellId = metadataCellId ?? dataxCellExecId ?? dataxCellId;
    }
    // Guardrail for in-place unified diff updates:
    // - First update must prove we're targeting the right cell (source match or findCell hit)
    // - Subsequent streaming updates continue safely for that verified cell id.
    // 
    // LIFECYCLE: This variable is scoped to a single generateCodeWithLLM call.
    // It's reset (undefined) at the start of each generation, then set when
    // the first unified diff chunk is validated. Subsequent chunks for the
    // same streaming generation reuse the validated cell id.
    // 
    // This prevents race conditions where streaming chunks from one generation
    // could target a different cell if the user executes a new cell before
    // the previous generation completes.
    let validatedUnifiedDiffCellId = undefined;
    // Cache the actual widget reference after first successful lookup so that
    // subsequent streaming / final writes don't re-search the cells list (which
    // can intermittently fail if the notebook DOM re-renders during long AI
    // generation windows). The widget reference stays valid for the lifetime of
    // this genCode invocation.
    let cachedTargetCell = null;
    // ---------------------------------------------------------------------------
    // Cell-lookup utilities adapted from jupyterlab-diff's findCell / findNotebook
    // Ref: https://github.com/jupyter-ai-contrib/jupyterlab-diff/blob/995b1056/src/plugin.ts#L28-L65
    //
    // NOTE: jupyterlab-diff is NOT a runtime dependency. The patterns and approaches
    // below are vendored/adapted from that project for cell identification logic.
    // The references are for attribution and to document the source of the algorithm.
    // ---------------------------------------------------------------------------
    /** Metadata keys that may hold a kernel-assigned cell identifier. */
    const _metadataKeysForCellId = [
        'id', 'cellId', 'cell_id', 'dataxCellId',
        'exec_id', 'execId', 'execution_id', 'executionId', 'target',
    ];
    /**
     * Find the current notebook panel (mirrors jupyterlab-diff's findNotebook).
     * Returns `{ notebook, widgets }` or `null`.
     */
    const _findNotebook = () => {
        const g = globalThis;
        const w = resolveWindow();
        const nbTracker = w?.dataxNow?.nbTracker;
        if (!nbTracker)
            return null;
        const panel = nbTracker.currentWidget;
        if (!panel?.content)
            return null;
        const notebook = panel.content;
        const raw = notebook?.widgets;
        // Always snapshot into a new Array to avoid live-mutation issues.
        const widgets = Array.isArray(raw)
            ? Array.from(raw)
            : raw && typeof raw[Symbol.iterator] === 'function'
                ? Array.from(raw)
                : [];
        return { notebook, widgets };
    };
    /**
     * Find a cell's **index** in `notebook.model.cells` by `cellIdToFind`.
     * (Adapted from jupyterlab-diff's findCell — returns index, not cell model,
     * because widget lookup must be index-based: `widgets[index]`.)
     *
     * IMPORTANT: The kernel-assigned cellId (from execution metadata) and the
     * JupyterLab widget's `model.id` can be from different ID namespaces.
     * Searching `model.cells` by id and then using the index to get `widgets[i]`
     * is the only reliable method (matches jupyterlab-diff's approach).
     *
     * Strategy (in order):
     *   1. Direct `cells.get(i).id` match   (jupyterlab-diff's approach)
     *   2. Metadata-key match               (datax extension)
     *   3. Returns -1 (not found)
     */
    const _findCellIndex = (notebook, cellIdToFind) => {
        const model = notebook?.model;
        const cells = model?.cells;
        if (!cells || typeof cells.length !== 'number' || typeof cells.get !== 'function') {
            return { index: -1, matchMethod: 'no-cells' };
        }
        // 1. Direct cells.get(i).id match
        for (let i = 0; i < cells.length; i++) {
            const c = cells.get(i);
            if (c?.id != null && String(c.id).trim() === cellIdToFind) {
                return { index: i, matchMethod: 'cell-id' };
            }
        }
        // 2. Metadata-key match
        for (let i = 0; i < cells.length; i++) {
            const c = cells.get(i);
            // Check model metadata (Map-like or plain object)
            const meta = c?.metadata;
            if (meta) {
                const getVal = typeof meta.get === 'function' ? (k) => meta.get(k) : (k) => meta?.[k];
                for (const key of _metadataKeysForCellId) {
                    const val = getVal(key);
                    if (val != null && String(val).trim() === cellIdToFind) {
                        return { index: i, matchMethod: 'metadata-key' };
                    }
                }
            }
            // Check sharedModel metadata
            const shared = c?.sharedModel;
            if (shared && typeof shared.getMetadata === 'function') {
                for (const key of _metadataKeysForCellId) {
                    const val = shared.getMetadata(key);
                    if (val != null && String(val).trim() === cellIdToFind) {
                        return { index: i, matchMethod: 'shared-metadata-key' };
                    }
                }
            }
        }
        return { index: -1, matchMethod: 'not-found' };
    };
    const _getCellSource = (cell) => {
        const source = cell?.model?.sharedModel?.getSource?.();
        if (typeof source === 'string')
            return source;
        if (Array.isArray(source))
            return source.join('');
        return '';
    };
    const _normalizeForMatch = (text) => text.replace(/\r\n/g, '\n').trim();
    // ---------------------------------------------------------------------------
    // executeUnifiedCellDiff
    //
    // Cell lookup strategy (mirrors jupyterlab-diff plugin.ts#L275-L310):
    //   1. Find cell INDEX in notebook.model.cells (by id or metadata)
    //   2. Get widget at that INDEX: widgets[index]
    //   3. Fallback: active cell
    //
    // CRITICAL: The kernel-assigned cellId (from execute_request metadata)
    // and JupyterLab widget's model.id are from DIFFERENT ID namespaces.
    // Never compare widget.model.id against the kernel cellId directly.
    // ---------------------------------------------------------------------------
    const executeUnifiedCellDiff = async (payload) => {
        const g = globalThis;
        const requestedCellIdStr = String(cellId ?? '').trim();
        // ---- Early validation ----
        if (!requestedCellIdStr || ['undefined', 'null', '[object Object]'].includes(requestedCellIdStr)) {
            g?._console?.error?.('[AI_Agents] executeUnifiedCellDiff: invalid or missing cellId', { cellId });
            return false;
        }
        _debug(`executeUnifiedCellDiff: attempting to update cell ${requestedCellIdStr}`);
        // ---- Find notebook (findNotebook) ----
        const nb = _findNotebook();
        if (!nb) {
            g?._console?.error?.('[AI_Agents] executeUnifiedCellDiff: notebook not available');
            return false;
        }
        const { notebook, widgets } = nb;
        // ---- Cell-lookup state (declared here so all steps share the same variables) ----
        let targetCell = null;
        let matchMethod = '';
        // ---- Step 0: Reuse cached widget reference from a previous successful call ----
        // After the first successful lookup we have a stable widget reference.
        // Re-searching the cells list can intermittently fail during long AI
        // generation windows (e.g. if JupyterLite re-renders or the active cell
        // changes), causing the autofix to silently abort and leave the cell in
        // its original state.  Always try to reuse the cached reference first;
        // only fall back to re-search if the cache is stale.
        if (!targetCell && cachedTargetCell != null && cachedTargetCell.model?.type === 'code') {
            targetCell = cachedTargetCell;
            matchMethod = 'cached-widget';
            _debug('executeUnifiedCellDiff: reusing cached widget reference');
        }
        else if (!targetCell) {
            cachedTargetCell = null; // invalidate stale reference
        }
        // ---- Step 1: Index-based lookup (jupyterlab-diff's approach) ----
        // Find cell index in model.cells, then get the widget at the same index.
        // This is reliable because JupyterLab maintains 1:1 index correspondence
        // between notebook.model.cells and notebook.content.widgets.
        if (!targetCell) {
            let cellMatchMethod = '';
            let foundCell = null;
            const { index: cellIndex, matchMethod: method } = _findCellIndex(notebook, requestedCellIdStr);
            if (cellIndex >= 0 && cellIndex < widgets.length) {
                const widget = widgets[cellIndex];
                if (widget?.model?.type === 'code') {
                    foundCell = widget;
                    cellMatchMethod = method;
                    _debug(`executeUnifiedCellDiff: found widget at index ${cellIndex} via ${cellMatchMethod}`, {
                        requestedId: requestedCellIdStr,
                        widgetModelId: String(widget.model.id ?? ''),
                        cellIndex,
                    });
                }
                else {
                    g?._console?.warn?.(`[AI_Agents] executeUnifiedCellDiff: widget at index ${cellIndex} is not a code cell`, { type: widget?.model?.type, matchMethod: cellMatchMethod });
                }
            }
            // ---- Step 2: Active-cell fallback (jupyterlab-diff default) ----
            if (!foundCell) {
                const activeWidget = notebook?.activeCell;
                if (activeWidget?.model?.type === 'code') {
                    foundCell = activeWidget;
                    matchMethod = 'active-cell';
                    _debug('executeUnifiedCellDiff: using active-cell fallback', { activeCellModelId: String(activeWidget.model.id ?? '') });
                }
            }
            if (foundCell) {
                targetCell = foundCell;
                matchMethod = cellMatchMethod || matchMethod;
            }
        }
        if (!targetCell?.model || targetCell.model.type !== 'code') {
            g?._console?.error?.(`[AI_Agents] executeUnifiedCellDiff: no code cell widget found for ${requestedCellIdStr}`, { matchMethod: matchMethod || 'none' });
            return false;
        }
        const resolvedCellId = String(targetCell.model.id ?? '');
        // ---- First-write validation (stream guardrail) ----
        const alreadyValidated = typeof validatedUnifiedDiffCellId === 'string' &&
            validatedUnifiedDiffCellId.length > 0 &&
            validatedUnifiedDiffCellId === resolvedCellId;
        if (!alreadyValidated) {
            const desiredOriginal = _normalizeForMatch(payload.originalSource || '');
            const currentSource = _normalizeForMatch(_getCellSource(targetCell));
            const sourceMatches = desiredOriginal.length > 0 && currentSource.length > 0 && currentSource === desiredOriginal;
            // Direct or metadata match → trust without source check.
            // Active-cell fallback → require source match OR unique source recovery.
            if (matchMethod === 'active-cell' && !sourceMatches) {
                // Try source-based recovery: find a unique code cell with matching source
                const codeWidgets = widgets.filter((c) => c?.model?.type === 'code');
                const bySource = codeWidgets.filter((c) => _normalizeForMatch(_getCellSource(c)) === desiredOriginal);
                if (bySource.length === 1) {
                    g?._console?.warn?.('[AI_Agents] executeUnifiedCellDiff: active-cell source mismatch, recovered by unique source match', { requestedCellId: requestedCellIdStr, recoveredCellId: bySource[0]?.model?.id });
                    targetCell = bySource[0];
                    matchMethod = 'source-recovery';
                }
                else {
                    // Active cell source doesn't match, and no unique recovery available.
                    // To prevent data loss from updating the wrong cell (e.g., user quickly
                    // executed cell B after cell A, and cell A's auto-fix tries to update B),
                    // we abort rather than proceeding with an uncertain target.
                    const errMsg = '[AI_Agents] executeUnifiedCellDiff: active-cell source mismatch with no unique recovery; aborting to avoid unsafe update';
                    g?._console?.error?.(errMsg, {
                        requestedCellId: requestedCellIdStr,
                        activeCellId: resolvedCellId,
                        sourceMatchCandidates: bySource.length,
                    });
                    throw new Error(errMsg);
                }
            }
            // Lock the stream to this target for subsequent chunks.
            validatedUnifiedDiffCellId = String(targetCell.model.id ?? '');
            // Cache the widget reference so future calls don't need to re-search
            // the notebook cells list (which can fail if the DOM re-renders during
            // a long AI generation window).
            cachedTargetCell = targetCell;
            _debug(`executeUnifiedCellDiff: validated & cached target cell ${validatedUnifiedDiffCellId}`);
        }
        _debug(`executeUnifiedCellDiff: resolved cell via ${matchMethod}`, { targetId: targetCell.model.id, requestedId: requestedCellIdStr });
        // ---- Update the cell's source code ----
        targetCell.model.sharedModel.setSource(payload.newSource);
        // ---- Enable diff mode (skip during transient/streaming updates) ----
        const diffAPI = resolveWindow()?.dataxNow?.diffMode;
        const shouldEnableDiff = payload.enableDiffMode !== false;
        if (shouldEnableDiff && diffAPI && typeof diffAPI.enableDiffMode === 'function') {
            try {
                await diffAPI.enableDiffMode(targetCell);
                _debug('executeUnifiedCellDiff: diff mode enabled');
            }
            catch (err) {
                g?._console?.warn?.('[AI_Agents] executeUnifiedCellDiff: failed to enable diff mode:', err);
            }
        }
        else if (!shouldEnableDiff) {
            _debug('executeUnifiedCellDiff: skipping diff mode for transient update');
        }
        else {
            _debug('executeUnifiedCellDiff: diffMode API not available');
        }
        return true;
    };
    _debug(`unified-cell-diff target cellId: ${cellId ?? 'undefined'} (purpose: ${Purpose[purpose]})`);
    if (inplaceUpdateEnabled) {
        if (!cellId) {
            globalThis?._console?.error?.('[AI_Agents] Cannot execute unified cell diff - no cellId available');
            inplaceUpdateEnabled = false;
        }
        else {
            let ok = false;
            try {
                ok = await executeUnifiedCellDiff({
                    originalSource: currentPrompt,
                    newSource: summary_going + '\n', // show fixing progress immediately
                    enableDiffMode: true
                });
            }
            catch (err) {
                g?._console?.warn?.('[AI_Agents] Auto-fix cell update failed during init:', err);
            }
            if (!ok) {
                globalThis?._console?.warn?.('[AI_Agents] Auto-fix in-place update disabled; using display fallback for this run');
                inplaceUpdateEnabled = false;
                renderFallbackDetails(summary_going, '', closed);
            }
        }
    }
    const runStream = async (streamLLM, heading) => {
        if (heading) {
            if (inplaceUpdateEnabled) {
                let ok = false;
                try {
                    ok = await executeUnifiedCellDiff({
                        originalSource: currentPrompt,
                        newSource: summary_going + '\n' + (heading || ''), // show progress heading
                        enableDiffMode: true
                    });
                }
                catch (err) {
                    g?._console?.warn?.('[AI_Agents] Auto-fix cell update failed during heading:', err);
                }
                if (!ok) {
                    inplaceUpdateEnabled = false;
                    renderFallbackDetails(summary_going, heading, closed);
                }
            }
            else {
                if (inplaceUpdate) {
                    renderFallbackDetails(summary_going, heading, closed);
                }
                else {
                    DisplayAdapter.markdown('', { display_id: sessionId });
                }
            }
        }
        const builtPrompt = buildSkillAwarePrompt(role_coder_real, prompt);
        const requestOptions = getLLMRequestOptions({}, model);
        const codeAgent = createNativeTextAgent({
            model: streamLLM,
            instructions: builtPrompt.instructions,
            ...(requestOptions.temperature !== undefined ? { temperature: requestOptions.temperature } : {}),
            ...(requestOptions.maxOutputTokens !== undefined
                ? { maxOutputTokens: requestOptions.maxOutputTokens }
                : {}),
        });
        let lastDisplayUpdate = 0;
        const THROTTLE_MS = 100;
        const { text: fullText } = await collectAgentTextWithStreamingFallback(codeAgent, builtPrompt.prompt, abortSignal, async (fullText) => {
            const now = Date.now();
            if (fullText.length === 0 || now - lastDisplayUpdate < THROTTLE_MS) {
                return;
            }
            lastDisplayUpdate = now;
            if (inplaceUpdateEnabled) {
                let ok = false;
                try {
                    ok = await executeUnifiedCellDiff({
                        originalSource: currentPrompt,
                        newSource: summary_going + '\n' + fullText, // show fixing progress + streamed code
                        enableDiffMode: true
                    });
                }
                catch (err) {
                    g?._console?.warn?.('[AI_Agents] Auto-fix cell update failed during stream:', err);
                }
                if (!ok) {
                    inplaceUpdateEnabled = false;
                    renderFallbackDetails(summary_going, fullText, closed);
                }
            }
            else if (inplaceUpdate) {
                renderFallbackDetails(summary_going, fullText, closed);
            }
            else {
                DisplayAdapter.markdown(buildInProgressCodeMarkdown(scriptType, fullText), { display_id: sessionId, update: true });
            }
        });
        // Final flush — always render the completed text
        if (fullText.length > 0) {
            if (inplaceUpdateEnabled) {
                try {
                    await executeUnifiedCellDiff({
                        originalSource: currentPrompt,
                        newSource: summary_going + '\n' + fullText, // streaming flush — show progress + completed text
                        enableDiffMode: true
                    });
                }
                catch (err) {
                    g?._console?.warn?.('[AI_Agents] Auto-fix cell update failed during final flush:', err);
                }
            }
            else if (inplaceUpdate) {
                renderFallbackDetails(summary_going, fullText, closed);
            }
            else {
                DisplayAdapter.markdown(buildInProgressCodeMarkdown(scriptType, fullText), { display_id: sessionId, update: true });
            }
        }
        return fullText;
    };
    try {
        let fullText = await runStream(llm);
        // Auto-inject %matplotlib inline when the generated code uses matplotlib but
        // lacks the magic command — prevents figures from rendering as text-only.
        if (fullText.includes('matplotlib') && !fullText.includes('%matplotlib')) {
            fullText = '%matplotlib inline\n' + fullText;
        }
        if (inplaceUpdateEnabled) {
            const finalText = normalizeNewSourceForUnifiedDiff({
                currentPrompt,
                fullText,
                scriptType,
            });
            let ok = false;
            try {
                ok = await executeUnifiedCellDiff({
                    originalSource: currentPrompt,
                    newSource: finalText,
                    enableDiffMode: true // final normalized state — show diff overlay
                });
            }
            catch (err) {
                g?._console?.warn?.('[AI_Agents] Auto-fix cell update failed during final write:', err);
            }
            if (!ok) {
                inplaceUpdateEnabled = false;
                renderFallbackDetails(summary_done, fullText, finalClosed);
            }
        }
        else {
            if (inplaceUpdate) {
                renderFallbackDetails(summary_done, fullText, finalClosed);
            }
            else {
                const fencedContent = '\n```python\n' + fullText + '\n```\n';
                const detailsBlock = '<details ><summary>' + summary_done + '</summary><br>\n\n' + fencedContent + '\n</details>';
                DisplayAdapter.markdown(detailsBlock, { display_id: sessionId, update: true });
            }
        }
        return fullText;
    }
    catch (error) {
        const dbg = getAIAgentsLLMDebug();
        dbg.lastError = _errorInfo(error);
        throw error;
    }
}
//# sourceMappingURL=ai_agents.js.map