export declare function retryUntil<T>(maxAttempts: number, attempt: (attempt: number) => Promise<T>, isSuccess: (result: T) => boolean, delayMs?: number): Promise<{
    result: T;
    attempts: number;
}>;
//# sourceMappingURL=retry.d.ts.map