import { generateText, streamText, Output, } from 'ai';
import { GENAI_MAX_RETRIES } from './genai-retry.js';
function buildSharedCallOptions(options) {
    return {
        maxRetries: GENAI_MAX_RETRIES,
        ...(typeof options.instructions === 'string' ? { system: options.instructions } : {}),
        ...(typeof options.temperature === 'number' ? { temperature: options.temperature } : {}),
        ...(typeof options.maxOutputTokens === 'number'
            ? { maxOutputTokens: options.maxOutputTokens }
            : {}),
        ...(options.providerOptions ? { providerOptions: options.providerOptions } : {}),
        ...(options.tools ? { tools: options.tools } : {}),
        ...(options.toolChoice ? { toolChoice: options.toolChoice } : {}),
        ...(options.stopWhen ? { stopWhen: options.stopWhen } : {}),
        ...(options.activeTools ? { activeTools: options.activeTools } : {}),
    };
}
function buildPromptCallOptions(callOptions) {
    if (Array.isArray(callOptions.messages)) {
        return {
            messages: callOptions.messages,
            ...(callOptions.abortSignal ? { abortSignal: callOptions.abortSignal } : {}),
        };
    }
    return {
        prompt: String(callOptions.prompt ?? ''),
        ...(callOptions.abortSignal ? { abortSignal: callOptions.abortSignal } : {}),
    };
}
export function createNativeTextAgent(options) {
    return {
        async stream(callOptions) {
            const result = streamText({
                model: options.model,
                ...buildSharedCallOptions(options),
                ...buildPromptCallOptions(callOptions),
            });
            return {
                textStream: result.textStream,
                fullStream: result.fullStream,
                sdkResult: result,
            };
        },
        async generate(callOptions) {
            const result = await generateText({
                model: options.model,
                ...buildSharedCallOptions(options),
                ...buildPromptCallOptions(callOptions),
            });
            return {
                text: result.text,
                finishReason: result.finishReason,
                usage: result.usage,
                warnings: result.warnings ?? [],
                sdkResult: result,
            };
        },
    };
}
function buildObjectOutput(options) {
    return Output.object({
        schema: options.schema,
        ...(typeof options.schemaName === 'string' ? { name: options.schemaName } : {}),
        ...(typeof options.schemaDescription === 'string'
            ? { description: options.schemaDescription }
            : {}),
    });
}
export function createNativeObjectAgent(options) {
    const output = buildObjectOutput(options);
    return {
        async stream(callOptions) {
            const result = streamText({
                model: options.model,
                output,
                ...buildSharedCallOptions(options),
                ...buildPromptCallOptions(callOptions),
            });
            return {
                partialObjectStream: result.partialOutputStream,
                textStream: result.textStream,
                fullStream: result.fullStream,
                object: Promise.resolve(result.output),
                sdkResult: result,
            };
        },
        async generate(callOptions) {
            const result = await generateText({
                model: options.model,
                output,
                ...buildSharedCallOptions(options),
                ...buildPromptCallOptions(callOptions),
            });
            return {
                output: result.output,
                text: result.text,
                finishReason: result.finishReason,
                usage: result.usage,
                warnings: result.warnings ?? [],
                sdkResult: result,
            };
        },
    };
}
//# sourceMappingURL=native-agent.js.map