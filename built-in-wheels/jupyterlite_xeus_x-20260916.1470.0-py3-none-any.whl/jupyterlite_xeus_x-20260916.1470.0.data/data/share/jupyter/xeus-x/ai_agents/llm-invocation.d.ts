/**
 * LLMInvocationService - Stub module (to be fully implemented in next deepening phase)
 *
 * This module will provide a clean interface for LLM operations including:
 * - Text streaming and generation
 * - Object generation with schema validation
 * - Embedding operations
 * - SmartAsk orchestration
 *
 * The implementation will mirror the Vercel AI SDK API for easy maintenance.
 *
 * See ADR-001 for the full deepening plan.
 */
export interface LLMInvocationService {
    generateText(prompt: string, options?: any): Promise<{
        text: string;
    }>;
    streamText(prompt: string, options?: any): Promise<{
        textStream: AsyncIterable<string>;
    }>;
    generateObject<OBJECT>(prompt: string, schema: any, options?: any): Promise<{
        object: OBJECT;
    }>;
    streamObject<OBJECT>(prompt: string, schema: any, options?: any): Promise<{
        objectStream: AsyncIterable<OBJECT>;
    }>;
}
export interface AbortControllerFactory {
    combine(...signals: AbortSignal[]): AbortSignal | null;
    timeout(ms: number): AbortSignal;
}
//# sourceMappingURL=llm-invocation.d.ts.map