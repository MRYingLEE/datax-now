/**
 * Agent Code Generators
 *
 * Port of string template functions from xeus-x agent_executor.cpp to TypeScript.
 * These generate language-specific code strings for agent command execution.
 *
 * By living in TypeScript, agent API changes no longer require WASM rebuilds.
 */
// Constants matching xeus_base C++ enum values
const INVALID_FUNCTION = -1;
const NO_PARAMS = 0;
const SINGLE_PARAM = 1;
function escapeString(s) {
    let result = '';
    for (const c of s) {
        switch (c) {
            case '"':
                result += '\\"';
                break;
            case '\\':
                result += '\\\\';
                break;
            case '\b':
                result += '\\b';
                break;
            case '\f':
                result += '\\f';
                break;
            case '\n':
                result += '\\n';
                break;
            case '\r':
                result += '\\r';
                break;
            case '\t':
                result += '\\t';
                break;
            default:
                if (c.charCodeAt(0) <= 0x1f) {
                    result += '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0');
                }
                else {
                    result += c;
                }
        }
    }
    return result;
}
function escapeJsSingleQuotedString(s) {
    let result = '';
    for (const c of s) {
        switch (c) {
            case '\'':
                result += '\\\'';
                break;
            case '\\':
                result += '\\\\';
                break;
            case '\b':
                result += '\\b';
                break;
            case '\f':
                result += '\\f';
                break;
            case '\n':
                result += '\\n';
                break;
            case '\r':
                result += '\\r';
                break;
            case '\t':
                result += '\\t';
                break;
            default:
                if (c.charCodeAt(0) <= 0x1f) {
                    result += '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0');
                }
                else {
                    result += c;
                }
        }
    }
    return result;
}
function combinedAgentArgument(cmd) {
    let argument = '';
    if (cmd.pre_text)
        argument += cmd.pre_text;
    if (argument && cmd.post_text)
        argument += ' ';
    if (cmd.post_text)
        argument += cmd.post_text;
    if (!argument)
        argument = cmd.code;
    return argument;
}
function smartAskUserArgument(cmd) {
    if (cmd.post_text)
        return cmd.post_text;
    if (cmd.code)
        return cmd.code;
    return '';
}
function smartAskMetadataLiteral(target) {
    return '{ cell: { target: "' + escapeString(target) + '" }, systemPromptAlias: true }';
}
function joinArgs(args, sep) {
    return args.join(sep);
}
function isSimpleIdentifier(name) {
    if (!name)
        return false;
    return /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name);
}
function baseAgentAliasName(name) {
    for (const suffix of ['_python', '_javascript', '_py', '_js', '_r']) {
        if (name.length > suffix.length && name.endsWith(suffix)) {
            return name.slice(0, -suffix.length);
        }
    }
    return '';
}
function isLikelyJsonPayload(value) {
    const trimmed = value.trim();
    if (!trimmed)
        return false;
    if (!((trimmed.startsWith('{') && trimmed.endsWith('}')) ||
        (trimmed.startsWith('[') && trimmed.endsWith(']')))) {
        return false;
    }
    try {
        JSON.parse(trimmed);
        return true;
    }
    catch {
        return false;
    }
}
function parseDisplayTemplateSegments(value) {
    const segments = [];
    let currentText = '';
    const pushText = () => {
        if (!currentText)
            return;
        segments.push({ kind: 'text', value: currentText });
        currentText = '';
    };
    for (let i = 0; i < value.length; i++) {
        const ch = value[i];
        const next = value[i + 1];
        if (ch === '{' && next === '{') {
            currentText += '{';
            i += 1;
            continue;
        }
        if (ch === '}' && next === '}') {
            currentText += '}';
            i += 1;
            continue;
        }
        if (ch === '{') {
            const end = value.indexOf('}', i + 1);
            if (end === -1)
                return null;
            const expr = value.slice(i + 1, end).trim();
            if (!expr || expr.includes('{'))
                return null;
            pushText();
            segments.push({ kind: 'expr', value: expr });
            i = end;
            continue;
        }
        if (ch === '}') {
            return null;
        }
        currentText += ch;
    }
    pushText();
    return segments;
}
function escapeDoubleQuotedString(value) {
    return value
        .replace(/\\/g, '\\\\')
        .replace(/"/g, '\\"')
        .replace(/\n/g, '\\n')
        .replace(/\r/g, '\\r')
        .replace(/\t/g, '\\t');
}
function escapePythonFStringText(value) {
    return escapeDoubleQuotedString(value)
        .replace(/\{/g, '{{')
        .replace(/\}/g, '}}');
}
function escapeJsTemplateText(value) {
    return value
        .replace(/\\/g, '\\\\')
        .replace(/`/g, '\\`')
        .replace(/\$\{/g, '\\${')
        .replace(/\n/g, '\\n')
        .replace(/\r/g, '\\r')
        .replace(/\t/g, '\\t');
}
function escapeRGlueText(value) {
    return escapeDoubleQuotedString(value)
        .replace(/\{/g, '{{')
        .replace(/\}/g, '}}');
}
function renderDisplayTemplate(value, lang) {
    if (!value) {
        return lang === 'javascript' ? '""' : '""';
    }
    if (isLikelyJsonPayload(value)) {
        return `"${escapeDoubleQuotedString(value)}"`;
    }
    const segments = parseDisplayTemplateSegments(value);
    const hasExpressions = segments?.some(segment => segment.kind === 'expr') ?? false;
    if (!segments || !hasExpressions) {
        return `"${escapeDoubleQuotedString(value)}"`;
    }
    if (lang === 'python') {
        const body = segments.map(segment => (segment.kind === 'expr'
            ? `{${segment.value}}`
            : escapePythonFStringText(segment.value))).join('');
        return `f"${body}"`;
    }
    if (lang === 'javascript') {
        const body = segments.map(segment => (segment.kind === 'expr'
            ? `\${${segment.value}}`
            : escapeJsTemplateText(segment.value))).join('');
        return `\`${body}\``;
    }
    const body = segments.map(segment => (segment.kind === 'expr'
        ? `{${segment.value}}`
        : escapeRGlueText(segment.value))).join('');
    return `glue::glue("${body}")`;
}
function pythonTemplateBootstrap() {
    return ('if "__xeus_expand_template" not in globals():\n' +
        '    import re\n' +
        '    __xeus_tpl_l = "__XEUS_TPL_LBRACE__"\n' +
        '    __xeus_tpl_r = "__XEUS_TPL_RBRACE__"\n' +
        '    def __xeus_expand_template(__s):\n' +
        '        __text = str(__s).replace("{{", __xeus_tpl_l).replace("}}", __xeus_tpl_r)\n' +
        '        def __repl(__m):\n' +
        '            __expr = __m.group(1).strip()\n' +
        '            try:\n' +
        '                return str(eval(__expr, globals()))\n' +
        '            except Exception as __e:\n' +
        '                raise RuntimeError(f"Template expression {{{__expr}}} failed: {__e}") from __e\n' +
        '        __out = re.sub(r"\\{([^{}]+)\\}", __repl, __text)\n' +
        '        if "{" in __out or "}" in __out:\n' +
        '            raise RuntimeError("Template contains unresolved or malformed braces")\n' +
        '        return __out.replace(__xeus_tpl_l, "{").replace(__xeus_tpl_r, "}")\n');
}
function rTemplateBootstrap() {
    return ('if (!exists(".xeus_expand_template", envir = .GlobalEnv)) {\n' +
        '  .xeus_tpl_l <- "__XEUS_TPL_LBRACE__"\n' +
        '  .xeus_tpl_r <- "__XEUS_TPL_RBRACE__"\n' +
        '  .xeus_expand_template <- function(.s) {\n' +
        '    .orig <- as.character(.s)\n' +
        '    .trim <- trimws(.orig)\n' +
        '    if ((grepl("^\\\\{", .trim) && grepl("\\\\}$", .trim)) || (grepl("^\\\\[", .trim) && grepl("\\\\]$", .trim))) {\n' +
        '      .is_json <- FALSE\n' +
        '      if (requireNamespace("jsonlite", quietly = TRUE)) {\n' +
        '        .is_json <- tryCatch(jsonlite::validate(.trim), error = function(e) FALSE)\n' +
        '      }\n' +
        '      if (.is_json) return(.orig)\n' +
        '    }\n' +
        '    .l <- .xeus_tpl_l\n' +
        '    .r <- .xeus_tpl_r\n' +
        '    .text <- gsub("\\\\{\\\\{", .l, as.character(.s), perl = TRUE)\n' +
        '    .text <- gsub("\\\\}\\\\}", .r, .text, perl = TRUE)\n' +
        '    .safe_calls <- c(\'[\', \'$\', \'+\', \'-\', \'*\', \'/\', \'^\', \'==\', \'!=\', \'<=\', \'>=\', \'<\', \'>\', \'&\', \'&&\', \'|\', \'||\', \'!\', \'c\', \'list\', \'paste0\', \'as.character\', \'as.numeric\', \'as.logical\', \'as.integer\', \'typeof\', \'length\', \'nchar\', \'trimws\', \'seq_along\', \'min\', \'max\', \'sum\', \'mean\')\n' +
        '    .make_safe <- function() {\n' +
        '      .e <- new.env(parent = emptyenv())\n' +
        '      .e$`[` <- `[`\n' +
        '      .e$`$` <- `$`\n' +
        '      .e$`+` <- `+`\n' +
        '      .e$`-` <- `-`\n' +
        '      .e$`*` <- `*`\n' +
        '      .e$`/` <- `/`\n' +
        '      .e$`^` <- `^`\n' +
        '      .e$`==` <- `==`\n' +
        '      .e$`!=` <- `!=`\n' +
        '      .e$`<=` <- `<=`\n' +
        '      .e$`>=` <- `>=`\n' +
        '      .e$`<` <- `<`\n' +
        '      .e$`>` <- `>`\n' +
        '      .e$`&` <- `&`\n' +
        '      .e$`&&` <- `&&`\n' +
        '      .e$`|` <- `|`\n' +
        '      .e$`||` <- `||`\n' +
        '      .e$`!` <- `!`\n' +
        '      .e$T <- TRUE\n' +
        '      .e$F <- FALSE\n' +
        '      assign("TRUE", TRUE, envir = .e)\n' +
        '      assign("FALSE", FALSE, envir = .e)\n' +
        '      assign("NULL", NULL, envir = .e)\n' +
        '      assign("NA", NA, envir = .e)\n' +
        '      .e$c <- c\n' +
        '      .e$list <- list\n' +
        '      .e$paste0 <- paste0\n' +
        '      .e$as.character <- as.character\n' +
        '      .e$as.numeric <- as.numeric\n' +
        '      .e$as.logical <- as.logical\n' +
        '      .e$as.integer <- as.integer\n' +
        '      .e$typeof <- typeof\n' +
        '      .e$length <- length\n' +
        '      .e$nchar <- nchar\n' +
        '      .e$trimws <- trimws\n' +
        '      .e$seq_along <- seq_along\n' +
        '      .e$min <- min\n' +
        '      .e$max <- max\n' +
        '      .e$sum <- sum\n' +
        '      .e$mean <- mean\n' +
        '      .e$stop <- function(...) stop(..., call. = FALSE)\n' +
        '      .e\n' +
        '    }\n' +
        '    .is_safe_expr <- function(.node) {\n' +
        '      if (is.null(.node) || is.atomic(.node)) return(TRUE)\n' +
        '      if (is.symbol(.node)) {\n' +
        '        .name <- as.character(.node)\n' +
        '        return(!identical(.name, ""))\n' +
        '      }\n' +
        '      if (is.expression(.node) || is.pairlist(.node)) {\n' +
        '        .parts <- as.list(.node)\n' +
        '        if (!length(.parts)) return(TRUE)\n' +
        '        return(all(vapply(.parts, .is_safe_expr, logical(1))))\n' +
        '      }\n' +
        '      if (is.call(.node)) {\n' +
        '        .head <- .node[[1L]]\n' +
        '        if (!is.symbol(.head)) return(FALSE)\n' +
        '        .fn <- as.character(.head)\n' +
        '        if (!(.fn %in% .safe_calls)) return(FALSE)\n' +
        '        .args <- as.list(.node)[-1L]\n' +
        '        if (!length(.args)) return(TRUE)\n' +
        '        return(all(vapply(.args, .is_safe_expr, logical(1))))\n' +
        '      }\n' +
        '      FALSE\n' +
        '    }\n' +
        '    .bind_globals <- function(.node, .env) {\n' +
        '      if (is.symbol(.node)) {\n' +
        '        .name <- as.character(.node)\n' +
        '        if (!(.name %in% c("", "T", "F", "TRUE", "FALSE", "NULL", "NA")) &&\n' +
        '            !exists(.name, envir = .env, inherits = FALSE) &&\n' +
        '            exists(.name, envir = .GlobalEnv, inherits = FALSE)) {\n' +
        '          assign(.name, get(.name, envir = .GlobalEnv, inherits = FALSE), envir = .env)\n' +
        '        }\n' +
        '        return(invisible(NULL))\n' +
        '      }\n' +
        '      if (is.expression(.node) || is.call(.node) || is.pairlist(.node)) {\n' +
        '        for (.part in as.list(.node)) {\n' +
        '          .bind_globals(.part, .env)\n' +
        '        }\n' +
        '      }\n' +
        '      invisible(NULL)\n' +
        '    }\n' +
        '    repeat {\n' +
        '      .m <- regexpr("\\\\{([^{}]+)\\\\}", .text, perl = TRUE)\n' +
        '      if (.m[[1L]] == -1L) break\n' +
        '      .start <- .m[[1L]]\n' +
        '      .len <- attr(.m, "match.length")\n' +
        '      .expr <- trimws(substr(.text, .start + 1L, .start + .len - 2L))\n' +
        '      .parsed <- tryCatch(\n' +
        '        parse(text = .expr, keep.source = FALSE),\n' +
        '        error = function(e) stop(paste0("Template expression {", .expr, "} failed: ", conditionMessage(e)), call. = FALSE)\n' +
        '      )\n' +
        '      if (length(.parsed) != 1L || !.is_safe_expr(.parsed[[1L]])) {\n' +
        '        stop(paste0("Template expression {", .expr, "} failed: disallowed syntax"), call. = FALSE)\n' +
        '      }\n' +
        '      .safe_env <- .make_safe()\n' +
        '      .bind_globals(.parsed[[1L]], .safe_env)\n' +
        '      .val <- tryCatch(\n' +
        '        eval(.parsed[[1L]], envir = .safe_env),\n' +
        '        error = function(e) stop(paste0("Template expression {", .expr, "} failed: ", conditionMessage(e)), call. = FALSE)\n' +
        '      )\n' +
        '      .text <- paste0(substr(.text, 1L, .start - 1L), .val, substr(.text, .start + .len, nchar(.text)))\n' +
        '    }\n' +
        '    if (grepl("[{}]", .text, perl = TRUE)) {\n' +
        '      stop("Template contains unresolved or malformed braces", call. = FALSE)\n' +
        '    }\n' +
        '    .text <- gsub(.l, "{", .text, fixed = TRUE)\n' +
        '    .text <- gsub(.r, "}", .text, fixed = TRUE)\n' +
        '    .text\n' +
        '  }\n' +
        '}\n');
}
function jsTemplateBootstrap() {
    return ('var __xeus_expand_template = globalThis.__xeus_expand_template || ((__s) => {\n' +
        '  const __l = "__XEUS_TPL_LBRACE__";\n' +
        '  const __r = "__XEUS_TPL_RBRACE__";\n' +
        '  function __xeus_lookup_namespace_value(__name) {\n' +
        '    const __dx = (globalThis && typeof globalThis.datax === "object" && globalThis.datax) ? globalThis.datax : null;\n' +
        '    if (!__dx) {\n' +
        '      return { found: false, value: undefined };\n' +
        '    }\n' +
        '    const __meta = (__dx.cell && typeof __dx.cell.metadata === "object" && __dx.cell.metadata) || {};\n' +
        '    const __langInfo = (__meta.language_info && typeof __meta.language_info === "object" && __meta.language_info) || {};\n' +
        '    const __jupyterlab = (__meta.jupyterlab && typeof __meta.jupyterlab === "object" && __meta.jupyterlab) || {};\n' +
        '    let __sourceLang = String(__meta.source_language || __langInfo.name || __jupyterlab.language || "").toLowerCase();\n' +
        '    if (__sourceLang === "py") __sourceLang = "python";\n' +
        '    if (__sourceLang === "js" || __sourceLang === "ts" || __sourceLang === "tsx" || __sourceLang === "typescript") __sourceLang = "javascript";\n' +
        '    const __order = [];\n' +
        '    if (__sourceLang) {\n' +
        '      __order.push(__sourceLang);\n' +
        '    }\n' +
        '    for (const __candidate of ["python", "r", "javascript"]) {\n' +
        '      if (!__order.includes(__candidate)) {\n' +
        '        __order.push(__candidate);\n' +
        '      }\n' +
        '    }\n' +
        '    for (const __bucketName of __order) {\n' +
        '      const __bucket = __dx[__bucketName];\n' +
        '      if (!__bucket || (typeof __bucket !== "object" && typeof __bucket !== "function")) {\n' +
        '        continue;\n' +
        '      }\n' +
        '      try {\n' +
        '        if (__name in __bucket) {\n' +
        '          return { found: true, value: __bucket[__name] };\n' +
        '        }\n' +
        '      } catch (_) {\n' +
        '      }\n' +
        '      const __vars = __bucket.vars;\n' +
        '      if (__vars && typeof __vars === "object" && Object.prototype.hasOwnProperty.call(__vars, __name)) {\n' +
        '        return { found: true, value: __vars[__name] };\n' +
        '      }\n' +
        '    }\n' +
        '    return { found: false, value: undefined };\n' +
        '  }\n' +
        '  let __text = String(__s).replace(/\\{\\{/g, __l).replace(/\\}\\}/g, __r);\n' +
        '  const __out = __text.replace(/\\{([^{}]+)\\}/g, (__all, __exprRaw) => {\n' +
        '    const __expr = String(__exprRaw).trim();\n' +
        '    try {\n' +
        '      let __v;\n' +
        '      if (/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(__expr) && !(__expr in globalThis)) {\n' +
        '        const __fallback = __xeus_lookup_namespace_value(__expr);\n' +
        '        if (__fallback.found) {\n' +
        '          __v = __fallback.value;\n' +
        '        } else {\n' +
        '          __v = (0, eval)(__expr);\n' +
        '        }\n' +
        '      } else {\n' +
        '        __v = (0, eval)(__expr);\n' +
        '      }\n' +
        '      return String(__v);\n' +
        '    } catch (__err) {\n' +
        '      throw new Error(`Template expression {${__expr}} failed: ${__err instanceof Error ? __err.message : String(__err)}`);\n' +
        '    }\n' +
        '  });\n' +
        '  if (/[{}]/.test(__out)) {\n' +
        '    throw new Error("Template contains unresolved or malformed braces");\n' +
        '  }\n' +
        '  return __out.replace(new RegExp(__l, "g"), "{").replace(new RegExp(__r, "g"), "}");\n' +
        '});\n' +
        'globalThis.__xeus_expand_template = __xeus_expand_template;\n' +
        'globalThis.__xeus_ensure_execution_results = typeof globalThis.__xeus_ensure_execution_results === "function" ? globalThis.__xeus_ensure_execution_results : (() => {\n' +
        '  const __results = globalThis["execution_results_last"];\n' +
        '  if (__results === null || (typeof __results !== "object" && typeof __results !== "function")) {\n' +
        '    globalThis["execution_results_last"] = {};\n' +
        '  }\n' +
        '  return globalThis["execution_results_last"];\n' +
        '});\n');
}
function jsLoweredCodeLogLines(loweredCode) {
    // Write debug log line (hidden from user — goes only to console)
    return 'globalThis._console?.log?.(\'' + escapeJsSingleQuotedString(loweredCode.trim()) + '\');\n';
}
function jsVisibleCodeLine(loweredCode) {
    const codeFence = '```javascript\n' + loweredCode.trim() + '\n```\n';
    return 'if (globalThis.dataxNow?.showAgentStatementInOutput === true) {\n' +
        '  (typeof (globalThis.datax?.display?.display_data ?? globalThis.displayData) === "function") ? void (globalThis.datax?.display?.display_data ?? globalThis.displayData)(' +
        '{ "text/markdown": ' + JSON.stringify(codeFence) + ' }, {}, {}) : void 0;\n' +
        '}\n';
}
/**
 * Build a reference to the shared execution results bucket for a given command/key name.
 * The generated code writes here so consumers can read `execution_results_last["cmd"]`.
 */
function execResultTarget(name) {
    return 'globalThis.__xeus_ensure_execution_results()["' + escapeString(name) + '"]';
}
function buildDisplayAgentArgs(cmd, lang, paramCount) {
    const argument = combinedAgentArgument(cmd);
    switch (paramCount) {
        case NO_PARAMS:
            return [];
        case SINGLE_PARAM:
            return [renderDisplayTemplate(argument, lang)];
        default:
            return [
                renderDisplayTemplate(cmd.pre_text, lang),
                renderDisplayTemplate(cmd.post_text, lang),
            ];
    }
}
export function generateAgentDisplayCodeForLanguage(cmd, lang) {
    let paramCount = cmd.param_count;
    if (paramCount === INVALID_FUNCTION)
        paramCount = SINGLE_PARAM;
    const args = buildDisplayAgentArgs(cmd, lang, paramCount);
    const alias = baseAgentAliasName(cmd.command);
    if (lang === 'python') {
        let code = '';
        if (cmd.is_expression) {
            code += 'agent_last = globals().get("agent_last", {})\n';
            code += 'agent_last["' + escapeString(cmd.command) + '"] = agenten("' +
                escapeString(cmd.command) + '", ' + renderDisplayTemplate(cmd.pre_text, 'python') +
                ', ' + renderDisplayTemplate(cmd.post_text, 'python') + ')\n';
            code += 'globals()["agent_last"] = agent_last\n';
            return code;
        }
        code += cmd.command + '_last = ' + cmd.command + '(' + joinArgs(args, ', ') + ')\n';
        if (alias && isSimpleIdentifier(alias)) {
            code += alias + '_last = ' + cmd.command + '_last\n';
        }
        return code;
    }
    if (lang === 'r') {
        let code = '';
        if (cmd.is_expression) {
            code += 'if (!exists("agent_last", envir = .GlobalEnv)) agent_last <- list()\n';
            code += 'agent_last[["' + escapeString(cmd.command) + '"]] <- agenten("' +
                escapeString(cmd.command) + '", ' + renderDisplayTemplate(cmd.pre_text, 'r') +
                ', ' + renderDisplayTemplate(cmd.post_text, 'r') + ')\n';
            return code;
        }
        code += cmd.command + '_last <- ' + cmd.command + '(' + joinArgs(args, ', ') + ')\n';
        if (alias && isSimpleIdentifier(alias)) {
            code += alias + '_last <- ' + cmd.command + '_last\n';
        }
        return code;
    }
    let code = jsTemplateBootstrap();
    if (cmd.is_expression) {
        code += 'agent_last["' + escapeString(cmd.command) + '"] = await agenten("' +
            escapeString(cmd.command) + '", ' + renderDisplayTemplate(cmd.pre_text, 'javascript') +
            ', ' + renderDisplayTemplate(cmd.post_text, 'javascript') + ');\n';
        code += execResultTarget(cmd.command) + ' = agent_last["' + escapeString(cmd.command) + '"];\n';
        return code;
    }
    const assignmentTarget = execResultTarget(cmd.command);
    code += assignmentTarget + ' = ' +
        (cmd.is_async ? 'await ' : '') +
        'globalThis["' + cmd.command + '"](' + joinArgs(args, ', ') + ');\n';
    if (alias && isSimpleIdentifier(alias)) {
        code += execResultTarget(alias) + ' = ' + assignmentTarget + ';\n';
    }
    return code;
}
/**
 * Generate code for a single agent command in a specific language.
 * Mirrors the C++ generate_agent_code_for_language() function.
 */
export function generateAgentCodeForLanguage(cmd, lang) {
    let paramCount = cmd.param_count;
    if (paramCount === INVALID_FUNCTION)
        paramCount = SINGLE_PARAM;
    const isAsync = cmd.is_async;
    const argument = combinedAgentArgument(cmd);
    const escapedArgument = '"' + escapeString(argument) + '"';
    if (lang === 'python') {
        const bootstrap = pythonTemplateBootstrap();
        const alias = baseAgentAliasName(cmd.command);
        if (cmd.is_expression) {
            const escapedExpr = escapeString(cmd.command);
            const escapedPreText = escapeString(cmd.pre_text);
            const escapedPostText = escapeString(cmd.post_text);
            return (bootstrap +
                'agent_last = globals().get("agent_last", {})\n' +
                'agent_last["' + escapedExpr + '"] = agenten("' +
                escapedExpr + '", __xeus_expand_template("' +
                escapedPreText + '"), __xeus_expand_template("' +
                escapedPostText + '"))\n' +
                'globals()["agent_last"] = agent_last\n');
        }
        else {
            const args = [];
            switch (paramCount) {
                case NO_PARAMS: break;
                case SINGLE_PARAM:
                    args.push('__xeus_expand_template(' + escapedArgument + ')');
                    break;
                default:
                    args.push('__xeus_expand_template("' + escapeString(cmd.pre_text) + '")');
                    args.push('__xeus_expand_template("' + escapeString(cmd.post_text) + '")');
                    break;
            }
            let code = bootstrap + cmd.command + '_last = ' + cmd.command + '(' + joinArgs(args, ', ') + ')\n';
            if (alias && isSimpleIdentifier(alias)) {
                code += alias + '_last = ' + cmd.command + '_last\n';
            }
            return code;
        }
    }
    else if (lang === 'r') {
        const bootstrap = rTemplateBootstrap();
        const alias = baseAgentAliasName(cmd.command);
        if (cmd.is_expression) {
            let code = bootstrap;
            code += 'if (!exists("agent_last", envir = .GlobalEnv)) agent_last <- list()\n';
            code += 'agent_last[["' + escapeString(cmd.command) + '"]] <- agenten("' +
                escapeString(cmd.command) + '", ';
            if (!cmd.pre_text) {
                code += '.xeus_expand_template(""), .xeus_expand_template("")';
            }
            else {
                code += '.xeus_expand_template("' + escapeString(cmd.pre_text) + '"), .xeus_expand_template("' + escapeString(cmd.post_text) + '")';
            }
            code += ')\n';
            return code;
        }
        else {
            const args = [];
            switch (paramCount) {
                case NO_PARAMS: break;
                case SINGLE_PARAM:
                    args.push('.xeus_expand_template(' + escapedArgument + ')');
                    break;
                default:
                    args.push('.xeus_expand_template("' + escapeString(cmd.pre_text) + '")');
                    args.push('.xeus_expand_template("' + escapeString(cmd.post_text) + '")');
                    break;
            }
            let code = bootstrap + cmd.command + '_last <- ' + cmd.command + '(' + joinArgs(args, ', ') + ')\n';
            if (alias && isSimpleIdentifier(alias)) {
                code += alias + '_last <- ' + cmd.command + '_last\n';
            }
            return code;
        }
    }
    else {
        // javascript
        const bootstrap = jsTemplateBootstrap();
        const alias = baseAgentAliasName(cmd.command);
        if (cmd.is_expression) {
            const escapedExpr = escapeString(cmd.command);
            const escapedPreText = escapeString(cmd.pre_text);
            const escapedPostText = escapeString(cmd.post_text);
            const loweredCall = 'agent_last["' + escapedExpr + '"] = await agenten("' +
                escapedExpr + '", __xeus_expand_template("' +
                escapedPreText + '"), __xeus_expand_template("' +
                escapedPostText + '"));';
            return (bootstrap +
                jsVisibleCodeLine(loweredCall) +
                jsLoweredCodeLogLines(loweredCall) +
                loweredCall + '\n' +
                execResultTarget(escapedExpr) + ' = agent_last["' + escapedExpr + '"];\n');
        }
        else {
            const args = [];
            switch (paramCount) {
                case NO_PARAMS: break;
                case SINGLE_PARAM:
                    args.push('__xeus_expand_template(' + escapedArgument + ')');
                    break;
                default:
                    args.push('__xeus_expand_template("' + escapeString(cmd.pre_text) + '")');
                    args.push('__xeus_expand_template("' + escapeString(cmd.post_text) + '")');
                    break;
            }
            let code = bootstrap;
            const resultVar = execResultTarget(cmd.command);
            const loweredCall = resultVar + ' = ' +
                (isAsync ? 'await ' : '') +
                'globalThis["' + cmd.command + '"](' + joinArgs(args, ', ') + ');';
            code += jsVisibleCodeLine(loweredCall);
            code += jsLoweredCodeLogLines(loweredCall);
            code += loweredCall + '\n';
            if (alias && isSimpleIdentifier(alias)) {
                code += execResultTarget(alias) + ' = ' + resultVar + ';\n';
            }
            return code;
        }
    }
}
/**
 * Generate a JS Promise.allSettled block for multiple async agent commands.
 * Mirrors the C++ generate_js_promise_all_block() function.
 */
export function generateJsPromiseAllBlock(asyncCmds) {
    if (asyncCmds.length <= 1) {
        return asyncCmds.map(cmd => generateAgentCodeForLanguage(cmd, 'javascript')).join('');
    }
    let code = '{\n';
    code += jsTemplateBootstrap();
    code += '  const __xeusAsyncResults = await Promise.allSettled([\n';
    for (let i = 0; i < asyncCmds.length; i++) {
        const cmd = asyncCmds[i];
        let paramCount = cmd.param_count;
        if (paramCount === INVALID_FUNCTION)
            paramCount = SINGLE_PARAM;
        const argument = combinedAgentArgument(cmd);
        const escapedArgument = '"' + escapeString(argument) + '"';
        const args = [];
        switch (paramCount) {
            case NO_PARAMS: break;
            case SINGLE_PARAM:
                args.push('__xeus_expand_template(' + escapedArgument + ')');
                break;
            default:
                args.push('__xeus_expand_template("' + escapeString(cmd.pre_text) + '")');
                args.push('__xeus_expand_template("' + escapeString(cmd.post_text) + '")');
                break;
        }
        const cmdLoweredCall = 'return await globalThis["' + cmd.command + '"](' + joinArgs(args, ', ') + ');';
        code += '    (async () => {\n';
        code += '      ' + jsVisibleCodeLine(cmdLoweredCall);
        code += '      ' + jsLoweredCodeLogLines(cmdLoweredCall);
        code += '      ' + cmdLoweredCall + '\n';
        code += '    })()';
        if (i + 1 < asyncCmds.length)
            code += ',';
        code += '\n';
    }
    code += '  ]);\n';
    for (let i = 0; i < asyncCmds.length; i++) {
        const cmd = asyncCmds[i];
        code += '  var ' + cmd.command + '_last = __xeusAsyncResults[' + i + '].status === \'fulfilled\' ' +
            '? __xeusAsyncResults[' + i + '].value : __xeusAsyncResults[' + i + '].reason;\n';
        // Write to shared execution results bucket
        code += '  ' + execResultTarget(cmd.command) + ' = ' + cmd.command + '_last;\n';
    }
    code += '}\n';
    return code;
}
/**
 * Generate code for a go-style command (pygo/jsgo/rgo) in a specific language.
 * Mirrors the C++ generate_go_code_for_language() function.
 */
export function generateGoCodeForLanguage(cmd, codeLang, goLang) {
    const argument = combinedAgentArgument(cmd);
    const escapedArgument = escapeString(argument);
    const escapedTarget = escapeString(cmd.command);
    let goFunction = 'pygo';
    if (goLang === 'r') {
        goFunction = 'rgo';
    }
    else if (goLang === 'javascript') {
        goFunction = 'jsgo';
    }
    if (codeLang === 'python') {
        let code = 'if \'datax\' in dir() and hasattr(datax, \'cell\'):\n';
        code += '    datax.cell.target = "' + escapedTarget + '"\n';
        code += '_xeus_go_metadata = {"cell": {"target": "' + escapedTarget + '"}}\n';
        code += '_xeus_go_result = ' + goFunction + '("' + escapedArgument + '", _xeus_go_metadata)\n';
        if (isSimpleIdentifier(cmd.command)) {
            code += cmd.command + '_go_last = _xeus_go_result\n';
        }
        code += 'agent_go_last = globals().get("agent_go_last", {})\n';
        code += 'agent_go_last["' + escapedTarget + '"] = _xeus_go_result\n';
        code += 'globals()["agent_go_last"] = agent_go_last\n';
        return code;
    }
    else if (codeLang === 'r') {
        let code = 'if (exists("datax", envir = .GlobalEnv)) { datax$cell$target <- "' +
            escapedTarget + '" }\n';
        code += '.xeus_go_metadata <- list(cell = list(target = "' + escapedTarget + '"))\n';
        code += '.xeus_go_result <- ' + goFunction + '("' + escapedArgument + '", .xeus_go_metadata)\n';
        if (isSimpleIdentifier(cmd.command)) {
            code += cmd.command + '_go_last <- .xeus_go_result\n';
        }
        code += 'if (!exists("agent_go_last", envir = .GlobalEnv)) agent_go_last <- list()\n';
        code += 'agent_go_last[["' + escapedTarget + '"]] <- .xeus_go_result\n';
        return code;
    }
    else {
        // javascript
        let code = jsTemplateBootstrap();
        code += 'if (typeof datax !== \'undefined\' && datax.cell) { datax.cell.target = "' +
            escapedTarget + '"; }\n';
        const useSmartAsk = Object.prototype.hasOwnProperty.call(cmd, 'system_prompt');
        // Use let so the second triggering of the same command can reassign without TypeError.
        code += 'let __xeusGoMetadata = ' +
            (useSmartAsk
                ? smartAskMetadataLiteral(escapedTarget)
                : '{ model: "", maxRetries: 5, cell: { target: "' + escapedTarget + '" } }') +
            ';\n';
        const resultTarget = execResultTarget(cmd.command);
        if (useSmartAsk) {
            const loweredCall = 'const __xeusGoResult = await __xeusSmartAsk("' +
                escapeString(smartAskUserArgument(cmd)) +
                '", { streaming: true, executionPolicy: \'ai\', metadata: __xeusGoMetadata, system_prompt: "' +
                escapeString(cmd.system_prompt ?? '') +
                '" });';
            code += jsVisibleCodeLine(loweredCall);
            code += jsLoweredCodeLogLines(loweredCall);
            code += 'if (typeof __xeus_x_ensure_ai_agents_loaded === "function") { await __xeus_x_ensure_ai_agents_loaded(); }\n';
            code += 'const __xeusSmartAsk = globalThis._dataxnow_?.smartAsk ?? globalThis.smartAsk;\n';
            code += 'if (typeof __xeusSmartAsk !== "function") { throw new Error("smartAsk is not available. Ensure the AI agents module is loaded."); }\n';
            code += loweredCall + ';\n';
            code += resultTarget + ' = __xeusGoResult;\n';
        }
        else {
            const loweredCall = 'const __xeusGoResult = await globalThis["' + goFunction + '"]("' +
                escapedArgument + '", __xeusGoMetadata);';
            code += jsVisibleCodeLine(loweredCall);
            code += jsLoweredCodeLogLines(loweredCall);
            code += loweredCall + '\n';
            code += resultTarget + ' = __xeusGoResult;\n';
            if (isSimpleIdentifier(cmd.command)) {
                code += 'globalThis["' + cmd.command + '_go_last"] = __xeusGoResult;\n';
            }
        }
        code += 'agent_go_last["' + escapedTarget + '"] = __xeusGoResult;';
        code += 'void 0;\n';
        code += '\n';
        return code;
    }
}
//# sourceMappingURL=agent-code-generators.js.map