import type { JSONObject } from '@lumino/coreutils';
import { type ExecutionCountGetter } from './result-factory.js';
import type { ICodeGoResult, IJupyterOutput, ILanguageProxy, IRunResult } from './code-commands-types.js';
import { LanguageType_Lowercase } from './utilities.js';
export interface IGeneratedCodeResult {
    status: 'ok' | 'error';
    generated?: string;
    detectedLanguage?: 'python' | 'javascript' | 'r';
}
export interface IRepairAttemptContext {
    command: string;
    requirement: string;
    currentCode: string;
    languageKey: 'python' | 'javascript' | 'r';
    languageType: LanguageType_Lowercase;
    proxy: ILanguageProxy;
    metadata: JSONObject;
    runResult: IRunResult;
    outputs: IJupyterOutput[];
}
export interface IExecuteGeneratedCodeOptions {
    genResult: IGeneratedCodeResult;
    command: string;
    requirement: string;
    languageKey: 'python' | 'javascript' | 'r';
    languageType: LanguageType_Lowercase;
    proxy: ILanguageProxy;
    metadata?: JSONObject;
    maxAttempts?: number;
    getExecutionCount?: ExecutionCountGetter;
    repairCode: (failure: IRepairAttemptContext) => Promise<string>;
}
export declare function buildRuntimeRepairCallback(options: {
    command: string;
    languageKey: 'python' | 'javascript' | 'r';
    languageType: LanguageType_Lowercase;
}): (failure: IRepairAttemptContext) => Promise<string>;
export declare function executeGeneratedCodeWithRetry(options: IExecuteGeneratedCodeOptions): Promise<ICodeGoResult>;
//# sourceMappingURL=go-execution.d.ts.map