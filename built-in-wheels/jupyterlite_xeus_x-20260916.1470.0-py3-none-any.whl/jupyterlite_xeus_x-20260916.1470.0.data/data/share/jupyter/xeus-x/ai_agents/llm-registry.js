/**
 * LLMRegistry — Multi-provider model registry for the Vercel AI SDK.
 *
 * Separates provider authentication (API keys, base URLs) from model usage.
 * All returned models are standard `LanguageModel` instances that work with
 * `generateText()`, `streamText()`, `tool()`, `ToolLoopAgent`, and every
 * other Vercel AI SDK function unchanged.
 *
 * @example
 * ```ts
 * import { generateText } from 'ai';
 * import { LLMRegistry } from './llm-registry';
 *
 * const registry = new LLMRegistry();
 *
 * // Configure providers (auth only — done once, e.g. at startup)
 * registry.registerProvider('openai', { apiKey: 'sk-...' });
 * registry.registerProvider('gemini', {
 *   apiKey: 'AIza...',
 *   baseURL: 'https://generativelanguage.googleapis.com/v1beta/openai/',
 * });
 * registry.registerProvider('claude', {
 *   apiKey: 'sk-ant-...',
 *   // Needs native Anthropic factory — see registerAnthropicFactory()
 * });
 *
 * // Multi-model workflow
 * const [r1, r2] = await Promise.all([
 *   generateText({ model: registry.model('openai/gpt-4o'), prompt: 'Review...' }),
 *   generateText({ model: registry.model('gemini/gemini-2.5-flash'), prompt: 'Review...' }),
 * ]);
 * const merged = await generateText({
 *   model: registry.model('claude/claude-sonnet-4-5'),
 *   prompt: `Merge:\n${r1.text}\n${r2.text}`,
 * });
 * ```
 */
import { getActiveProviderConfig, } from './llm-factory.js';
import { createOpenAICompatibleLanguageModel } from './openai-compatible.js';
// ---------------------------------------------------------------------------
// Built-in factories
// ---------------------------------------------------------------------------
/**
 * Default factory: treats any provider as OpenAI-compatible.
 *
 * Works directly for:
 * - OpenAI (native)
 * - Google Gemini (via `https://generativelanguage.googleapis.com/v1beta/openai/`)
 * - Any OpenAI-compatible proxy (LiteLLM, vLLM, Ollama, Azure)
 *
 * For Anthropic native API, supply a custom factory — see
 * `createAnthropicFactory()`.
 */
const openaiCompatibleFactory = (auth, modelName) => {
    return createOpenAICompatibleLanguageModel(auth, modelName);
};
/**
 * Multi-provider model registry.
 *
 * Register providers with their auth configs, then resolve models by
 * `"provider/model"` spec. Returned `LanguageModel` instances are usable
 * with every Vercel AI SDK function (`generateText`, `streamText`,
 * `ToolLoopAgent`, etc.) without modification.
 */
export class LLMRegistry {
    constructor() {
        this._providers = new Map();
        this._modelCache = new Map();
    }
    /**
     * Register a provider with its auth configuration.
     *
     * @param name    Short name, e.g. `'openai'`, `'gemini'`, `'claude'`.
     * @param auth    API key, base URL, and optional headers.
     * @param factory Optional model factory. Defaults to OpenAI-compatible.
     *
     * @example
     * registry.registerProvider('openai', { apiKey: 'sk-...' });
     * registry.registerProvider('gemini', {
     *   apiKey: 'AIza...',
     *   baseURL: 'https://generativelanguage.googleapis.com/v1beta/openai/',
     * });
     */
    registerProvider(name, auth, factory) {
        this._providers.set(name, {
            auth: {
                provider: auth.provider ?? name,
                ...auth,
            },
            factory: factory ?? openaiCompatibleFactory,
        });
        // Invalidate cached models for this provider.
        for (const key of this._modelCache.keys()) {
            if (key.startsWith(name + '/')) {
                this._modelCache.delete(key);
            }
        }
    }
    // -------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------
    /** Parse `"provider/model"` or bare `"model"` spec. */
    _parseSpec(spec) {
        const slashIdx = spec.indexOf('/');
        if (slashIdx === -1) {
            return { providerName: null, modelName: spec };
        }
        return {
            providerName: spec.slice(0, slashIdx) || null,
            modelName: spec.slice(slashIdx + 1),
        };
    }
    /** Pick the first registered provider as a fallback. */
    _pickFallback() {
        for (const [name, entry] of this._providers) {
            return { name, entry };
        }
        return null;
    }
    // -------------------------------------------------------------------
    // Model resolution
    // -------------------------------------------------------------------
    /**
     * Resolve a `LanguageModel` with runtime fallback.
     *
     * The spec is treated as a **preference** — the registry tries the
     * exact provider first, then falls through to any registered provider.
     *
     * Resolution order:
     * 1. `"provider/model"` — exact provider + model.
     * 2. Provider not registered — fall back to another registered
     *    provider using its `defaultModel` (if set) or the requested
     *    model name.
     * 3. Bare `"model"` (no slash) — first registered provider, using
     *    its `defaultModel` or the bare name.
     * 4. No providers at all — throws.
     *
     * @param spec  `"provider/model"` or bare `"model"` string.
     * @returns     A Vercel AI SDK `LanguageModel`.
     *
     * @example
     * // Exact match — openai is registered
     * registry.model('openai/gpt-4o')
     *
     * // Only gemini is registered at runtime — falls back to gemini
     * registry.model('openai/gpt-4o') // → uses gemini/gemini-2.5-flash
     *
     * // Bare model name — uses first registered provider
     * registry.model('gpt-4o')
     */
    model(spec) {
        const cached = this._modelCache.get(spec);
        if (cached)
            return cached;
        const { providerName, modelName } = this._parseSpec(spec);
        if (!modelName) {
            throw new Error(`Missing model name in spec "${spec}".`);
        }
        let resolvedEntry;
        let resolvedModelName;
        // (1) Try exact provider.
        const exact = providerName ? this._providers.get(providerName) : undefined;
        if (exact) {
            // Preferred path — exact provider.
            resolvedEntry = exact;
            resolvedModelName = modelName;
        }
        else {
            // (2/3) Fallback — pick any registered provider.
            const fallback = this._pickFallback();
            if (!fallback) {
                throw new Error('No providers registered in LLMRegistry. ' +
                    'Call registerProvider() before requesting a model.');
            }
            resolvedEntry = fallback.entry;
            resolvedModelName = fallback.entry.auth.defaultModel || modelName;
            if (providerName) {
                console.warn(`[LLMRegistry] Provider "${providerName}" not registered, ` +
                    `falling back to "${fallback.name}" with model "${resolvedModelName}"`);
            }
        }
        const lm = resolvedEntry.factory(resolvedEntry.auth, resolvedModelName);
        this._modelCache.set(spec, lm);
        return lm;
    }
    /**
     * Strict model resolution — no fallback.
     *
     * Throws if the exact provider is not registered.
     * Use when you need to guarantee a specific provider.
     *
     * @param spec  `"provider/model"` format (required).
     */
    modelStrict(spec) {
        const cached = this._modelCache.get(spec);
        if (cached)
            return cached;
        const { providerName, modelName } = this._parseSpec(spec);
        if (!providerName) {
            throw new Error(`modelStrict() requires "provider/model" format, got "${spec}".`);
        }
        if (!modelName) {
            throw new Error(`Missing model name in spec "${spec}".`);
        }
        const entry = this._providers.get(providerName);
        if (!entry) {
            const available = this.listProviders().join(', ') || '(none)';
            throw new Error(`Provider "${providerName}" not registered. Available: ${available}`);
        }
        const lm = entry.factory(entry.auth, modelName);
        this._modelCache.set(spec, lm);
        return lm;
    }
    /** Check if a provider is registered. */
    hasProvider(name) {
        return this._providers.has(name);
    }
    /** List registered provider names. */
    listProviders() {
        return Array.from(this._providers.keys());
    }
    /** Clear cached model instances (e.g. after key rotation). */
    clearCache() {
        this._modelCache.clear();
    }
    /** Remove a provider and its cached models. */
    removeProvider(name) {
        const deleted = this._providers.delete(name);
        if (deleted) {
            for (const key of this._modelCache.keys()) {
                if (key.startsWith(name + '/')) {
                    this._modelCache.delete(key);
                }
            }
        }
        return deleted;
    }
}
// ---------------------------------------------------------------------------
// Default (singleton) registry + convenience functions
// ---------------------------------------------------------------------------
let _defaultRegistry = null;
/** Get (or create) the default singleton registry. */
export function getDefaultRegistry() {
    if (!_defaultRegistry) {
        _defaultRegistry = new LLMRegistry();
    }
    return _defaultRegistry;
}
/**
 * Register a provider on the default registry.
 *
 * @example
 * registerProvider('openai', { apiKey: 'sk-...' });
 */
export function registerProvider(name, auth, factory) {
    getDefaultRegistry().registerProvider(name, auth, factory);
}
/**
 * Resolve a model from the default registry (with runtime fallback).
 *
 * @example
 * import { generateText } from 'ai';
 * const result = await generateText({ model: model('openai/gpt-4o'), prompt: '...' });
 */
export function model(spec) {
    return getDefaultRegistry().model(spec);
}
/**
 * Resolve a model strictly (no fallback) from the default registry.
 */
export function modelStrict(spec) {
    return getDefaultRegistry().modelStrict(spec);
}
// ---------------------------------------------------------------------------
// Bridge: auto-populate from window.jupyter_ai
// ---------------------------------------------------------------------------
/**
 * Populate the registry with the active `window.jupyter_ai` provider.
 *
 * Bridges the existing JupyterLite AI configuration into the registry so
 * existing code can migrate incrementally.
 *
 * @param registry  Registry to populate (defaults to the singleton).
 * @param alias     Provider name to register under (defaults to `'default'`).
 */
export function registerFromJupyterAI(registry, alias = 'default') {
    const r = registry ?? getDefaultRegistry();
    const config = getActiveProviderConfig();
    if (!config)
        return false;
    r.registerProvider(alias, {
        provider: config.provider,
        apiKey: config.apiKey,
        baseURL: config.baseURL,
        headers: config.headers,
        defaultModel: config.model,
    });
    return true;
}
// ---------------------------------------------------------------------------
// Native provider factory helpers
// ---------------------------------------------------------------------------
/**
 * Create a factory for `@ai-sdk/anthropic`.
 *
 * Pass the `createAnthropic` function from the `@ai-sdk/anthropic` package.
 * This avoids a hard dependency — the caller must install the package.
 *
 * @example
 * import { createAnthropic } from '@ai-sdk/anthropic';
 * registry.registerProvider('claude', { apiKey: 'sk-ant-...' },
 *   createNativeFactory(createAnthropic));
 */
export function createNativeFactory(createFn) {
    return (auth, modelName) => {
        const provider = createFn({
            ...(auth.apiKey && { apiKey: auth.apiKey }),
            ...(auth.baseURL && { baseURL: auth.baseURL }),
            ...(auth.headers && { headers: auth.headers }),
        });
        return provider(modelName);
    };
}
// Re-export the default factory for users who want to compose their own.
export { openaiCompatibleFactory };
//# sourceMappingURL=llm-registry.js.map