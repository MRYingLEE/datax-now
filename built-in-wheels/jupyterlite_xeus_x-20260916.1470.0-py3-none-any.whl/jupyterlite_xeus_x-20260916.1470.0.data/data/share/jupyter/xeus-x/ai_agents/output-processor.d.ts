import { LanguageType_Lowercase } from './utilities.js';
/**
 * Transforms a JSON object or array according to specific rules.
 * Standalone pure function.
 * @param json - The input JSON value to transform
 * @returns The transformed JSON value
 */
export declare function compressOutput(json: any): any;
/**
 * Utility methods for wrapping content.
 * Standalone pure function.
 */
export declare function wrapCode(code: string, language: LanguageType_Lowercase | string): string;
/**
 * Wrap content for notebook markdown display, normalizing any pre-existing
 * fence so the display never nests duplicate language fences.
 */
export declare function wrapCodeForDisplay(code: string, language: LanguageType_Lowercase | string, closeFence?: boolean): string;
/**
 * Standalone pure function.
 */
export declare function wrapJSON(j: string): string;
/**
 * Standalone pure function.
 */
export declare function wrapSection(content: string, sectionName?: string): string;
/**
 * Standalone pure function.
 */
export declare function customTrim(str: string): string;
/**
 * Standalone pure function.
 */
export declare function convertToString(preview: any): string;
/**
 * Extract code from markdown content.
 * Extracts the last fenced code block from markdown.
 * Standalone pure function.
 */
export declare function extractCode(markdownContent: string): string;
//# sourceMappingURL=output-processor.d.ts.map