import type { CallWarning, FinishReason, LanguageModelUsage } from 'ai';
export type SharedAIErrorName = 'ProviderAuthError' | 'ProviderError' | 'TimeoutError' | 'AbortError' | 'RuntimeError';
export type SharedAIError = {
    ename: SharedAIErrorName;
    evalue: string;
    traceback?: string[];
};
export type SharedServiceErrorType = 'ProviderAuthError' | 'ProviderError' | 'TimeoutError' | 'AbortError' | 'RuntimeError';
export interface ISharedServiceError {
    type: SharedServiceErrorType;
    message: string;
    retryable: boolean;
}
export type SharedAIResultMetadata = {
    finishReason?: FinishReason;
    usage?: LanguageModelUsage;
    warnings?: CallWarning[];
};
export declare function normalizeAIError(error: unknown): SharedAIError;
export declare function normalizeServiceError(error: unknown): ISharedServiceError;
export declare function getErrorStatusInfo(error: unknown): {
    message: string;
    status: number | undefined;
    name: string;
};
//# sourceMappingURL=ai-error-utils.d.ts.map