import { createOpenAI } from '@ai-sdk/openai';
import { GENAI_INITIAL_429_RETRY_DELAY_MS, GENAI_MAX_429_RETRIES, GENAI_MAX_429_RETRY_DELAY_MS, } from './genai-retry.js';
// Not exported from package root today, but kept here as the shared default
// across the factory and registry layers.
export const DUMMY_API_KEY = 'sk-no-key-required';
export function isNonEmptyString(value) {
    return typeof value === 'string' && value.trim().length > 0;
}
function hasUserSuppliedAuthHeader(headers) {
    if (!headers) {
        return false;
    }
    for (const [key, value] of Object.entries(headers)) {
        if (key.toLowerCase() === 'authorization' && isNonEmptyString(value)) {
            return true;
        }
    }
    return false;
}
class RateLimitRetryError extends Error {
    constructor() {
        super(`HTTP 429 persisted after ${GENAI_MAX_429_RETRIES} retries`);
        this.statusCode = 429;
        this.name = 'RateLimitRetryError';
    }
}
function get429RetryDelay(response, retryNumber) {
    const retryAfter = response.headers.get('Retry-After');
    if (retryAfter !== null) {
        const seconds = Number(retryAfter);
        const delay = Number.isFinite(seconds)
            ? seconds * 1000
            : Date.parse(retryAfter) - Date.now();
        if (Number.isFinite(delay) && delay >= 0) {
            return Math.min(delay, GENAI_MAX_429_RETRY_DELAY_MS);
        }
    }
    return Math.min(GENAI_INITIAL_429_RETRY_DELAY_MS * 2 ** (retryNumber - 1), GENAI_MAX_429_RETRY_DELAY_MS);
}
function sleepWithAbort(delayMs, signal) {
    if (signal?.aborted) {
        return Promise.reject(signal.reason ?? new DOMException('The operation was aborted.', 'AbortError'));
    }
    return new Promise((resolve, reject) => {
        const timeout = setTimeout(finish, delayMs);
        function finish() {
            signal?.removeEventListener('abort', abort);
            resolve();
        }
        function abort() {
            clearTimeout(timeout);
            signal?.removeEventListener('abort', abort);
            reject(signal?.reason ?? new DOMException('The operation was aborted.', 'AbortError'));
        }
        signal?.addEventListener('abort', abort, { once: true });
    });
}
export function createCompatibleFetch(options = {}) {
    const STRIP_KEYS = ['stream_options'];
    const stripUnsupportedOptions = options.stripUnsupportedOptions ?? true;
    return async (input, init) => {
        if (stripUnsupportedOptions
            && init?.method?.toUpperCase() === 'POST'
            && typeof init.body === 'string') {
            try {
                const json = JSON.parse(init.body);
                let modified = false;
                for (const key of STRIP_KEYS) {
                    if (key in json) {
                        delete json[key];
                        modified = true;
                    }
                }
                if (modified) {
                    init = { ...init, body: JSON.stringify(json) };
                }
            }
            catch {
                // Body isn't JSON — pass through untouched.
            }
        }
        for (let retryNumber = 0;; retryNumber++) {
            const response = await fetch(input, init);
            if (response.status !== 429) {
                return response;
            }
            if (retryNumber >= GENAI_MAX_429_RETRIES) {
                await response.body?.cancel();
                throw new RateLimitRetryError();
            }
            const delayMs = get429RetryDelay(response, retryNumber + 1);
            await response.body?.cancel();
            await sleepWithAbort(delayMs, init?.signal);
        }
    };
}
export function createCompatibleFetchWithAuthBehavior(options) {
    const baseFetch = createCompatibleFetch({
        stripUnsupportedOptions: options?.stripUnsupportedOptions,
    });
    return async (input, init) => {
        if (options?.stripAuthorization && init?.headers) {
            const headers = new Headers(init.headers);
            headers.delete('authorization');
            headers.delete('Authorization');
            init = { ...init, headers };
        }
        return baseFetch(input, init);
    };
}
export function buildOpenAICompatibleProviderOptions(config) {
    const hasExplicitApiKey = isNonEmptyString(config.apiKey);
    const apiKey = hasExplicitApiKey ? config.apiKey : DUMMY_API_KEY;
    const hasExplicitAuthHeader = hasUserSuppliedAuthHeader(config.headers);
    const providerOptions = {
        apiKey,
    };
    if (isNonEmptyString(config.baseURL)) {
        providerOptions.baseURL = config.baseURL;
    }
    if (config.headers && Object.keys(config.headers).length > 0) {
        providerOptions.headers = config.headers;
    }
    providerOptions.fetch = createCompatibleFetchWithAuthBehavior({
        stripAuthorization: config.provider !== 'openai' && !hasExplicitApiKey && !hasExplicitAuthHeader,
        stripUnsupportedOptions: config.provider !== 'openai',
    });
    return providerOptions;
}
export function createOpenAICompatibleLanguageModel(config, modelName) {
    const provider = createOpenAI(buildOpenAICompatibleProviderOptions(config));
    return provider.chat(modelName);
}
export function createOpenAICompatibleEmbeddingModel(config, modelName) {
    const provider = createOpenAI(buildOpenAICompatibleProviderOptions(config));
    return provider.embeddingModel(modelName);
}
//# sourceMappingURL=openai-compatible.js.map