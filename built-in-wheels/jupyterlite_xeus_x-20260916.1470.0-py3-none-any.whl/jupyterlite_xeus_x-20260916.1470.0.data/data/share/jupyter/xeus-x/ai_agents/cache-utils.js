import { DisplayAdapter } from './display-adapter.js';
import { createLogger } from './logger.js';
import { extractFencedBlocks, normalizeFenceLanguage } from './utilities.js';
const MAX_RUNTIME_REPLAY_ENTRIES = 200;
const runtimeReplayStore = new Map();
const { diagnostic: _diag } = createLogger('[AI_Agents]');
function consumeClearedOutputMarker(cellId) {
    if (!cellId) {
        return false;
    }
    try {
        const g = globalThis;
        const windowLike = g?.window ?? g;
        const clearedOutputCellIds = windowLike?.dataxNow?.aiReplay?.clearedOutputCellIds
            ?? g?.dataxNow?.aiReplay?.clearedOutputCellIds;
        if (clearedOutputCellIds instanceof Set) {
            return clearedOutputCellIds.delete(cellId);
        }
    }
    catch {
        // Ignore lookup failures and treat as no explicit clear marker.
    }
    return false;
}
function makeRuntimeReplayKey(options) {
    return JSON.stringify([
        options.cellId,
        options.requestType,
        normalizePrompt(options.requirement),
        options.detectedLanguage ?? '',
        normalizePackageConstraints(options.packageConstraints),
    ]);
}
function normalizePackageConstraints(packageConstraints) {
    return {
        required: [...new Set(packageConstraints?.required ?? [])].sort(),
        optional: [...new Set(packageConstraints?.optional ?? [])].sort(),
        prohibited: [...new Set(packageConstraints?.prohibited ?? [])].sort(),
    };
}
export function getRuntimeGenCache(options) {
    if (options.replayAllowed === false || !options.cellId) {
        _diag('[diag][runtime-cache] skip lookup', {
            requestType: options.requestType,
            cellId: options.cellId ?? '',
            replayAllowed: options.replayAllowed ?? 'unset',
            normalizedRequirement: normalizePrompt(options.requirement),
            detectedLanguage: options.detectedLanguage ?? '',
        });
        return null;
    }
    const key = makeRuntimeReplayKey({
        cellId: options.cellId,
        requestType: options.requestType,
        requirement: options.requirement,
        detectedLanguage: options.detectedLanguage,
        packageConstraints: options.packageConstraints,
    });
    const entry = runtimeReplayStore.get(key);
    if (!entry || typeof entry.generated !== 'string' || entry.generated.trim().length === 0) {
        if (entry) {
            runtimeReplayStore.delete(key);
        }
        _diag('[diag][runtime-cache] miss', {
            requestType: options.requestType,
            cellId: options.cellId,
            key,
            storeSize: runtimeReplayStore.size,
        });
        return null;
    }
    if (consumeClearedOutputMarker(options.cellId)) {
        _diag('[diag][runtime-cache] invalidated by cleared output marker', {
            requestType: options.requestType,
            cellId: options.cellId,
            key,
        });
        clearRuntimeGenCache(options);
        return null;
    }
    _diag('[diag][runtime-cache] hit', {
        requestType: options.requestType,
        cellId: options.cellId,
        key,
        displayCount: entry.displayData.length,
    });
    return {
        cached: true,
        generated: entry.generated,
        displayData: entry.displayData,
    };
}
export function clearRuntimeGenCache(options) {
    if (!options.cellId) {
        return;
    }
    const key = makeRuntimeReplayKey({
        cellId: options.cellId,
        requestType: options.requestType,
        requirement: options.requirement,
        detectedLanguage: options.detectedLanguage,
        packageConstraints: options.packageConstraints,
    });
    runtimeReplayStore.delete(key);
    _diag('[diag][runtime-cache] cleared entry', {
        requestType: options.requestType,
        cellId: options.cellId,
        key,
        storeSize: runtimeReplayStore.size,
    });
}
export function setRuntimeGenCache(options) {
    if (!options.cellId || !options.generated) {
        _diag('[diag][runtime-cache] skip store', {
            requestType: options.requestType,
            cellId: options.cellId ?? '',
            hasGenerated: !!options.generated,
            displayCount: options.displayData.length,
        });
        return;
    }
    const key = makeRuntimeReplayKey({
        cellId: options.cellId,
        requestType: options.requestType,
        requirement: options.requirement,
        detectedLanguage: options.detectedLanguage,
        packageConstraints: options.packageConstraints,
    });
    // Evict oldest entry when at capacity
    if (!runtimeReplayStore.has(key) && runtimeReplayStore.size >= MAX_RUNTIME_REPLAY_ENTRIES) {
        const oldestKey = runtimeReplayStore.keys().next().value;
        if (oldestKey !== undefined) {
            runtimeReplayStore.delete(oldestKey);
        }
    }
    runtimeReplayStore.set(key, {
        generated: options.generated,
        displayData: options.displayData,
    });
    _diag('[diag][runtime-cache] stored entry', {
        requestType: options.requestType,
        cellId: options.cellId,
        key,
        displayCount: options.displayData.length,
        storeSize: runtimeReplayStore.size,
    });
}
export function normalizePrompt(prompt) {
    let text = String(prompt ?? '').trim();
    if (!text) {
        return '';
    }
    while (true) {
        const match = text.match(/^@[\w-]+(?:\s+|$)/);
        if (!match) {
            break;
        }
        text = text.slice(match[0].length).trim();
    }
    return text;
}
/**
 * Determine whether a cached source tag is compatible with the current request type.
 *
 * **Design principles:**
 * - `*gen` agents (pygen, jsgen, rgen) are compatible with their `*go` counterparts
 *   because both generate code for the same language.
 * - `go` (auto-detect) is compatible with ALL language-specific `*go` agents
 *   (`pygo`, `jsgo`, `rgo`) when the detected language matches, because `@variable`
 *   patterns (e.g. `@df_iris`) route through the C++ kernel as language-specific
 *   `*go` calls, but semantically they are variants of `go` (auto-detect).
 * - `wildgen` / `wildgo` are only compatible with each other because they handle
 *   mixed-language output which cannot be meaningfully cross-matched.
 *
 * **Compatibility matrix (requestType → allowed cached sources):**
 *
 * | Request | Compatible cached sources | Notes |
 * |---------|--------------------------|-------|
 * | `pygen` | `pygen`, `pygo` | Gen can replay go-produced code |
 * | `jsgen` | `jsgen`, `jsgo` | Same |
 * | `rgen`  | `rgen`, `rgo` | Same |
 * | `gen`   | `gen`, `go` | Pure auto-detect only |
 * | `wildgen` | `wildgen`, `wildgo` | Mixed-language only |
 * | `pygo`  | `pygo`, `pygen`, `go` | Go-produced code reusable if language matches |
 * | `jsgo`  | `jsgo`, `jsgen`, `go` | Same |
 * | `rgo`   | `rgo`, `rgen`, `go` | Same |
 * | `go`    | `go`, `pygo`, `jsgo`, `rgo`, `pygen`, `jsgen`, `rgen` | Auto-detect can reuse any language-specific cache |
 * | `wildgo` | `wildgo`, `wildgen` | Mixed-language only |
 */
export function isSourceCompatible(requestType, cachedSource, requestDetectedLanguage, cachedDetectedLanguage) {
    // Map each request type to the set of compatible cached sources.
    // The 'go' entry is deliberately broad: auto-detect should be able to
    // reuse cache produced by any language-specific *go or *gen agent,
    // provided the detected language matches.
    const compatibleSources = {
        pygen: ['pygen', 'pygo'],
        jsgen: ['jsgen', 'jsgo'],
        rgen: ['rgen', 'rgo'],
        gen: ['gen', 'go'],
        wildgen: ['wildgen', 'wildgo'],
        pygo: ['pygo', 'pygen', 'go'],
        jsgo: ['jsgo', 'jsgen', 'go'],
        rgo: ['rgo', 'rgen', 'go'],
        go: ['go', 'pygo', 'jsgo', 'rgo', 'pygen', 'jsgen', 'rgen'],
        wildgo: ['wildgo', 'wildgen'],
    };
    const allowed = compatibleSources[requestType];
    if (!allowed || !allowed.includes(cachedSource)) {
        return false;
    }
    // For auto-detect (@gen / @go), both detected languages must match.
    // For @go requesting a cached @pygo/@jsgo/@rgo entry, the cached entry's
    // detected language must match the current request's detected language.
    if (requestType === 'gen' || requestType === 'go') {
        return !!requestDetectedLanguage
            && !!cachedDetectedLanguage
            && requestDetectedLanguage === cachedDetectedLanguage;
    }
    // For @pygo / @jsgo / @rgo requesting a cached @go entry, the detected
    // languages must match (the cached @go entry already knows the language).
    if (cachedSource === 'go') {
        return !!requestDetectedLanguage
            && !!cachedDetectedLanguage
            && requestDetectedLanguage === cachedDetectedLanguage;
    }
    return true;
}
function inferSourceFromPrompt(prompt) {
    const trimmed = String(prompt ?? '').trim();
    if (!trimmed.startsWith('@')) {
        return undefined;
    }
    const token = trimmed.split(/\s+/, 1)[0].replace(/^@/, '').toLowerCase();
    switch (token) {
        case 'pygen':
        case 'jsgen':
        case 'rgen':
        case 'gen':
        case 'wildgen':
        case 'pygo':
        case 'jsgo':
        case 'tsgo':
        case 'rgo':
        case 'go':
        case 'wildgo':
            return token;
        default:
            return undefined;
    }
}
// normalizeFenceLanguage and extractFencedBlocks are imported from utilities.ts
function extractCodeFromMarkdown(markdown, targetLanguage) {
    if (!markdown) {
        return null;
    }
    const blocks = extractFencedBlocks(markdown);
    if (blocks.length === 0) {
        return null;
    }
    if (!targetLanguage) {
        return blocks[blocks.length - 1].code.trim();
    }
    const normalizedTarget = normalizeFenceLanguage(targetLanguage);
    let lastMatch = null;
    for (const block of blocks) {
        const normalized = normalizeFenceLanguage(block.language);
        if (normalized === normalizedTarget) {
            lastMatch = block.code.trim();
        }
    }
    return lastMatch;
}
function isWidgetViewData(data) {
    if (!data || typeof data !== 'object') {
        return false;
    }
    // Jupyter widget views reference kernel-side state by model_id. Re-emitting
    // them on cache replay re-instantiates the same widget alongside any
    // image/png/text rendering that was already captured, which visually
    // duplicates the widget's content (e.g. a matplotlib chart). Such items
    // must never be part of cached display replay.
    for (const key of Object.keys(data)) {
        if (key.startsWith('application/vnd.jupyter.widget-view')) {
            return true;
        }
    }
    return false;
}
function getDisplayDataOutputs(outputModel) {
    if (!Array.isArray(outputModel)) {
        return [];
    }
    return outputModel.filter((item) => item &&
        typeof item === 'object' &&
        (!item.output_type || item.output_type === 'display_data' || item.output_type === 'update_display_data') &&
        !!item.data &&
        !isWidgetViewData(item.data));
}
function hasErrorResult(lastExecuteIO) {
    if (lastExecuteIO?.status === 'error') {
        return true;
    }
    const er = lastExecuteIO?.execution_result;
    if (!er || typeof er !== 'object') {
        return false;
    }
    return (er.status && er.status !== 'ok')
        || !!er.ename
        || !!er.evalue
        || (Array.isArray(er.traceback) && er.traceback.length > 0);
}
function getMarkdownFromData(data) {
    if (!data) {
        return null;
    }
    const value = data['text/markdown'] ?? data['text/plain'];
    return typeof value === 'string' ? value : null;
}
function resolveTargetLanguage(requestType, detectedLanguage) {
    const languageMap = {
        pygen: 'python',
        jsgen: 'javascript',
        rgen: 'r',
        gen: detectedLanguage,
        pygo: 'python',
        jsgo: 'javascript',
        rgo: 'r',
        // For @go, fall back to the cached entry's detected language when
        // the request itself has no detected language (e.g. @variable → pygo
        // path where the requirement text doesn't contain language hints).
        go: detectedLanguage,
    };
    return languageMap[requestType];
}
export function checkGenCache(options) {
    // Replay is opt-out: if the frontend explicitly sets replayAllowed to false
    // (e.g. user cleared outputs before re-running), skip the cache.
    // When replayAllowed is undefined (metadata not delivered), allow replay
    // as long as lastExecuteIO data is available — the prompt and source
    // matching checks below already guard against stale/mismatched entries.
    if (options.replayAllowed === false) {
        return null;
    }
    const lastExecuteIO = typeof options.lastExecuteIO === 'object' && options.lastExecuteIO !== null
        ? options.lastExecuteIO
        : null;
    if (!lastExecuteIO || hasErrorResult(lastExecuteIO)) {
        return null;
    }
    const outputModel = getDisplayDataOutputs(lastExecuteIO.output_model);
    if (outputModel.length === 0) {
        return null;
    }
    const normalizedRequirement = normalizePrompt(options.requirement);
    if (!normalizedRequirement) {
        return null;
    }
    const displayMatches = [];
    let generated = '';
    for (const item of outputModel) {
        const metadata = item.metadata ?? {};
        // Only use explicit item-level metadata for matching — never fall back to the
        // cell-level prompt.  Without this guard, plain chart/figure outputs (which
        // carry no metadata.source / metadata.prompt) would inherit the cell prompt
        // via inferredPrompt and be incorrectly included in the replay, producing a
        // duplicate chart on every re-execution (the fix for that bug).
        const metadataPrompt = typeof metadata.prompt === 'string' ? metadata.prompt : '';
        const promptCandidate = metadataPrompt; // explicit item metadata only
        const normalizedPromptCandidate = normalizePrompt(promptCandidate);
        const source = metadata.source; // explicit only
        const cachedDetectedLanguage = metadata.detectedLanguage;
        if (!source) {
            continue;
        }
        if (normalizedPromptCandidate.length === 0) {
            continue;
        }
        if (normalizedPromptCandidate !== normalizedRequirement) {
            continue;
        }
        if (!isSourceCompatible(options.requestType, source, options.detectedLanguage, cachedDetectedLanguage)) {
            continue;
        }
        const displayId = typeof item.transient?.display_id === 'string'
            ? item.transient.display_id
            : undefined;
        if (displayId && item.output_type === 'update_display_data') {
            const previousIndex = displayMatches.findIndex((match) => match.transient?.display_id === displayId);
            if (previousIndex >= 0) {
                displayMatches[previousIndex] = item;
            }
            else {
                displayMatches.push(item);
            }
        }
        else {
            displayMatches.push(item);
        }
        const markdown = getMarkdownFromData(item.data);
        if (!markdown) {
            continue;
        }
        if (options.requestType === 'wildgen' || options.requestType === 'wildgo') {
            generated = markdown.trim();
            continue;
        }
        const targetLanguage = resolveTargetLanguage(options.requestType, options.detectedLanguage);
        const extracted = extractCodeFromMarkdown(markdown, targetLanguage);
        if (extracted) {
            generated = extracted;
        }
    }
    if (!generated || displayMatches.length === 0) {
        return null;
    }
    return {
        cached: true,
        generated,
        displayData: displayMatches,
    };
}
function isGeneratedCodeDisplay(item) {
    if (!item || typeof item !== 'object') {
        return false;
    }
    const metadata = item.metadata ?? {};
    const source = typeof metadata.source === 'string' ? metadata.source : '';
    if (!source) {
        return false;
    }
    const markdown = getMarkdownFromData(item.data);
    if (!markdown) {
        return false;
    }
    const targetLanguage = resolveTargetLanguage(source, metadata.detectedLanguage) || undefined;
    const extracted = extractCodeFromMarkdown(markdown, targetLanguage);
    return !!extracted && extracted.length > 0;
}
function dedupeReplayDisplayData(items) {
    if (!Array.isArray(items) || items.length < 2) {
        return Array.isArray(items) ? items : [];
    }
    const deduped = [];
    const seenGeneratedDisplayKeys = new Set();
    for (const item of items) {
        if (!isGeneratedCodeDisplay(item)) {
            deduped.push(item);
            continue;
        }
        const metadata = item.metadata ?? {};
        const key = JSON.stringify([
            metadata.source ?? '',
            metadata.prompt ?? '',
            metadata.detectedLanguage ?? '',
            item.transient?.display_id ?? '',
            item.data?.['text/markdown'] ?? item.data?.['text/plain'] ?? '',
        ]);
        if (seenGeneratedDisplayKeys.has(key)) {
            continue;
        }
        seenGeneratedDisplayKeys.add(key);
        deduped.push(item);
    }
    return deduped;
}
export function replayDisplayData(items) {
    if (!items || items.length === 0) {
        return;
    }
    const replayItems = dedupeReplayDisplayData(items);
    if (replayItems.length === 0) {
        return;
    }
    const g = globalThis;
    const displayData = g?.datax?.display?.display_data ?? g?.display_data;
    const updateDisplayData = g?.datax?.display?.update_display_data ?? g?.update_display_data;
    if (typeof displayData === 'function' || typeof updateDisplayData === 'function') {
        for (const item of replayItems) {
            const replay = item.output_type === 'update_display_data' && typeof updateDisplayData === 'function'
                ? updateDisplayData
                : displayData;
            if (typeof replay === 'function') {
                replay(item.data ?? {}, item.metadata ?? {}, item.transient ?? {});
            }
        }
        return;
    }
    for (const item of replayItems) {
        const markdown = getMarkdownFromData(item.data ?? {});
        if (typeof markdown === 'string') {
            DisplayAdapter.markdown(markdown, { metadata: item.metadata ?? {} });
        }
    }
}
//# sourceMappingURL=cache-utils.js.map