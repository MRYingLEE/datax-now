/**
 * Cell AI_Agents Context — shared type for metadata injected by C++ into
 * `globalThis.datax.cell` before every execution.
 *
 * C++ sets `datax.cell.metadata` (execute_request metadata including lastExecuteIO),
 * `datax.cell.exec_metadata` (stable snapshot for post-exec work),
 * `datax.cell.execution_count`, and `datax.cell.id` via emscripten::val before
 * dispatching generated code to sub-kernels.
 *
 * This module provides typed access to that context, eliminating the need for
 * metadata parameter passing through the bridge layer.
 */
import { toPlainObject } from './display/display.js';
import { createLogger } from './logger.js';
const { diagnostic: _diag } = createLogger('[AI_Agents]');
const RESOLVED_METADATA_FLAG = '__xeusResolvedMetadata';
const CANONICAL_LANGUAGE_IDS = new Set([
    'python',
    'javascript',
    'typescript',
    'r',
    'markdown',
    'sql',
    'ai',
]);
function normalizeCanonicalLanguageId(value) {
    if (typeof value !== 'string') {
        return '';
    }
    const normalized = value.trim().toLowerCase();
    if (!normalized) {
        return '';
    }
    if (normalized === 'py') {
        return 'python';
    }
    if (normalized === 'js') {
        return 'javascript';
    }
    if (normalized === 'ts' || normalized === 'tsx') {
        return 'typescript';
    }
    if (normalized === 'md' || normalized === 'plain' || normalized === 'plaintext' || normalized === 'text') {
        return 'markdown';
    }
    return CANONICAL_LANGUAGE_IDS.has(normalized) ? normalized : '';
}
function normalizeLastExecuteIO(lastExecuteIO) {
    if (!lastExecuteIO) {
        return undefined;
    }
    const normalized = { ...lastExecuteIO };
    const canonicalLanguage = normalizeCanonicalLanguageId(normalized.code_language);
    if (canonicalLanguage) {
        normalized.code_language = canonicalLanguage;
    }
    return normalized;
}
/**
 * Read the current execution metadata snapshot from `globalThis.datax.cell.exec_metadata`.
 * This is injected by C++ (via emscripten::val for JS, Python code for Python,
 * R code for R) before every execution.
 *
 * @returns The execute_request metadata object, or undefined if unavailable.
 */
export function readCellMetadata() {
    try {
        const g = globalThis;
        const cell = g?.datax?.cell;
        const normalizeMeta = (meta) => {
            if (!meta) {
                return undefined;
            }
            if (typeof meta === 'string') {
                try {
                    const parsed = JSON.parse(meta);
                    return normalizeMeta(parsed);
                }
                catch {
                    return undefined;
                }
            }
            if (typeof meta === 'object' && !Array.isArray(meta)) {
                // Try toJSON() first - custom serialization should take precedence
                const maybeToJson = meta.toJSON;
                if (typeof maybeToJson === 'function') {
                    try {
                        const serialized = maybeToJson.call(meta);
                        if (serialized && serialized !== meta) {
                            const normalized = normalizeMeta(serialized);
                            if (normalized) {
                                return normalized;
                            }
                        }
                    }
                    catch {
                        // Ignore toJSON errors and fall back to plain-object handling
                    }
                }
                // Fall back to plain object extraction
                const plain = toPlainObject(meta);
                if (Object.keys(plain).length > 0) {
                    return plain;
                }
            }
            return undefined;
        };
        const execMeta = normalizeMeta(cell?.exec_metadata);
        if (execMeta) {
            return execMeta;
        }
        const meta = normalizeMeta(cell?.metadata);
        if (meta) {
            return meta;
        }
    }
    catch {
        // silently ignore
    }
    return undefined;
}
/**
 * Extract `lastExecuteIO` from cell metadata.
 *
 * The execute_request metadata may contain `lastExecuteIO` directly,
 * or the metadata itself may act as lastExecuteIO when it has
 * `prompt` + `output_model`/`code` fields.
 *
 * @returns The lastExecuteIO value or undefined.
 */
function extractLastExecuteIO(meta) {
    if (!meta) {
        return undefined;
    }
    // Direct lastExecuteIO field
    if (meta.lastExecuteIO && typeof meta.lastExecuteIO === 'object') {
        return normalizeLastExecuteIO(meta.lastExecuteIO);
    }
    // (Removed flat metadata fallback as per cleanup tasks in feature_ai_agents_execution_flow.md)
    return undefined;
}
export function readLastExecuteIO() {
    const meta = readCellMetadata();
    return extractLastExecuteIO(meta);
}
/**
 * Merge caller-provided metadata with ambient cell metadata and ensure
 * `lastExecuteIO` is present.  This is the **single source of truth** for
 * metadata resolution — every layer that needs resolved metadata should call
 * this rather than duplicating the merge + lastExecuteIO look-up.
 *
 * Resolution order (last wins):
 *   1. Caller-provided `provided` fields (ground truth)
 *   2. Cell metadata injected by C++ (`readCellMetadata()`) when `provided` is empty
 *   3. `lastExecuteIO` back-filled from the same source when absent
 *
 * @param provided Metadata explicitly passed by the caller (may be empty).
 * @returns Fully-resolved metadata record.
 */
export function resolveMetadata(provided = {}) {
    // Handle JSON string inputs — the xpython.js default Module.implementCode
    // passes metadata as a raw JSON string rather than a parsed object.
    // Parse it so cellId and other fields are preserved correctly.
    let parsedProvided = provided;
    if (typeof provided === 'string' && provided.length > 0) {
        try {
            parsedProvided = JSON.parse(provided);
        }
        catch {
            parsedProvided = {};
        }
    }
    const validated = parsedProvided && typeof parsedProvided === 'object' && !Array.isArray(parsedProvided)
        ? parsedProvided
        : {};
    if (validated[RESOLVED_METADATA_FLAG] === true) {
        return validated;
    }
    const cellMeta = readCellMetadata() ?? {};
    const merged = { ...cellMeta, ...validated, [RESOLVED_METADATA_FLAG]: true };
    const replayAllowed = merged.aiCacheReplayAllowed;
    if (replayAllowed === false) {
        delete merged.lastExecuteIO;
    }
    else if (merged.lastExecuteIO === undefined) {
        const fallback = extractLastExecuteIO(merged);
        if (fallback !== undefined) {
            merged.lastExecuteIO = fallback;
        }
    }
    else if (typeof merged.lastExecuteIO === 'object' && merged.lastExecuteIO !== null) {
        const normalizedLastExecuteIO = normalizeLastExecuteIO(merged.lastExecuteIO);
        if (normalizedLastExecuteIO) {
            merged.lastExecuteIO = normalizedLastExecuteIO;
        }
    }
    // Back-fill cellId from stable C++ context fields when execute_request
    // metadata does not include it.
    // IMPORTANT: do not use exec_id/execution counters here; auto-fix updates
    // must target a notebook cell id only.
    //
    // SAFETY: Only back-fill if the caller provided metadata explicitly
    // (validated has keys), which indicates it came from kernel-injected context.
    // If no metadata was provided, don't back-fill from potentially stale
    // globalThis.datax.cell, as it could be from a previous cell execution.
    //
    // Priority for cellId resolution (first match wins):
    //   1. datax.cell.id     — set by C++ inject_js_cell_context() from the
    //                          execute_request cell ID (most reliable).
    //   2. datax.cell.exec_id — alternate field set alongside id by C++.
    //   3. datax.cell.target  — set by generated code to the command name
    //                          ("pygo", "df_iris", etc.); used as last resort.
    //
    // When datax.cell.id exists but is an empty string, C++ attempted to set
    // it but the execute_request metadata had no cell ID. In this case we fall
    // back to target because the command name is stable across re-executions
    // of the same cell and allows the runtime cache to work.
    if (!merged.cellId) {
        try {
            const g = globalThis;
            // Only trust globalThis.datax.cell if we received explicit metadata from kernel
            const hasExplicitMetadata = Object.keys(validated).length > 0;
            if (hasExplicitMetadata) {
                const cell = g?.datax?.cell;
                let backfillSource = '';
                // Prefer id > exec_id > target, skipping empty strings.
                const id = (typeof cell?.id === 'string' && cell.id.length > 0)
                    ? (backfillSource = 'datax.cell.id', cell.id)
                    : (typeof cell?.exec_id === 'string' && cell.exec_id.length > 0)
                        ? (backfillSource = 'datax.cell.exec_id', cell.exec_id)
                        : (typeof cell?.target === 'string' && cell.target.length > 0)
                            ? (backfillSource = 'datax.cell.target', cell.target)
                            : undefined;
                if (typeof id === 'string' && id.length > 0) {
                    merged.cellId = id;
                    _diag('[diag][resolveMetadata] back-filled cellId', {
                        cellId: id,
                        source: backfillSource,
                        hasExplicitMetadata,
                        metadataKeys: Object.keys(validated),
                    });
                }
            }
            // If no explicit metadata was provided, don't back-fill - force caller
            // to provide cellId explicitly to avoid targeting stale/wrong cell
        }
        catch {
            // silently ignore
        }
    }
    _diag('[diag][resolveMetadata] resolved metadata summary', {
        cellId: typeof merged.cellId === 'string' ? merged.cellId : '',
        hasLastExecuteIO: !!merged.lastExecuteIO,
        replayAllowed: typeof merged.aiCacheReplayAllowed === 'boolean'
            ? merged.aiCacheReplayAllowed
            : 'unset',
        providedKeys: Object.keys(validated)
            .filter((key) => key !== RESOLVED_METADATA_FLAG),
    });
    return merged;
}
/**
 * Read the agent command name set by C++ for @command magic invocations.
 * @returns The command name (e.g., "pygo", "rgen") or undefined for direct API calls.
 */
export function readAgentCommand() {
    try {
        const g = globalThis;
        const cmd = g?.datax?.cell?.agentCommand;
        return typeof cmd === 'string' && cmd.length > 0 ? cmd : undefined;
    }
    catch {
        return undefined;
    }
}
//# sourceMappingURL=cell-ai_agents-context.js.map