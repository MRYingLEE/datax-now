export declare const CONSTANTS: {
    readonly STATUS_OK: "ok";
    readonly STATUS_ERROR: "error";
    readonly LANGUAGE_PYTHON: "Python";
    readonly LANGUAGE_JAVASCRIPT: "javascript";
    readonly LANGUAGE_R: "R";
    readonly THINKING_MESSAGE: "thinking...";
    readonly EMPTY_AI_REQUEST: "Empty AI request";
    readonly EMPTY_CODE_GENERATION_REQUEST: "Empty code generation request";
    readonly EMPTY_JAVASCRIPT_GENERATION_REQUEST: "Empty JavaScript generation request";
    readonly EMPTY_R_GENERATION_REQUEST: "Empty R generation request";
    readonly EMPTY_GENERATION_REQUEST: "Empty generation request";
    readonly FAILED_TO_GENERATE_CODE: "Failed to generate code";
    readonly FAILED_TO_GENERATE_JAVASCRIPT_CODE: "Failed to generate JavaScript code";
    readonly FAILED_TO_GENERATE_R_CODE: "Failed to generate R code";
    readonly AI_CODE_GENERATION_EMPTY_RESULT: "AI code generation returned empty result";
    readonly AI_JAVASCRIPT_GENERATION_EMPTY_RESULT: "AI JavaScript generation returned empty result";
    readonly AI_R_GENERATION_EMPTY_RESULT: "AI R generation returned empty result";
    readonly AI_MIXED_CODE_GENERATION_EMPTY_RESULT: "AI mixed code generation returned empty result";
    readonly GENERATING_PYTHON_CODE: "Generating Python code...";
    readonly GENERATED_PYTHON_CODE: "Generated Python code";
    readonly GENERATING_JAVASCRIPT_CODE: "Generating JavaScript code...";
    readonly GENERATED_JAVASCRIPT_CODE: "Generated JavaScript code";
    readonly GENERATING_R_CODE: "Generating R code...";
    readonly GENERATED_R_CODE: "Generated R code";
    readonly GENERATING_MIXED_CODE: "Generating mixed code...";
    readonly GENERATED_MIXED_CODE: "Generated mixed code";
    readonly FIXING_PYTHON_CODE: "Fixing Python code...";
    readonly FIXED_PYTHON_CODE: "Fixed Python code";
    readonly FIXING_JAVASCRIPT_CODE: "Fixing JavaScript code...";
    readonly FIXED_JAVASCRIPT_CODE: "Fixed JavaScript code";
    readonly FIXING_R_CODE: "Fixing R code...";
    readonly FIXED_R_CODE: "Fixed R code";
    readonly FIXING_MIXED_CODE: "Fixing mixed code...";
    readonly FIXED_MIXED_CODE: "Fixed mixed code";
    readonly EMPTY_STRING: "";
};
export declare enum LanguageType_Lowercase {
    JavaScript = "javascript",
    Python = "python",
    R = "r"
}
export declare function isStringList(variable: unknown): variable is string[];
/**
 * Resolve the main-thread `window` reference in a worker-safe way.
 *
 * In the xeus Coincident worker, the main-thread `window` proxy is stored
 * at `globalThis._window` (not `globalThis.window`, because assigning to
 * `globalThis.window` in a worker breaks tests — see coincident.worker.ts).
 *
 * This helper checks both locations so that ai_agents works whether it runs
 * in the main thread (globalThis.window) or in the Coincident web-worker
 * (globalThis._window).
 */
export declare function resolveWindow(): any;
/**
 * Remove fenced code block formatting and return the code inside
 * @param fencedCode Code potentially wrapped in fenced code blocks
 * @param language Language identifier (python, javascript, r, etc.)
 * @returns Raw code without fence markers
 */
export declare function deFencedCode(fencedCode: string, language: LanguageType_Lowercase | string): string;
/**
 * Extract all fenced code blocks from a markdown string.
 * Returns them in order of appearance with the raw language tag preserved.
 * Shared by cache-utils, code-commands, and ai_agents to ensure consistent parsing.
 */
export declare function extractFencedBlocks(markdown: string): Array<{
    language: string;
    code: string;
}>;
/**
 * Python module names used to detect Python context from variable namespaces.
 */
export declare const PYTHON_MODULE_CANDIDATES: string[];
/**
 * Collect imported Python module names that appear in a variable namespace.
 * Only applies to Python; returns an empty array for other languages.
 */
export declare function collectModulesFromContext(languageKey: 'python' | 'javascript' | 'r', currentContext: Record<string, any>): string[];
/**
 * Normalize a fenced code block language tag to a canonical form.
 */
export declare function normalizeFenceLanguage(language: string): string;
/**
 * Auto-detect the target language from a natural-language requirement string.
 * Defaults to Python when no language-specific signals are found.
 */
export declare function detectLanguage(requirement: string): 'python' | 'javascript' | 'r';
//# sourceMappingURL=utilities.d.ts.map