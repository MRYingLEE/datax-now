import type { CallWarning, DeepPartial, FinishReason, FlexibleSchema, InferSchema, LanguageModel, LanguageModelUsage, StopCondition, ToolChoice, ToolSet } from 'ai';
import type { ProviderOptions } from '@ai-sdk/provider-utils';
import { type SharedAIError } from './ai-error-utils.js';
import { type INativeObjectGenerateResult, type INativeObjectStreamResult, type INativeTextGenerateResult, type INativeTextStreamResult } from './native-agent.js';
export type TypedAgentErrorName = 'ProviderAuthError' | 'ProviderError' | 'TimeoutError' | 'AbortError' | 'RuntimeError';
export type TypedAgentError = SharedAIError;
type TypedToolNames<TOOLS extends ToolSet> = Array<Extract<keyof TOOLS, string>>;
export type TypedAgentOk<T, SDK_RESULT = unknown> = {
    status: 'ok';
    value: T;
    finishReason?: FinishReason;
    usage?: LanguageModelUsage;
    warnings?: CallWarning[];
    sdkResult: SDK_RESULT;
};
export type TypedAgentResult<T, SDK_RESULT = unknown> = TypedAgentOk<T, SDK_RESULT> | ({
    status: 'error';
} & TypedAgentError);
export type TypedAgentCallOptions<TOOLS extends ToolSet = {}> = {
    /** Override the model for this request (e.g. `"openai/gpt-5-mini"`). */
    model?: string;
    /** Override temperature for this request. */
    temperature?: number;
    /** Override max output tokens for this request. */
    maxOutputTokens?: number;
    /** Abort the request (best-effort, provider-dependent). */
    abortSignal?: AbortSignal;
    /** Provider-specific metadata (passed through by the AI SDK). */
    providerOptions?: ProviderOptions;
    /** Inject a model directly (used for testing or advanced callers). */
    llm?: LanguageModel;
    /** Tools exposed to the model. */
    tools?: TOOLS;
    /** Explicit tool selection strategy. */
    toolChoice?: ToolChoice<TOOLS>;
    /** Stop condition(s) for multi-step generations. */
    stopWhen?: StopCondition<TOOLS> | Array<StopCondition<TOOLS>>;
    /** Convenience alias for stop after N steps. */
    maxSteps?: number;
    /** Limit active tools when the model supports more than the current call should use. */
    activeTools?: TypedToolNames<TOOLS>;
};
export type TypedAgentObjectOptions<SCHEMA extends FlexibleSchema<unknown>, TOOLS extends ToolSet = {}> = TypedAgentCallOptions<TOOLS> & {
    schema: SCHEMA;
    schemaName?: string;
    schemaDescription?: string;
};
export type TypedAgentTextResult<TOOLS extends ToolSet = {}> = TypedAgentResult<string, INativeTextGenerateResult<TOOLS>['sdkResult']>;
export type TypedAgentObjectResult<SCHEMA extends FlexibleSchema<unknown>, TOOLS extends ToolSet = {}> = TypedAgentResult<InferSchema<SCHEMA>, INativeObjectGenerateResult<InferSchema<SCHEMA>, TOOLS>['sdkResult']>;
export type TypedAgentTextStreamOk<TOOLS extends ToolSet = {}> = {
    status: 'ok';
    textStream: INativeTextStreamResult<TOOLS>['textStream'];
    fullStream: INativeTextStreamResult<TOOLS>['fullStream'];
    sdkResult: INativeTextStreamResult<TOOLS>['sdkResult'];
};
export type TypedAgentTextStreamResult<TOOLS extends ToolSet = {}> = TypedAgentTextStreamOk<TOOLS> | ({
    status: 'error';
} & TypedAgentError);
export type TypedAgentObjectStreamOk<OBJECT, TOOLS extends ToolSet = {}> = {
    status: 'ok';
    partialObjectStream: AsyncIterable<DeepPartial<OBJECT>>;
    textStream: INativeObjectStreamResult<OBJECT, TOOLS>['textStream'];
    fullStream: INativeObjectStreamResult<OBJECT, TOOLS>['fullStream'];
    object: Promise<OBJECT>;
    sdkResult: INativeObjectStreamResult<OBJECT, TOOLS>['sdkResult'];
};
export type TypedAgentObjectStreamResult<SCHEMA extends FlexibleSchema<unknown>, TOOLS extends ToolSet = {}> = TypedAgentObjectStreamOk<InferSchema<SCHEMA>, TOOLS> | ({
    status: 'error';
} & TypedAgentError);
export declare class TypedAgent {
    private readonly _system;
    constructor(options?: {
        system?: string;
    });
    text(prompt: string, options?: TypedAgentCallOptions): Promise<TypedAgentTextResult>;
    streamText<TOOLS extends ToolSet = {}>(prompt: string, options?: TypedAgentCallOptions<TOOLS>): Promise<TypedAgentTextStreamResult<TOOLS>>;
    object<SCHEMA extends FlexibleSchema<unknown>, TOOLS extends ToolSet = {}>(prompt: string, options: TypedAgentObjectOptions<SCHEMA, TOOLS>): Promise<TypedAgentObjectResult<SCHEMA, TOOLS>>;
    streamObject<SCHEMA extends FlexibleSchema<unknown>, TOOLS extends ToolSet = {}>(prompt: string, options: TypedAgentObjectOptions<SCHEMA, TOOLS>): Promise<TypedAgentObjectStreamResult<SCHEMA, TOOLS>>;
}
/** For JavaScript callers that can't use `new` directly; TypeScript callers should prefer `new TypedAgent(options)`. */
export declare function createTypedAgent(options?: {
    system?: string;
}): TypedAgent;
/**
 * One-shot text generation. Returns `{ status: 'ok', text }` (DataX API convention).
 * For repeated calls with the same system prompt, prefer `new TypedAgent({ system })`.
 */
export declare function typedText(prompt: string, options?: TypedAgentCallOptions & {
    system?: string;
}): Promise<{
    status: 'ok';
    text: string;
    finishReason?: FinishReason;
    usage?: LanguageModelUsage;
    warnings?: CallWarning[];
    sdkResult: INativeTextGenerateResult['sdkResult'];
} | ({
    status: 'error';
} & TypedAgentError)>;
/**
 * One-shot structured object generation. Returns `{ status: 'ok', object }` (DataX API convention).
 * For repeated calls with the same system prompt, prefer `new TypedAgent({ system })`.
 */
export declare function typedObject<SCHEMA extends FlexibleSchema<unknown>>(prompt: string, options: TypedAgentObjectOptions<SCHEMA> & {
    system?: string;
}): Promise<{
    status: 'ok';
    object: InferSchema<SCHEMA>;
    finishReason?: FinishReason;
    usage?: LanguageModelUsage;
    warnings?: CallWarning[];
    sdkResult: INativeObjectGenerateResult<InferSchema<SCHEMA>>['sdkResult'];
} | ({
    status: 'error';
} & TypedAgentError)>;
export {};
//# sourceMappingURL=typed-agent.d.ts.map