/**
 * Code Generation Engine
 *
 * Standalone generation functions extracted from CodeCommandExecutor.
 * Each function receives an ICodeCommandContext to access shared helpers.
 */
import { genCode, Purpose, ScriptType } from './ai_agents.js';
import { checkGenCache, clearRuntimeGenCache, getRuntimeGenCache, normalizePrompt, replayDisplayData, setRuntimeGenCache, } from './cache-utils.js';
import { DisplayAdapter } from './display-adapter.js';
import { wrapCodeForDisplay } from './output-processor.js';
import { retryUntil } from './retry.js';
import { makeErrorResult, makeOkResult } from './result-factory.js';
import { CONSTANTS, collectModulesFromContext, deFencedCode, detectLanguage, extractFencedBlocks, } from './utilities.js';
import { validatePackageConstraints, buildConstraintViolationFeedback, buildPackageConstraintsSection, } from './package-validator.js';
import { createLogger } from './logger.js';
const { debug: _debug, info: _info, diagnostic: _diag } = createLogger('[AI_Agents]');
/**
 * Recursively clone a value with bounded depth/width, replacing circular
 * references and anything past the limits with a placeholder. Used to build
 * safe debug previews of live language-namespace snapshots (e.g. R context
 * fetched via Module.getNamespace('r')), which can be deep enough that a
 * direct JSON.stringify() overflows the JS call stack (RangeError: Maximum
 * call stack size exceeded).
 */
function boundedClone(value, depth, seen) {
    if (value === null || typeof value !== 'object') {
        return value;
    }
    if (seen.has(value)) {
        return '[Circular]';
    }
    if (depth <= 0) {
        return Array.isArray(value) ? '[Array]' : '[Object]';
    }
    seen.add(value);
    if (Array.isArray(value)) {
        return value.slice(0, 20).map((item) => boundedClone(item, depth - 1, seen));
    }
    const result = {};
    for (const key of Object.keys(value).slice(0, 50)) {
        try {
            result[key] = boundedClone(value[key], depth - 1, seen);
        }
        catch (error) {
            result[key] = `[unreadable: ${String(error?.message || error)}]`;
        }
    }
    return result;
}
/** Safe, bounded-depth preview string for debug logging. Never throws. */
function safeContextPreview(value, maxLen = 300) {
    try {
        return JSON.stringify(boundedClone(value, 4, new WeakSet())).slice(0, maxLen);
    }
    catch (error) {
        return `[context preview unavailable: ${String(error?.message || error)}]`;
    }
}
function normalizeMixedLanguage(language) {
    const lower = language.toLowerCase();
    if (lower === 'python' || lower === 'py')
        return 'python';
    if (lower === 'javascript' || lower === 'js' || lower === 'typescript' || lower === 'ts' || lower === 'tsx')
        return 'javascript';
    if (lower === 'r' || lower === 'rlang')
        return 'r';
    return undefined;
}
function validateMixedPackageConstraints(markdown, required, prohibited) {
    const blocks = extractFencedBlocks(markdown);
    const foundRequired = new Set();
    const usedProhibited = new Set();
    for (const block of blocks) {
        const language = normalizeMixedLanguage(block.language);
        if (!language)
            continue;
        const result = validatePackageConstraints(block.code, language, [], prohibited);
        result.usedProhibited.forEach((packageName) => usedProhibited.add(packageName));
        // The validator's public result intentionally exposes only violations, so
        // check required packages one at a time to determine which block provides them.
        for (const packageName of required) {
            if (validatePackageConstraints(block.code, language, [packageName], []).valid) {
                foundRequired.add(packageName.toLowerCase());
            }
        }
    }
    const missingRequired = required.filter((packageName) => !foundRequired.has(packageName.toLowerCase()));
    return {
        valid: missingRequired.length === 0 && usedProhibited.size === 0,
        missingRequired,
        usedProhibited: [...usedProhibited],
    };
}
function isNormalWidgetDisplay(generated) {
    const createsWidget = /\bdatax\.(?:widget|widgets\.anywidget)\s*\(/.test(generated);
    const displaysWidget = /\bdisplay_widget\s*\(|\bdatax\.display\.display_anywidget\s*\(/.test(generated);
    return createsWidget && displaysWidget;
}
/**
 * Emit a display_data message for generated code.
 */
export function emitGeneratedDisplay(options) {
    if (!options.generated || options.generated.trim().length === 0) {
        return null;
    }
    if (isNormalWidgetDisplay(options.generated)) {
        return null;
    }
    const metadata = {
        source: options.sourceTag,
        prompt: normalizePrompt(options.requirement),
    };
    if (options.detectedLanguage) {
        metadata.detectedLanguage = options.detectedLanguage;
    }
    const fencedContent = options.isMarkdown
        ? options.generated
        : wrapCodeForDisplay(options.generated, options.language ?? '');
    // Wrap in <details> structure to preserve the collapsible display.
    // The cache (extractFencedBlocks) still finds fenced code blocks inside
    // the HTML wrapper, so cache detection and code extraction remain intact.
    const summary = options.summary || 'Generated code';
    const markdown = `<details ><summary>${summary}</summary><br>\n\n${fencedContent}\n</details>`;
    const g = globalThis;
    const displayData = g?.datax?.display?.display_data ?? g?.display_data;
    const updateDisplayData = g?.datax?.display?.update_display_data ?? g?.update_display_data;
    const data = { 'text/markdown': markdown };
    const displayId = options.displayId ? String(options.displayId) : '';
    const transient = displayId ? { display_id: displayId } : {};
    if (displayId && typeof updateDisplayData === 'function') {
        const displayRecord = {
            output_type: 'update_display_data',
            data,
            metadata,
            transient,
        };
        updateDisplayData(data, metadata, transient);
        return displayRecord;
    }
    const displayRecord = {
        output_type: 'display_data',
        data,
        metadata,
        transient,
    };
    if (typeof displayData === 'function') {
        displayData(data, metadata, transient);
        return displayRecord;
    }
    DisplayAdapter.markdown(markdown, { metadata });
    return displayRecord;
}
/**
 * Core code generation with retry logic for a single language.
 */
export async function executeGenCodeGen(ctx, command, requirement, scriptType, language, languageKey, generatingMessage, generatedMessage, emptyErrorMessage, purpose = Purpose.FirstGen, maxTries = 5, detectedLanguage, metadata = {}, packageConstraints, model) {
    // Validate requirement
    if (!requirement) {
        return makeErrorResult(ctx.config.getExecutionCount, 'ExecutionError', `Empty ${language} generation request`, [`No requirement provided after ${command}`]);
    }
    // Validate datax configuration
    if (!ctx.config.datax) {
        return makeErrorResult(ctx.config.getExecutionCount, 'ConfigurationError', 'datax not configured', [`${command} requires datax to be configured`]);
    }
    const resolvedMetadata = ctx.resolveMetadata(metadata);
    const lastExecuteIO = resolvedMetadata.lastExecuteIO;
    const replayAllowed = resolvedMetadata.aiCacheReplayAllowed;
    const effectiveDetectedLanguage = detectedLanguage ?? languageKey;
    const cellId = typeof resolvedMetadata.cellId === 'string'
        ? resolvedMetadata.cellId
        : undefined;
    const sourceTag = ctx.resolveSourceTag(command);
    _diag('[diag][executeGenCodeGen] resolved metadata', {
        command,
        sourceTag,
        cellId: cellId ?? '',
        replayAllowed: replayAllowed ?? 'unset',
        hasLastExecuteIO: !!lastExecuteIO,
        detectedLanguage: effectiveDetectedLanguage,
        normalizedRequirement: normalizePrompt(requirement),
    });
    // Build a constraint-augmented requirement that embeds the package
    // instructions into the user prompt so they are visible in every retry.
    const _required = (packageConstraints?.required ?? []).filter(Boolean);
    const _optional = (packageConstraints?.optional ?? []).filter(Boolean);
    const _prohibited = (packageConstraints?.prohibited ?? []).filter(Boolean);
    const constraintSection = buildPackageConstraintsSection(_required, _optional, _prohibited);
    // Base requirement: plain text; violations are appended per-attempt below.
    const baseRequirement = constraintSection
        ? `${requirement}\n\n${constraintSection}`
        : requirement;
    if (replayAllowed === false) {
        clearRuntimeGenCache({
            cellId,
            requestType: sourceTag,
            requirement,
            detectedLanguage: effectiveDetectedLanguage,
            packageConstraints,
        });
    }
    const cacheHit = checkGenCache({
        requestType: sourceTag,
        requirement,
        lastExecuteIO,
        detectedLanguage: effectiveDetectedLanguage,
        replayAllowed,
        packageConstraints,
    });
    if (cacheHit) {
        _diag('[diag][executeGenCodeGen] checkGenCache hit', {
            sourceTag,
            cellId: cellId ?? '',
            detectedLanguage: effectiveDetectedLanguage,
            displayCount: cacheHit.displayData.length,
        });
        _info(`[cache] hit for ${sourceTag} (${normalizePrompt(requirement)})`);
        replayDisplayData(cacheHit.displayData);
        return makeOkResult(ctx.config.getExecutionCount, undefined, {
            generated: cacheHit.generated,
            cached: true,
            detectedLanguage: effectiveDetectedLanguage,
        });
    }
    const runtimeCacheHit = getRuntimeGenCache({
        cellId,
        requestType: sourceTag,
        requirement,
        detectedLanguage: effectiveDetectedLanguage,
        replayAllowed,
        packageConstraints,
    });
    if (runtimeCacheHit) {
        _diag('[diag][executeGenCodeGen] runtime cache hit', {
            sourceTag,
            cellId: cellId ?? '',
            detectedLanguage: effectiveDetectedLanguage,
            displayCount: runtimeCacheHit.displayData.length,
        });
        replayDisplayData(runtimeCacheHit.displayData);
        return makeOkResult(ctx.config.getExecutionCount, undefined, {
            generated: runtimeCacheHit.generated,
            cached: true,
            detectedLanguage: effectiveDetectedLanguage,
        });
    }
    if (lastExecuteIO && replayAllowed !== false) {
        _diag('[diag][executeGenCodeGen] cache miss after checkGen/runtime lookup', {
            sourceTag,
            cellId: cellId ?? '',
            detectedLanguage: effectiveDetectedLanguage,
            normalizedRequirement: normalizePrompt(requirement),
        });
        _info(`[cache] miss for ${sourceTag} (${normalizePrompt(requirement)})`);
    }
    else {
        _diag('[diag][executeGenCodeGen] cache skipped before generation', {
            sourceTag,
            cellId: cellId ?? '',
            replayAllowed: replayAllowed ?? 'unset',
            hasLastExecuteIO: !!lastExecuteIO,
        });
        _info(`[cache] skip for ${sourceTag} (missing lastExecuteIO)`);
    }
    const { result } = await retryUntil(maxTries, async (attempt) => {
        const languageProxy = ctx.resolveLanguageProxy(languageKey);
        if (!languageProxy) {
            return makeErrorResult(ctx.config.getExecutionCount, 'ConfigurationError', `Unsupported language: ${languageKey}`, [`${command} does not support language: ${languageKey}`]);
        }
        // Get context from datax (all variables in the namespace)
        // Prefer Markdown context from getContextForPrompt() (adaptive formatting per
        // docs/devops/feature_context.md) over raw JSON vars to save tokens and improve
        // LLM code quality.
        let currentContext;
        let modules = [];
        try {
            const markdownContext = languageProxy.context;
            if (markdownContext && typeof markdownContext === 'string') {
                currentContext = markdownContext;
                _debug(`code generation context fetch (Markdown): languageKey=${languageKey}, length=${markdownContext.length}`);
                // Extract module names from raw vars for import detection (only needed/used for Python)
                if (languageKey === 'python') {
                    const rawVars = languageProxy.vars || {};
                    modules = collectModulesFromContext(languageKey, rawVars);
                }
                else {
                    modules = [];
                }
            }
            else {
                const rawVars = languageProxy.vars || {};
                currentContext = rawVars;
                _debug(`code generation context fetch (JSON): languageKey=${languageKey}, vars keys=[${Object.keys(currentContext).join(', ')}], vars=${safeContextPreview(currentContext)}`);
                modules = collectModulesFromContext(languageKey, currentContext);
            }
        }
        catch (error) {
            return makeErrorResult(ctx.config.getExecutionCount, 'ContextError', `Failed to get execution context: ${error.message}`, [String(error.stack || error)]);
        }
        // Generate unique session ID
        const sessionId = ctx.createSessionId(command);
        if (Purpose.AutoSuggest !== purpose) {
            DisplayAdapter.markdown(CONSTANTS.THINKING_MESSAGE + ' (Try ' + String(attempt) + ')', {
                display_id: sessionId,
                update: attempt !== 1,
            });
        }
        try {
            const generatedCode = await genCode({
                currentPrompt: baseRequirement,
                realCode: false,
                currentContext,
                modules,
                scriptType,
                sessionId,
                summary_going: generatingMessage,
                summary_done: generatedMessage,
                finalClosed: true,
                purpose,
                metadata: resolvedMetadata,
                model,
            });
            if (!generatedCode || generatedCode.trim().length === 0) {
                return makeErrorResult(ctx.config.getExecutionCount, 'GenerationError', emptyErrorMessage, ['AI returned empty code']);
            }
            // genCode already strips fences via extractCode(), but we keep this
            // as a safety net for the edge case where the LLM returns content
            // without fenced blocks (extractCode falls back to trimming raw text).
            const cleanCode = deFencedCode(generatedCode, language);
            // --- Package constraint validation ---
            if (_required.length > 0 || _prohibited.length > 0) {
                const validationResult = validatePackageConstraints(cleanCode, languageKey, _required, _prohibited);
                if (!validationResult.valid) {
                    const feedback = buildConstraintViolationFeedback(validationResult);
                    _info(`package constraint violation on attempt ${attempt}: ${feedback}`);
                    return makeErrorResult(ctx.config.getExecutionCount, 'PackageConstraintViolation', feedback, [feedback]);
                }
            }
            const displayRecord = emitGeneratedDisplay({
                sourceTag,
                requirement,
                generated: cleanCode,
                language,
                detectedLanguage: effectiveDetectedLanguage,
                displayId: sessionId,
                summary: generatedMessage,
            });
            setRuntimeGenCache({
                cellId,
                requestType: sourceTag,
                requirement,
                detectedLanguage: effectiveDetectedLanguage,
                packageConstraints,
                generated: cleanCode,
                displayData: displayRecord ? [displayRecord] : [],
            });
            _diag('[diag][executeGenCodeGen] stored runtime cache entry', {
                sourceTag,
                cellId: cellId ?? '',
                detectedLanguage: effectiveDetectedLanguage,
                hasDisplayRecord: !!displayRecord,
            });
            return makeOkResult(ctx.config.getExecutionCount, undefined, {
                generated: cleanCode,
                detectedLanguage: effectiveDetectedLanguage,
            });
        }
        catch (error) {
            const errName = error?.name || '';
            if (errName === 'AbortError') {
                return makeErrorResult(ctx.config.getExecutionCount, 'AbortError', 'AI code generation was stopped by user.', []);
            }
            // No AI provider is configured: retrying won't help since every
            // attempt will fail identically (and re-log the same console error).
            if (errName === 'ProviderConfigurationError') {
                return makeErrorResult(ctx.config.getExecutionCount, 'ConfigurationError', error.message, [String(error.stack || error)]);
            }
            return makeErrorResult(ctx.config.getExecutionCount, 'GenerationError', `Failed to generate code: ${error.message}`, [String(error.stack || error)]);
        }
    }, 
    // Bail immediately on permanent errors — retrying won't fix them.
    (value) => value?.status === 'ok' ||
        value?.ename === 'AbortError' ||
        value?.ename === 'ConfigurationError' ||
        value?.ename === 'ContextError');
    return (result ||
        makeErrorResult(ctx.config.getExecutionCount, 'MaxRetriesExceeded', `Failed after ${maxTries} attempts`));
}
/**
 * Auto-detect language and generate code in a single detected language.
 */
export async function executeSingleLangGen(ctx, languageConfig, requirement, maxTries = 5, metadata = {}, packageConstraints, model) {
    if (!requirement) {
        return makeErrorResult(ctx.config.getExecutionCount, 'ExecutionError', 'Empty code generation request', ['No requirement provided after @gen']);
    }
    const detectedLang = detectLanguage(requirement);
    // Generate code in the detected language only
    const cfg = languageConfig[detectedLang];
    return executeGenCodeGen(ctx, '@gen', requirement, cfg.scriptType, cfg.languageType, cfg.languageKey, cfg.generatingMessage, cfg.generatedMessage, cfg.emptyErrorMessage, Purpose.FirstGen, maxTries, detectedLang, metadata, packageConstraints, model);
}
/**
 * Generate code in mixed-language mode (Python + R + JS fenced blocks).
 */
export async function executeMixedGen(ctx, requirement, maxTries = 5, metadata = {}, packageConstraints, model, command = '@wildgen') {
    if (!requirement) {
        return makeErrorResult(ctx.config.getExecutionCount, 'ExecutionError', 'Empty mixed-language generation request', ['No requirement provided after @gen']);
    }
    if (!ctx.config.datax || !ctx.config.datax.python) {
        return makeErrorResult(ctx.config.getExecutionCount, 'ConfigurationError', 'Python language proxy required for @gen command', ['@gen command requires datax.python to be configured']);
    }
    const languageProxy = ctx.config.datax.python;
    let currentContext = {};
    let modules = [];
    try {
        const markdownContext = languageProxy.context;
        if (markdownContext && typeof markdownContext === 'string') {
            currentContext = markdownContext;
            _debug(`gen context fetch (Markdown): languageKey=python, length=${markdownContext.length}`);
            modules = collectModulesFromContext('python', languageProxy.vars || {});
        }
        else {
            currentContext = languageProxy.vars || {};
            _debug(`gen context fetch (JSON): languageKey=python, vars keys=[${Object.keys(currentContext).join(', ')}], vars=${safeContextPreview(currentContext)}`);
            modules = collectModulesFromContext('python', currentContext);
        }
    }
    catch (error) {
        return makeErrorResult(ctx.config.getExecutionCount, 'ContextError', `Failed to get execution context: ${error.message}`, [String(error.stack || error)]);
    }
    const resolvedMetadata = ctx.resolveMetadata(metadata);
    const lastExecuteIO = resolvedMetadata.lastExecuteIO;
    const replayAllowed = resolvedMetadata.aiCacheReplayAllowed;
    const sourceTag = ctx.resolveSourceTag(command);
    // Inject package constraint hints into the prompt for mixed-language generation.
    const _mixedRequired = (packageConstraints?.required ?? []).filter(Boolean);
    const _mixedOptional = (packageConstraints?.optional ?? []).filter(Boolean);
    const _mixedProhibited = (packageConstraints?.prohibited ?? []).filter(Boolean);
    const mixedConstraintSection = buildPackageConstraintsSection(_mixedRequired, _mixedOptional, _mixedProhibited);
    const baseMixedRequirement = mixedConstraintSection
        ? `${requirement}\n\n${mixedConstraintSection}`
        : requirement;
    const cacheHit = checkGenCache({
        requestType: sourceTag,
        requirement,
        lastExecuteIO,
        replayAllowed,
        packageConstraints,
    });
    if (cacheHit) {
        replayDisplayData(cacheHit.displayData);
        return makeOkResult(ctx.config.getExecutionCount, undefined, {
            generated: cacheHit.generated,
            cached: true,
        });
    }
    const sessionId = ctx.createSessionId(command);
    const { result } = await retryUntil(maxTries, async (attempt) => {
        DisplayAdapter.markdown(CONSTANTS.THINKING_MESSAGE + ' (Try ' + String(attempt) + ')', {
            display_id: sessionId,
            update: attempt !== 1,
        });
        try {
            const generatedCode = await genCode({
                currentPrompt: baseMixedRequirement,
                realCode: false,
                currentContext,
                modules,
                scriptType: ScriptType.PyRJS,
                sessionId,
                summary_going: CONSTANTS.GENERATING_MIXED_CODE,
                summary_done: CONSTANTS.GENERATED_MIXED_CODE,
                finalClosed: true,
                purpose: Purpose.FirstGen,
                metadata: resolvedMetadata,
                model,
            });
            if (!generatedCode || generatedCode.trim().length === 0) {
                return makeErrorResult(ctx.config.getExecutionCount, 'GenerationError', CONSTANTS.AI_MIXED_CODE_GENERATION_EMPTY_RESULT, ['AI returned empty code']);
            }
            if (_mixedRequired.length > 0 || _mixedProhibited.length > 0) {
                const validationResult = validateMixedPackageConstraints(generatedCode, _mixedRequired, _mixedProhibited);
                if (!validationResult.valid) {
                    const feedback = buildConstraintViolationFeedback(validationResult);
                    _info(`mixed package constraint violation on attempt ${attempt}: ${feedback}`);
                    return makeErrorResult(ctx.config.getExecutionCount, 'PackageConstraintViolation', feedback, [feedback]);
                }
            }
            emitGeneratedDisplay({
                sourceTag,
                requirement,
                generated: generatedCode,
                isMarkdown: true,
                displayId: sessionId,
                summary: CONSTANTS.GENERATED_MIXED_CODE,
            });
            return makeOkResult(ctx.config.getExecutionCount, undefined, {
                generated: generatedCode,
            });
        }
        catch (error) {
            const errName = error?.name || '';
            if (errName === 'AbortError') {
                return makeErrorResult(ctx.config.getExecutionCount, 'AbortError', 'AI code generation was stopped by user.', []);
            }
            // No AI provider is configured: retrying won't help since every
            // attempt will fail identically (and re-log the same console error).
            if (errName === 'ProviderConfigurationError') {
                return makeErrorResult(ctx.config.getExecutionCount, 'ConfigurationError', error.message, [String(error.stack || error)]);
            }
            return makeErrorResult(ctx.config.getExecutionCount, 'GenerationError', `Failed to generate code: ${error.message}`, [String(error.stack || error)]);
        }
    }, (value) => value?.status === 'ok' || value?.ename === 'AbortError' || value?.ename === 'ConfigurationError');
    return (result ||
        makeErrorResult(ctx.config.getExecutionCount, 'MaxRetriesExceeded', `Failed after ${maxTries} attempts`));
}
//# sourceMappingURL=code-gen-engine.js.map