export function getExecutionCount(getter, fallback = 0) {
    try {
        return getter ? getter() : fallback;
    }
    catch {
        return fallback;
    }
}
export function makeErrorResult(getter, ename, evalue, traceback = [], extra) {
    return {
        status: 'error',
        execution_count: getExecutionCount(getter, 0),
        ename,
        evalue,
        traceback,
        ...extra,
    };
}
export function makeOkResult(getter, executionCount, extra) {
    return {
        status: 'ok',
        execution_count: executionCount ?? getExecutionCount(getter, 0),
        ...extra,
    };
}
//# sourceMappingURL=result-factory.js.map