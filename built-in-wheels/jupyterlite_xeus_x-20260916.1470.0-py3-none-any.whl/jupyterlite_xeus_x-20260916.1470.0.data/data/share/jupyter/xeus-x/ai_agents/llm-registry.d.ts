/**
 * LLMRegistry — Multi-provider model registry for the Vercel AI SDK.
 *
 * Separates provider authentication (API keys, base URLs) from model usage.
 * All returned models are standard `LanguageModel` instances that work with
 * `generateText()`, `streamText()`, `tool()`, `ToolLoopAgent`, and every
 * other Vercel AI SDK function unchanged.
 *
 * @example
 * ```ts
 * import { generateText } from 'ai';
 * import { LLMRegistry } from './llm-registry';
 *
 * const registry = new LLMRegistry();
 *
 * // Configure providers (auth only — done once, e.g. at startup)
 * registry.registerProvider('openai', { apiKey: 'sk-...' });
 * registry.registerProvider('gemini', {
 *   apiKey: 'AIza...',
 *   baseURL: 'https://generativelanguage.googleapis.com/v1beta/openai/',
 * });
 * registry.registerProvider('claude', {
 *   apiKey: 'sk-ant-...',
 *   // Needs native Anthropic factory — see registerAnthropicFactory()
 * });
 *
 * // Multi-model workflow
 * const [r1, r2] = await Promise.all([
 *   generateText({ model: registry.model('openai/gpt-4o'), prompt: 'Review...' }),
 *   generateText({ model: registry.model('gemini/gemini-2.5-flash'), prompt: 'Review...' }),
 * ]);
 * const merged = await generateText({
 *   model: registry.model('claude/claude-sonnet-4-5'),
 *   prompt: `Merge:\n${r1.text}\n${r2.text}`,
 * });
 * ```
 */
import type { LanguageModel } from 'ai';
/**
 * Provider authentication and endpoint configuration.
 * Intentionally separate from any model name — this is the "environment" part.
 */
export interface IProviderAuth {
    provider?: string;
    apiKey?: string;
    baseURL?: string;
    headers?: Record<string, string>;
    /**
     * Default model name for this provider.  Used when another provider's
     * model was requested but that provider is not registered and we fall
     * back to this one.
     */
    defaultModel?: string;
}
/**
 * A factory function that turns auth + model name into a `LanguageModel`.
 *
 * The default factory (`openaiCompatibleFactory`) treats every provider as
 * OpenAI-compatible. You can supply a custom factory for providers that need
 * a native SDK (Anthropic, Google, etc.).
 */
export type ModelFactory = (auth: IProviderAuth, modelName: string) => LanguageModel;
/**
 * Default factory: treats any provider as OpenAI-compatible.
 *
 * Works directly for:
 * - OpenAI (native)
 * - Google Gemini (via `https://generativelanguage.googleapis.com/v1beta/openai/`)
 * - Any OpenAI-compatible proxy (LiteLLM, vLLM, Ollama, Azure)
 *
 * For Anthropic native API, supply a custom factory — see
 * `createAnthropicFactory()`.
 */
declare const openaiCompatibleFactory: ModelFactory;
/**
 * Multi-provider model registry.
 *
 * Register providers with their auth configs, then resolve models by
 * `"provider/model"` spec. Returned `LanguageModel` instances are usable
 * with every Vercel AI SDK function (`generateText`, `streamText`,
 * `ToolLoopAgent`, etc.) without modification.
 */
export declare class LLMRegistry {
    private _providers;
    private _modelCache;
    /**
     * Register a provider with its auth configuration.
     *
     * @param name    Short name, e.g. `'openai'`, `'gemini'`, `'claude'`.
     * @param auth    API key, base URL, and optional headers.
     * @param factory Optional model factory. Defaults to OpenAI-compatible.
     *
     * @example
     * registry.registerProvider('openai', { apiKey: 'sk-...' });
     * registry.registerProvider('gemini', {
     *   apiKey: 'AIza...',
     *   baseURL: 'https://generativelanguage.googleapis.com/v1beta/openai/',
     * });
     */
    registerProvider(name: string, auth: IProviderAuth, factory?: ModelFactory): void;
    /** Parse `"provider/model"` or bare `"model"` spec. */
    private _parseSpec;
    /** Pick the first registered provider as a fallback. */
    private _pickFallback;
    /**
     * Resolve a `LanguageModel` with runtime fallback.
     *
     * The spec is treated as a **preference** — the registry tries the
     * exact provider first, then falls through to any registered provider.
     *
     * Resolution order:
     * 1. `"provider/model"` — exact provider + model.
     * 2. Provider not registered — fall back to another registered
     *    provider using its `defaultModel` (if set) or the requested
     *    model name.
     * 3. Bare `"model"` (no slash) — first registered provider, using
     *    its `defaultModel` or the bare name.
     * 4. No providers at all — throws.
     *
     * @param spec  `"provider/model"` or bare `"model"` string.
     * @returns     A Vercel AI SDK `LanguageModel`.
     *
     * @example
     * // Exact match — openai is registered
     * registry.model('openai/gpt-4o')
     *
     * // Only gemini is registered at runtime — falls back to gemini
     * registry.model('openai/gpt-4o') // → uses gemini/gemini-2.5-flash
     *
     * // Bare model name — uses first registered provider
     * registry.model('gpt-4o')
     */
    model(spec: string): LanguageModel;
    /**
     * Strict model resolution — no fallback.
     *
     * Throws if the exact provider is not registered.
     * Use when you need to guarantee a specific provider.
     *
     * @param spec  `"provider/model"` format (required).
     */
    modelStrict(spec: string): LanguageModel;
    /** Check if a provider is registered. */
    hasProvider(name: string): boolean;
    /** List registered provider names. */
    listProviders(): string[];
    /** Clear cached model instances (e.g. after key rotation). */
    clearCache(): void;
    /** Remove a provider and its cached models. */
    removeProvider(name: string): boolean;
}
/** Get (or create) the default singleton registry. */
export declare function getDefaultRegistry(): LLMRegistry;
/**
 * Register a provider on the default registry.
 *
 * @example
 * registerProvider('openai', { apiKey: 'sk-...' });
 */
export declare function registerProvider(name: string, auth: IProviderAuth, factory?: ModelFactory): void;
/**
 * Resolve a model from the default registry (with runtime fallback).
 *
 * @example
 * import { generateText } from 'ai';
 * const result = await generateText({ model: model('openai/gpt-4o'), prompt: '...' });
 */
export declare function model(spec: string): LanguageModel;
/**
 * Resolve a model strictly (no fallback) from the default registry.
 */
export declare function modelStrict(spec: string): LanguageModel;
/**
 * Populate the registry with the active `window.jupyter_ai` provider.
 *
 * Bridges the existing JupyterLite AI configuration into the registry so
 * existing code can migrate incrementally.
 *
 * @param registry  Registry to populate (defaults to the singleton).
 * @param alias     Provider name to register under (defaults to `'default'`).
 */
export declare function registerFromJupyterAI(registry?: LLMRegistry, alias?: string): boolean;
/**
 * Create a factory for `@ai-sdk/anthropic`.
 *
 * Pass the `createAnthropic` function from the `@ai-sdk/anthropic` package.
 * This avoids a hard dependency — the caller must install the package.
 *
 * @example
 * import { createAnthropic } from '@ai-sdk/anthropic';
 * registry.registerProvider('claude', { apiKey: 'sk-ant-...' },
 *   createNativeFactory(createAnthropic));
 */
export declare function createNativeFactory(createFn: (opts: Record<string, unknown>) => (model: string) => LanguageModel): ModelFactory;
export { openaiCompatibleFactory };
//# sourceMappingURL=llm-registry.d.ts.map