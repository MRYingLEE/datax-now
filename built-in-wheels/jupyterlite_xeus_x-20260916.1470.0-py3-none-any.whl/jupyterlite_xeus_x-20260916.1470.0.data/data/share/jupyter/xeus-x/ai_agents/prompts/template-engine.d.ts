/**
 * Handlebars Template Engine for AI Prompts
 *
 * Runtime-fetch design: templates are loaded via fetch() from a configurable
 * base URL so that end users can edit .hbs files without rebuilding.
 *
 * Initialisation is lazy — the first call to render() triggers fetch of
 * manifest.json and all referenced template / partial files, then caches
 * the compiled Handlebars functions in memory.
 */
/**
 * Set the base URL for template fetching.
 * Must be called BEFORE the first render() if a non-default location is used.
 */
export declare function setTemplateBaseURL(url: string): void;
/**
 * Ensure templates are loaded. Safe to call multiple times — only the first
 * invocation fetches; concurrent callers share the same promise.
 */
export declare function ensureTemplatesLoaded(): Promise<void>;
/**
 * Render a template by name with the given data.
 *
 * ```ts
 * const text = await render('system/smartAsk', { defaultConvention, languageHint });
 * ```
 */
export declare function render(name: string, data?: Record<string, unknown>): Promise<string>;
/**
 * Render a kernel context template and return the plain text.
 * Convenience wrapper used by getKernelConfig().
 */
export declare function renderKernel(name: string): Promise<string>;
//# sourceMappingURL=template-engine.d.ts.map