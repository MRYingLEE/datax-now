export class DisplayAdapter {
    static getGlobal() {
        return globalThis;
    }
    static getInterpreter() {
        const g = DisplayAdapter.getGlobal();
        const moduleObj = g?.Module;
        if (!moduleObj) {
            return null;
        }
        for (const getterName of ['get_interpreter', '_get_interpreter']) {
            const getter = moduleObj[getterName];
            if (typeof getter === 'function') {
                try {
                    const interpreter = getter.call(moduleObj);
                    if (interpreter) {
                        return interpreter;
                    }
                }
                catch {
                    // Try the direct interpreter exports below.
                }
            }
        }
        return moduleObj.js_interpreter ?? moduleObj.xkernel ?? null;
    }
    static getMarkdownFn() {
        const g = DisplayAdapter.getGlobal();
        const fn = g?.datax?.display?.display_markdown
            ?? g?.display_markdown
            ?? g?.display?.display_markdown;
        return typeof fn === 'function' ? fn : null;
    }
    static getDisplayDataFns() {
        const g = DisplayAdapter.getGlobal();
        const interpreter = DisplayAdapter.getInterpreter();
        return {
            displayData: g?.datax?.display?.display_data
                ?? g?.display_data
                ?? interpreter?.display_data?.bind(interpreter),
            updateDisplayData: g?.datax?.display?.update_display_data
                ?? g?.update_display_data
                ?? interpreter?.update_display_data?.bind(interpreter),
        };
    }
    static data(data, metadata = {}, transient = {}, update = false) {
        const { displayData, updateDisplayData } = DisplayAdapter.getDisplayDataFns();
        const displayFn = update ? updateDisplayData : displayData;
        if (typeof displayFn !== 'function') {
            return false;
        }
        displayFn(data, metadata, transient);
        return true;
    }
    static markdown(text, options = {}) {
        const displayMarkdown = DisplayAdapter.getMarkdownFn();
        if (displayMarkdown) {
            try {
                displayMarkdown(text, options);
                return;
            }
            catch {
                // Fall through to display_data
            }
        }
        const displayIdOption = options.display_id ? String(options.display_id) : '';
        const transient = displayIdOption ? { display_id: displayIdOption } : {};
        DisplayAdapter.data({ 'text/markdown': text }, options.metadata || {}, transient, options.update === true);
    }
    static details(summary, explanation = '', closed = false, displayId = '') {
        const g = DisplayAdapter.getGlobal();
        const dataxDetails = g?.datax?.display?.display_details;
        if (typeof dataxDetails === 'function') {
            dataxDetails(summary, explanation, closed, displayId);
            return;
        }
        const rootDetails = g?.display_details;
        if (typeof rootDetails === 'function') {
            rootDetails(summary, explanation, closed, displayId);
        }
    }
    static updateDetails(summary, explanation = '', closed = false, displayId = '') {
        const g = DisplayAdapter.getGlobal();
        const dataxUpdate = g?.datax?.display?.update_display_details;
        if (typeof dataxUpdate === 'function') {
            dataxUpdate(summary, explanation, closed, displayId);
            return;
        }
        const rootUpdate = g?.update_display_details;
        if (typeof rootUpdate === 'function') {
            rootUpdate(summary, explanation, closed, displayId);
        }
    }
}
//# sourceMappingURL=display-adapter.js.map