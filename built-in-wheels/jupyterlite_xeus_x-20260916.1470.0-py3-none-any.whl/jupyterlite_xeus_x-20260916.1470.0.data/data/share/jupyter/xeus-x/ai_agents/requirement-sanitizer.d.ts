/**
 * RequirementSanitization - Sanitizes requirement strings for prompt inclusion
 *
 * Handles JSON.parse patterns in requirements to prevent XSS and ensure
 * safe string representation in prompts. Extracted from ai_agents.ts as part of deepening Candidate 1.
 */
export declare function sanitizeRequirement(requirement: string): string;
//# sourceMappingURL=requirement-sanitizer.d.ts.map