import { stepCountIs } from 'ai';
import { buildSkillAwarePrompt } from './agent-skills.js';
import { getLLM, getLLMRequestOptions, } from './llm-factory.js';
import { normalizeAIError, } from './ai-error-utils.js';
import { createNativeObjectAgent, createNativeTextAgent, } from './native-agent.js';
function normalizeStopWhen(options) {
    const conditions = [];
    if (options?.stopWhen) {
        conditions.push(...(Array.isArray(options.stopWhen) ? options.stopWhen : [options.stopWhen]));
    }
    if (Number.isInteger(options?.maxSteps) && (options?.maxSteps ?? 0) > 0) {
        conditions.push(stepCountIs(options.maxSteps));
    }
    if (conditions.length === 0) {
        return undefined;
    }
    return conditions.length === 1 ? conditions[0] : conditions;
}
function buildGenerationOptions(options) {
    const requestOptions = getLLMRequestOptions({
        temperature: options?.temperature,
        maxOutputTokens: options?.maxOutputTokens,
    }, options?.model);
    const stopWhen = normalizeStopWhen(options);
    return {
        ...requestOptions,
        ...(options?.abortSignal ? { abortSignal: options.abortSignal } : {}),
        ...(options?.providerOptions ? { providerOptions: options.providerOptions } : {}),
        ...(options?.tools ? { tools: options.tools } : {}),
        ...(options?.toolChoice ? { toolChoice: options.toolChoice } : {}),
        ...(stopWhen ? { stopWhen } : {}),
        ...(options?.activeTools ? { activeTools: options.activeTools } : {}),
    };
}
export class TypedAgent {
    constructor(options) {
        this._system = typeof options?.system === 'string' ? options.system : '';
    }
    async text(prompt, options) {
        const llm = options?.llm ?? getLLM(undefined, options?.model);
        if (!llm) {
            return {
                status: 'error',
                ename: 'ProviderAuthError',
                evalue: 'No active provider configured in window.jupyter_ai',
            };
        }
        try {
            const built = buildSkillAwarePrompt(this._system, String(prompt ?? ''));
            const generationOptions = buildGenerationOptions(options);
            const agent = createNativeTextAgent({
                model: llm,
                instructions: built.instructions,
                temperature: generationOptions.temperature,
                maxOutputTokens: generationOptions.maxOutputTokens,
                providerOptions: generationOptions.providerOptions,
                tools: generationOptions.tools,
                toolChoice: generationOptions.toolChoice,
                stopWhen: generationOptions.stopWhen,
                activeTools: generationOptions.activeTools,
            });
            const result = await agent.generate({
                prompt: built.prompt,
                ...(generationOptions.abortSignal ? { abortSignal: generationOptions.abortSignal } : {}),
            });
            return {
                status: 'ok',
                value: result.text,
                finishReason: result.finishReason,
                usage: result.usage,
                warnings: result.warnings ?? [],
                sdkResult: result.sdkResult,
            };
        }
        catch (error) {
            return { status: 'error', ...normalizeAIError(error) };
        }
    }
    async streamText(prompt, options) {
        const llm = options?.llm ?? getLLM(undefined, options?.model);
        if (!llm) {
            return {
                status: 'error',
                ename: 'ProviderAuthError',
                evalue: 'No active provider configured in window.jupyter_ai',
            };
        }
        try {
            const built = buildSkillAwarePrompt(this._system, String(prompt ?? ''));
            const generationOptions = buildGenerationOptions(options);
            const agent = createNativeTextAgent({
                model: llm,
                instructions: built.instructions,
                temperature: generationOptions.temperature,
                maxOutputTokens: generationOptions.maxOutputTokens,
                providerOptions: generationOptions.providerOptions,
                tools: generationOptions.tools,
                toolChoice: generationOptions.toolChoice,
                stopWhen: generationOptions.stopWhen,
                activeTools: generationOptions.activeTools,
            });
            const result = await agent.stream({
                prompt: built.prompt,
                ...(generationOptions.abortSignal ? { abortSignal: generationOptions.abortSignal } : {}),
            });
            return {
                status: 'ok',
                textStream: result.textStream,
                fullStream: result.fullStream,
                sdkResult: result.sdkResult,
            };
        }
        catch (error) {
            return { status: 'error', ...normalizeAIError(error) };
        }
    }
    async object(prompt, options) {
        const llm = options.llm ?? getLLM(undefined, options.model);
        if (!llm) {
            return {
                status: 'error',
                ename: 'ProviderAuthError',
                evalue: 'No active provider configured in window.jupyter_ai',
            };
        }
        try {
            const built = buildSkillAwarePrompt(this._system, String(prompt ?? ''));
            const generationOptions = buildGenerationOptions(options);
            const agent = createNativeObjectAgent({
                model: llm,
                schema: options.schema,
                instructions: built.instructions,
                schemaName: options.schemaName,
                schemaDescription: options.schemaDescription,
                temperature: generationOptions.temperature,
                maxOutputTokens: generationOptions.maxOutputTokens,
                providerOptions: generationOptions.providerOptions,
                tools: generationOptions.tools,
                toolChoice: generationOptions.toolChoice,
                stopWhen: generationOptions.stopWhen,
                activeTools: generationOptions.activeTools,
            });
            const result = await agent.generate({
                prompt: built.prompt,
                ...(generationOptions.abortSignal ? { abortSignal: generationOptions.abortSignal } : {}),
            });
            return {
                status: 'ok',
                value: result.output,
                finishReason: result.finishReason,
                usage: result.usage,
                warnings: result.warnings ?? [],
                sdkResult: result.sdkResult,
            };
        }
        catch (error) {
            return { status: 'error', ...normalizeAIError(error) };
        }
    }
    async streamObject(prompt, options) {
        const llm = options.llm ?? getLLM(undefined, options.model);
        if (!llm) {
            return {
                status: 'error',
                ename: 'ProviderAuthError',
                evalue: 'No active provider configured in window.jupyter_ai',
            };
        }
        try {
            const built = buildSkillAwarePrompt(this._system, String(prompt ?? ''));
            const generationOptions = buildGenerationOptions(options);
            const agent = createNativeObjectAgent({
                model: llm,
                schema: options.schema,
                instructions: built.instructions,
                schemaName: options.schemaName,
                schemaDescription: options.schemaDescription,
                temperature: generationOptions.temperature,
                maxOutputTokens: generationOptions.maxOutputTokens,
                providerOptions: generationOptions.providerOptions,
                tools: generationOptions.tools,
                toolChoice: generationOptions.toolChoice,
                stopWhen: generationOptions.stopWhen,
                activeTools: generationOptions.activeTools,
            });
            const result = await agent.stream({
                prompt: built.prompt,
                ...(generationOptions.abortSignal ? { abortSignal: generationOptions.abortSignal } : {}),
            });
            return {
                status: 'ok',
                partialObjectStream: result.partialObjectStream,
                textStream: result.textStream,
                fullStream: result.fullStream,
                object: result.object,
                sdkResult: result.sdkResult,
            };
        }
        catch (error) {
            return { status: 'error', ...normalizeAIError(error) };
        }
    }
}
/** For JavaScript callers that can't use `new` directly; TypeScript callers should prefer `new TypedAgent(options)`. */
export function createTypedAgent(options) {
    return new TypedAgent(options);
}
// ---------------------------------------------------------------------------
// Compatibility helpers for xeus-x callers
// ---------------------------------------------------------------------------
/**
 * One-shot text generation. Returns `{ status: 'ok', text }` (DataX API convention).
 * For repeated calls with the same system prompt, prefer `new TypedAgent({ system })`.
 */
export async function typedText(prompt, options) {
    const agent = new TypedAgent({ system: options?.system });
    const result = await agent.text(prompt, options);
    if (result.status === 'error')
        return result;
    const { value, ...rest } = result;
    return { ...rest, status: 'ok', text: value };
}
/**
 * One-shot structured object generation. Returns `{ status: 'ok', object }` (DataX API convention).
 * For repeated calls with the same system prompt, prefer `new TypedAgent({ system })`.
 */
export async function typedObject(prompt, options) {
    const agent = new TypedAgent({ system: options?.system });
    const result = await agent.object(prompt, options);
    if (result.status === 'error')
        return result;
    const { value, ...rest } = result;
    return { ...rest, status: 'ok', object: value };
}
//# sourceMappingURL=typed-agent.js.map