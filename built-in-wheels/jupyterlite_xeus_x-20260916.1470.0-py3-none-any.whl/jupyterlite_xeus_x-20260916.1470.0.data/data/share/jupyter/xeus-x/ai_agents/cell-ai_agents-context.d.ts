/**
 * Cell AI_Agents Context — shared type for metadata injected by C++ into
 * `globalThis.datax.cell` before every execution.
 *
 * C++ sets `datax.cell.metadata` (execute_request metadata including lastExecuteIO),
 * `datax.cell.exec_metadata` (stable snapshot for post-exec work),
 * `datax.cell.execution_count`, and `datax.cell.id` via emscripten::val before
 * dispatching generated code to sub-kernels.
 *
 * This module provides typed access to that context, eliminating the need for
 * metadata parameter passing through the bridge layer.
 */
import type { JSONObject } from '@lumino/coreutils';
/**
 * Shape of `globalThis.datax.cell` as set by C++ before each execution.
 */
export interface ICellContext {
    /** Full execute_request metadata from Jupyter (cellId, lastExecuteIO, etc.) */
    metadata?: JSONObject;
    /**
     * Independent deep-copy snapshot of the execute_request metadata, set by
     * `inject_js_cell_context` in C++ (via `cell.set("exec_metadata", ...)`).
     * Prefer this over `metadata` inside agent callbacks because it remains
     * stable even if `metadata` is later mutated by the kernel router.
     */
    exec_metadata?: JSONObject;
    /** Current execution counter */
    execution_count?: number;
    /** Cell ID string (stable UUID for the lifetime of the cell). */
    id?: string;
    /** Alias for `id` — set alongside `id` by C++ for backward compatibility. */
    exec_id?: string;
}
/**
 * Read the current execution metadata snapshot from `globalThis.datax.cell.exec_metadata`.
 * This is injected by C++ (via emscripten::val for JS, Python code for Python,
 * R code for R) before every execution.
 *
 * @returns The execute_request metadata object, or undefined if unavailable.
 */
export declare function readCellMetadata(): JSONObject | undefined;
export declare function readLastExecuteIO(): JSONObject | undefined;
/**
 * Merge caller-provided metadata with ambient cell metadata and ensure
 * `lastExecuteIO` is present.  This is the **single source of truth** for
 * metadata resolution — every layer that needs resolved metadata should call
 * this rather than duplicating the merge + lastExecuteIO look-up.
 *
 * Resolution order (last wins):
 *   1. Caller-provided `provided` fields (ground truth)
 *   2. Cell metadata injected by C++ (`readCellMetadata()`) when `provided` is empty
 *   3. `lastExecuteIO` back-filled from the same source when absent
 *
 * @param provided Metadata explicitly passed by the caller (may be empty).
 * @returns Fully-resolved metadata record.
 */
export declare function resolveMetadata(provided?: JSONObject | string | null | undefined): JSONObject;
/**
 * Read the agent command name set by C++ for @command magic invocations.
 * @returns The command name (e.g., "pygo", "rgen") or undefined for direct API calls.
 */
export declare function readAgentCommand(): string | undefined;
//# sourceMappingURL=cell-ai_agents-context.d.ts.map