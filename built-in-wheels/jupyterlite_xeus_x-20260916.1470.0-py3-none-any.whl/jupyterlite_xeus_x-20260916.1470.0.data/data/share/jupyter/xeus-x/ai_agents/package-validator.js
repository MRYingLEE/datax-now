/**
 * Package Constraint Validator
 *
 * Extracts imported package names from generated code and validates them
 * against required / prohibited constraints. Used inside the retry loop of
 * executeGenCodeGen so that violations are fed back to the AI as re-prompt
 * feedback rather than silently returned to the caller.
 *
 * Language support:
 *   Python     - import X, from X import Y (top-level package name only)
 *   R          - library(X), require(X), library("X"), require('X')
 *   JavaScript - import … from 'X', require('X'), import('X')
 *               (strips @scope/ prefix for matching)
 */
// ---------------------------------------------------------------------------
// Import extraction
// ---------------------------------------------------------------------------
/**
 * Normalise a raw package name to a canonical form for matching.
 * Lower-cases and strips leading scope (@scope/) for JS packages.
 */
function normalise(name) {
    return name.replace(/^@[^/]+\//, '').toLowerCase().trim();
}
/**
 * Extract the set of imported package names from Python source code.
 * Returns only top-level package names (e.g. `matplotlib` from
 * `import matplotlib.pyplot as plt`).
 */
function extractPythonPackages(code) {
    const packages = new Set();
    // import X, import X as Y, import X.Y.Z, import X, Y
    const importRe = /^\s*import\s+([^#\n]+)/gm;
    let m;
    while ((m = importRe.exec(code)) !== null) {
        for (const item of m[1].split(',')) {
            const packageName = item.trim().split(/\s+as\s+/i)[0].trim();
            if (/^[\w.]+$/.test(packageName)) {
                packages.add(normalise(packageName.split('.')[0]));
            }
        }
    }
    // from X import Y (also handles from X.Y import Z → root is X)
    const fromRe = /^\s*from\s+([\w.]+)\s+import/gm;
    while ((m = fromRe.exec(code)) !== null) {
        packages.add(normalise(m[1].split('.')[0]));
    }
    return packages;
}
/**
 * Extract the set of imported package names from R source code.
 * Handles: library(X), require(X), library("X"), require('X'),
 *          library(package = "X"), require(package = "X")
 */
function extractRPackages(code) {
    const packages = new Set();
    // library(pkg) / require(pkg) — bare identifier or quoted string
    const re = /\b(?:library|require)\s*\(\s*(?:package\s*=\s*)?["']?([\w.]+)["']?\s*[,)]/g;
    let m;
    while ((m = re.exec(code)) !== null) {
        packages.add(normalise(m[1]));
    }
    const namespaceRe = /\b([\w.]+):::{0,1}/g;
    while ((m = namespaceRe.exec(code)) !== null) {
        packages.add(normalise(m[1]));
    }
    return packages;
}
/**
 * Extract the set of imported package names from JavaScript / TypeScript source.
 * Handles:
 *   import … from 'pkg'
 *   const x = require('pkg')
 *   import('pkg')
 *   @scope/pkg → pkg
 */
function extractJavaScriptPackages(code) {
    const packages = new Set();
    // import … from 'pkg' / import … from "pkg"
    const importFromRe = /\bfrom\s+['"](@?[\w/@.-]+)['"]/g;
    let m;
    while ((m = importFromRe.exec(code)) !== null) {
        packages.add(normalise(m[1]));
    }
    const sideEffectImportRe = /^\s*import\s+['"](@?[\w/@.-]+)['"]/gm;
    while ((m = sideEffectImportRe.exec(code)) !== null) {
        packages.add(normalise(m[1]));
    }
    // require('pkg') / import('pkg')
    const requireRe = /\b(?:require|import)\s*\(\s*['"](@?[\w/@.-]+)['"]\s*\)/g;
    while ((m = requireRe.exec(code)) !== null) {
        packages.add(normalise(m[1]));
    }
    return packages;
}
/**
 * Extract the set of imported top-level package names from generated code.
 */
export function extractImportedPackages(code, language) {
    switch (language) {
        case 'python': return extractPythonPackages(code);
        case 'r': return extractRPackages(code);
        case 'javascript': return extractJavaScriptPackages(code);
    }
}
/**
 * Validate package constraints against the set of packages used in the code.
 *
 * @param code         Generated source code to inspect
 * @param language     Language of the code
 * @param required     Packages that MUST be imported
 * @param prohibited   Packages that MUST NOT be imported
 */
export function validatePackageConstraints(code, language, required, prohibited) {
    const used = extractImportedPackages(code, language);
    const missingRequired = required
        .map(normalise)
        .filter((pkg) => !used.has(pkg));
    const usedProhibited = prohibited
        .map(normalise)
        .filter((pkg) => used.has(pkg));
    return {
        valid: missingRequired.length === 0 && usedProhibited.length === 0,
        missingRequired,
        usedProhibited,
    };
}
// ---------------------------------------------------------------------------
// Prompt feedback builder
// ---------------------------------------------------------------------------
/**
 * Build a human-readable feedback string that can be appended to a re-prompt
 * when generated code violates package constraints.
 */
export function buildConstraintViolationFeedback(result) {
    const parts = ['The generated code violated package constraints:'];
    if (result.missingRequired.length > 0) {
        parts.push(`- MISSING required packages: ${result.missingRequired.join(', ')} — you MUST import them.`);
    }
    if (result.usedProhibited.length > 0) {
        parts.push(`- USED prohibited packages: ${result.usedProhibited.join(', ')} — you MUST NOT import them.`);
    }
    parts.push('Please regenerate the code to satisfy these constraints.');
    return parts.join('\n');
}
// ---------------------------------------------------------------------------
// Prompt section builder (for injecting constraints into the system prompt)
// ---------------------------------------------------------------------------
/**
 * Build a Markdown section describing the package constraints for inclusion
 * in the AI system prompt.
 *
 * Returns an empty string when all three lists are empty.
 */
export function buildPackageConstraintsSection(required, optional, prohibited) {
    if (required.length === 0 && optional.length === 0 && prohibited.length === 0) {
        return '';
    }
    const lines = ['## Package Constraints'];
    if (required.length > 0) {
        lines.push(`- **MUST use** (required imports): ${required.join(', ')}`);
    }
    if (optional.length > 0) {
        lines.push(`- **Prefer** (optional): ${optional.join(', ')}`);
    }
    if (prohibited.length > 0) {
        lines.push(`- **MUST NOT use** (prohibited imports): ${prohibited.join(', ')}`);
    }
    return lines.join('\n');
}
//# sourceMappingURL=package-validator.js.map