export const GENAI_MAX_ATTEMPTS = 10;
export const GENAI_MAX_RETRIES = GENAI_MAX_ATTEMPTS - 1;
export const GENAI_MAX_429_RETRIES = 50;
export const GENAI_INITIAL_429_RETRY_DELAY_MS = 500;
export const GENAI_MAX_429_RETRY_DELAY_MS = 10000;
//# sourceMappingURL=genai-retry.js.map