/**
 * @jupyterlite/ai_agents - AI Agents for Jupyter Kernels
 *
 * Public API exports.
 * This module provides code generation, single-language go execution helpers,
 * and LLM utilities. Mixed-language execution and output publishing remain in
 * xeus-x's execution layer (datax-exec.js).
 */
export { getNamespace, ask, pygo, jsgo, rgo, pygen, go, wildgo, jsgen, rgen, gen, wildgen, smartAsk, genCode, getVars, dataxApi, publicGetExecutor as getExecutor, type ICodeGenOptions, type IPackageConstraints, type ICodeGenResult, type ISmartAskResult, type ISmartAskCodeBlock, type ISmartAskOptions, } from './datax-api.js';
export { Purpose, ScriptType } from './ai_agents.js';
export { generateSessionId, askAI, genCode as genCodeDirect, fixCode, implementCode, getAIAgentsConfigSummary, getLanguageConfig, getKernelConfig, extractCodeBlocks, extractProse, } from './ai_agents.js';
export { CodeCommandExecutor, type ICodeCommandConfig, type ICodeGoResult, type IRunResult, type IRunOptions, type RunStatus, type ILanguageProxy, type IDataxNamespace, } from './code-commands.js';
export { compressOutput, wrapCode, wrapJSON, wrapSection, extractCode, customTrim, convertToString, } from './output-processor.js';
export { CONSTANTS, LanguageType_Lowercase, isStringList, resolveWindow, deFencedCode, extractFencedBlocks, normalizeFenceLanguage, } from './utilities.js';
export { getActiveProviderConfig, getLLM, type JupyterAIProviderConfig, } from './llm-factory.js';
export { callService, serviceRegistry, type IServiceCallResult, type IServiceError, type ServiceErrorType, } from './service-registry.js';
export { TypedAgent, createTypedAgent, typedText, typedObject, type TypedAgentCallOptions, type TypedAgentObjectOptions, type TypedAgentResult, type TypedAgentError, type TypedAgentErrorName, } from './typed-agent.js';
export { LLMRegistry, getDefaultRegistry, registerProvider, model, modelStrict, registerFromJupyterAI, createNativeFactory, openaiCompatibleFactory, type IProviderAuth, type ModelFactory, } from './llm-registry.js';
export { render, renderKernel, setTemplateBaseURL, ensureTemplatesLoaded, } from './prompts/template-engine.js';
export { generateAgentCodeForLanguage, generateJsPromiseAllBlock, generateGoCodeForLanguage, type IResolvedAgentCommand, } from './agent-code-generators.js';
export { toPlainObject, type IInterpreter, } from './display/display.js';
export { widget, widgetStateByID, Model, _internals, type Broadcast, type FrontEndModel, type Awaitable, type IWidgetOptions, } from './display/anywidget.js';
export { normalizeRunOutput, normalizeTraceback, } from './output-publisher.js';
//# sourceMappingURL=index.d.ts.map