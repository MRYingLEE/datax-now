/**
 * DataX API - Clean, Promise-based API for AI code generation
 *
 * Public exports from this module are re-exported in `src/index.ts`.
 * Keep the export surface stable.
 */
import { CodeCommandExecutor, } from './code-commands.js';
import { makeErrorResult } from './result-factory.js';
export { generateSessionId } from './ai_agents.js';
import { askAI, smartAsk as smartAskImpl } from './ai_agents.js';
/**
 * Ask AI a question with optional metadata context.
 */
export async function ask(question, options = {}) {
    return askAI(question, options.streaming !== false, options.displayId || '', options.metadata, options.abortSignal, options.timeoutMs, options.showStopButton ?? true);
}
// ============================================================================
// Helpers (Internal)
// ============================================================================
function getGlobalDataxNamespace() {
    const g = globalThis;
    return g?.datax ?? null;
}
function getExecutor(maxRetries) {
    const g = globalThis;
    const dataxNs = getGlobalDataxNamespace();
    if (!dataxNs) {
        return null;
    }
    return new CodeCommandExecutor({
        datax: dataxNs,
        getExecutionCount: () => g?._execution_count ?? 0,
        ...(typeof maxRetries === 'number' ? { maxRetries } : {}),
    });
}
function configurationError(tracebackLine) {
    return makeErrorResult(undefined, 'ConfigurationError', 'datax namespace not available in globalThis', [tracebackLine]);
}
/**
 * Get or create an executor, returning a configuration error if datax is unavailable.
 */
function requireExecutor(fnName, maxRetries) {
    if (maxRetries !== undefined && (!Number.isInteger(maxRetries) || maxRetries < 1 || maxRetries > 100)) {
        return makeErrorResult(undefined, 'ValidationError', 'maxRetries must be an integer between 1 and 100', [`Invalid maxRetries: ${String(maxRetries)}`]);
    }
    const executor = getExecutor(maxRetries);
    if (!executor) {
        return configurationError(`Ensure globalThis.datax is configured before calling ${fnName}`);
    }
    return executor;
}
// ============================================================================
// Namespace inspection (Public)
// ============================================================================
/**
 * Get namespace variables for a language
 */
export function getNamespace(language) {
    try {
        const dataxNs = getGlobalDataxNamespace();
        if (!dataxNs)
            return {};
        return dataxNs[language]?.vars ?? {};
    }
    catch {
        return {};
    }
}
// ============================================================================
// DataX API functions (Public)
// ============================================================================
/**
 * Generate code for a given requirement
 */
export async function genCode(requirement, options) {
    const language = options?.language ?? 'python';
    const result = requireExecutor('genCode', options?.maxRetries);
    if ('status' in result)
        return result;
    const metadata = options?.metadata ?? {};
    const constraints = options?.packageConstraints;
    switch (language) {
        case 'python': return result.pygen(requirement, metadata, constraints, options?.model);
        case 'javascript': return result.jsgen(requirement, metadata, constraints, options?.model);
        case 'r': return result.rgen(requirement, metadata, constraints, options?.model);
        default:
            return makeErrorResult(undefined, 'ConfigurationError', `Unsupported language: ${language}`, []);
    }
}
/**
 * Generic helper for single-method executor calls.
 * All pygen/jsgen/rgen/pygo/jsgo/rgo/gen/go/wildgo/wildgen share this pattern.
 */
async function executorCall(methodName, requirement, options) {
    const result = requireExecutor(methodName, options?.maxRetries);
    if ('status' in result)
        return result;
    const metadata = options?.metadata ?? {};
    const constraints = options?.packageConstraints;
    return result[methodName](requirement, metadata, constraints, options?.model);
}
/** Generate Python code without execution */
export async function pygen(requirement, options) {
    return executorCall('pygen', requirement, options);
}
/** Generate JavaScript code without execution */
export async function jsgen(requirement, options) {
    return executorCall('jsgen', requirement, options);
}
/** Generate R code without execution */
export async function rgen(requirement, options) {
    return executorCall('rgen', requirement, options);
}
/** Generate and execute Python code */
export async function pygo(requirement, options) {
    return executorCall('pygo', requirement, options);
}
/** Generate and execute JavaScript code */
export async function jsgo(requirement, options) {
    return executorCall('jsgo', requirement, options);
}
/** Generate and execute R code */
export async function rgo(requirement, options) {
    return executorCall('rgo', requirement, options);
}
/** Generate and execute code in the detected language */
export async function go(requirement, options) {
    return executorCall('go', requirement, options);
}
/** Auto-detect language and generate code without execution */
export async function gen(requirement, options) {
    return executorCall('gen', requirement, options);
}
/** Mixed-language code generation without execution (@wildgen) */
export async function wildgen(requirement, options) {
    return executorCall('wildgen', requirement, options);
}
/** Generate and execute mixed-language code */
export async function wildgo(requirement, options) {
    return executorCall('wildgo', requirement, options);
}
/** Get namespace variables for a language (alias for getNamespace) */
export function getVars(language) {
    return getNamespace(language);
}
/**
 * Get a CodeCommandExecutor instance backed by the current globalThis.datax
 * namespace. The executor is cached and recreated whenever globalThis.datax
 * changes (e.g. after kernel restart).
 *
 * This is the entry-point used by notebook cells that want direct access to
 * pygen/jsgen/rgen with the full three-parameter signature including
 * packageConstraints:
 *
 *   const executor = Module.jupyterAIAgents.dataxApi.getExecutor();
 *   await executor.pygen(requirement, {}, { required: ['pandas'] });
 */
let _dataxApiExecutor = null;
let _dataxApiExecutorDataxRef = null;
export function publicGetExecutor() {
    const g = globalThis;
    const dataxNs = getGlobalDataxNamespace();
    if (!dataxNs) {
        throw new Error('datax not available — ensure the kernel is fully initialised before calling getExecutor()');
    }
    // Recreate the executor if datax has been replaced (e.g. kernel restart).
    if (!_dataxApiExecutor || _dataxApiExecutorDataxRef !== dataxNs) {
        _dataxApiExecutor = new CodeCommandExecutor({
            datax: dataxNs,
            getExecutionCount: () => g?._execution_count ?? 0,
        });
        _dataxApiExecutorDataxRef = dataxNs;
    }
    return _dataxApiExecutor;
}
/**
 * Unified AI interaction: the model decides whether to respond with
 * prose, code, or both. Returns the decision and generated code blocks
 * WITHOUT executing them — execution is handled by xeus-x's execution layer.
 */
export async function smartAsk(question, options = {}) {
    return smartAskImpl(question, options);
}
/**
 * DataX API - convenient object that groups all API functions.
 * Generation-only — execution is handled by xeus-x's execution layer.
 */
export const dataxApi = {
    pygo,
    jsgo,
    rgo,
    pygen,
    jsgen,
    rgen,
    gen,
    wildgen,
    genCode,
    ask,
    smartAsk,
    getNamespace,
    getVars,
    getExecutor: publicGetExecutor,
};
//# sourceMappingURL=datax-api.js.map