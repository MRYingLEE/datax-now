/**
 * Code Generation Engine
 *
 * Standalone generation functions extracted from CodeCommandExecutor.
 * Each function receives an ICodeCommandContext to access shared helpers.
 */
import type { JSONObject } from '@lumino/coreutils';
import { Purpose, ScriptType } from './ai_agents.js';
import { type CachedDisplayData, type AIAgentsRequestType } from './cache-utils.js';
import { LanguageType_Lowercase } from './utilities.js';
import type { IPackageConstraints } from './datax-api.js';
import type { ICodeGoResult, ICodeCommandContext } from './code-commands-types.js';
/**
 * Emit a display_data message for generated code.
 */
export declare function emitGeneratedDisplay(options: {
    sourceTag: AIAgentsRequestType;
    requirement: string;
    generated: string;
    language?: LanguageType_Lowercase | string;
    detectedLanguage?: 'python' | 'javascript' | 'r';
    isMarkdown?: boolean;
    displayId?: string;
    summary?: string;
}): CachedDisplayData | null;
/**
 * Core code generation with retry logic for a single language.
 */
export declare function executeGenCodeGen(ctx: ICodeCommandContext, command: string, requirement: string, scriptType: ScriptType, language: LanguageType_Lowercase, languageKey: 'python' | 'javascript' | 'r', generatingMessage: string, generatedMessage: string, emptyErrorMessage: string, purpose?: Purpose, maxTries?: number, detectedLanguage?: 'python' | 'javascript' | 'r', metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string): Promise<ICodeGoResult>;
/**
 * Auto-detect language and generate code in a single detected language.
 */
export declare function executeSingleLangGen(ctx: ICodeCommandContext, languageConfig: Record<string, {
    command: string;
    scriptType: ScriptType;
    languageType: LanguageType_Lowercase;
    languageKey: 'python' | 'javascript' | 'r';
    generatingMessage: string;
    generatedMessage: string;
    emptyErrorMessage: string;
}>, requirement: string, maxTries?: number, metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string): Promise<ICodeGoResult>;
/**
 * Generate code in mixed-language mode (Python + R + JS fenced blocks).
 */
export declare function executeMixedGen(ctx: ICodeCommandContext, requirement: string, maxTries?: number, metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string, command?: string): Promise<ICodeGoResult>;
//# sourceMappingURL=code-gen-engine.d.ts.map