/**
 * DisplayManager - Handles all UI display operations for AI agents
 *
 * Provides a clean interface for showing messages, progress indicators,
 * and stop buttons in the Jupyter notebook cell output.
 * This module demonstrates deepening by encapsulating display logic behind a simple interface.
 */
import { type DisplayOptions } from './display-adapter.js';
export interface StopButtonResult {
    controller: AbortController;
    cleanup: () => Promise<void>;
    setLabel: (label: string) => void;
}
export declare class DisplayManager {
    private static _displayIdCounter;
    static show(message: string, options?: DisplayOptions): void;
    static createStopButton(initialLabel?: string): Promise<StopButtonResult>;
}
export default DisplayManager;
//# sourceMappingURL=display-manager.d.ts.map