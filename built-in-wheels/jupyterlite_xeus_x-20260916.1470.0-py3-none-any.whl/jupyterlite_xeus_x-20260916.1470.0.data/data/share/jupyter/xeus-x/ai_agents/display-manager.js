/**
 * DisplayManager - Handles all UI display operations for AI agents
 *
 * Provides a clean interface for showing messages, progress indicators,
 * and stop buttons in the Jupyter notebook cell output.
 * This module demonstrates deepening by encapsulating display logic behind a simple interface.
 */
import { DisplayAdapter } from './display-adapter.js';
export class DisplayManager {
    static show(message, options) {
        DisplayAdapter.markdown(message, options);
    }
    static async createStopButton(initialLabel = '⏹ Stop') {
        const displayId = `stop_${DisplayManager._displayIdCounter++}`;
        const channelName = `ai_agents_stop_${displayId}`;
        const g = globalThis;
        const transient = { display_id: displayId };
        const controller = new AbortController();
        let stopChannel = null;
        let currentLabel = initialLabel;
        const renderStopFrame = (stopped = false, hidden = false, activeLabel) => {
            const hiddenStyle = hidden ? 'display:none;' : 'display:inline-block;margin:4px 0 2px;';
            const disabledAttr = stopped ? 'disabled' : '';
            const buttonLabel = stopped ? 'Stopped' : activeLabel;
            const buttonTitle = stopped ? 'AI response generation stopped' : 'Stop AI response generation';
            const buttonBackground = stopped ? '#bdc3c7' : '#c0392b';
            const buttonColor = stopped ? '#4a4a4a' : '#fff';
            const buttonCursor = stopped ? 'not-allowed' : 'pointer';
            return `<div style="${hiddenStyle}">
        <button id="ai-agents-stop-button" type="button" title="${buttonTitle}" ${disabledAttr}
          style="display:inline-flex;align-items:center;gap:4px;padding:2px 10px;font-size:11px;font-family:var(--jp-ui-font-family,sans-serif);color:${buttonColor};background:${buttonBackground};border:none;border-radius:4px;cursor:${buttonCursor};vertical-align:middle;">
          ${buttonLabel}
        </button>
      </div>`;
        };
        const hideStopFrame = () => {
            DisplayAdapter.data({ 'text/markdown': '' }, {}, transient, true);
        };
        const setLabel = (label) => {
            currentLabel = label;
            const html = renderStopFrame(false, false, label || initialLabel);
            DisplayAdapter.data({ 'text/html-sandboxed': html }, { 'text/html-sandboxed': { width: '180px', height: '36px' } }, transient, true);
        };
        const setupFrame = async () => {
            const html = renderStopFrame(false, false, initialLabel);
            try {
                const displayed = DisplayAdapter.data({ 'text/html-sandboxed': html }, { 'text/html-sandboxed': { width: '180px', height: '36px' } }, transient);
                if (!displayed) {
                    g?._console?.warn?.('[AI_Agents][Stop] no display_data function available');
                }
            }
            catch (error) {
                g?._console?.warn?.('[AI_Agents][Stop] Display failed:', error);
            }
        };
        await setupFrame();
        if (typeof BroadcastChannel === 'function') {
            try {
                stopChannel = new BroadcastChannel(channelName);
                stopChannel.addEventListener('message', (event) => {
                    if (event?.data?.type !== 'stop' || controller.signal.aborted) {
                        return;
                    }
                    try {
                        controller.abort('Stopped by user');
                    }
                    catch (error) {
                        g?._console?.warn?.('[AI_Agents][Stop] controller.abort threw', error);
                    }
                });
            }
            catch (error) {
                g?._console?.warn?.('[AI_Agents][Stop] BroadcastChannel setup failed', error);
            }
        }
        const cleanup = async () => {
            try {
                stopChannel?.close();
            }
            catch { }
            hideStopFrame();
        };
        return { controller, cleanup, setLabel };
    }
}
DisplayManager._displayIdCounter = 0;
export default DisplayManager;
//# sourceMappingURL=display-manager.js.map