/**
 * Agent Skills Integration
 *
 * Reads available skills from `window.jupyter_ai.skills` (provided by
 * the @jupyterlite/ai global API) and injects them into the system
 * prompt so the LLM is aware of any domain-specific instructions.
 *
 * For the current codebase, most calls are one-shot prompt-style
 * invocations rather than persisted UI chat state. Keep the public
 * helper centered on AI SDK v6's top-level instructions/prompt model
 * and only construct `ModelMessage[]` directly when a caller explicitly
 * needs them.
 */
import type { ModelMessage } from 'ai';
export type SkillAwareMessage = ModelMessage;
export type SkillAwarePrompt = {
    instructions: string;
    prompt: string;
};
export declare function buildMessagesWithSkills(systemContent: string, userContent: string): SkillAwareMessage[];
export declare function buildSkillAwarePrompt(systemContent: string, userContent: string): SkillAwarePrompt;
//# sourceMappingURL=agent-skills.d.ts.map