const RUNTIME_ERROR_NAMES = new Set([
    'EvalError',
    'RangeError',
    'ReferenceError',
    'SyntaxError',
    'TypeError',
    'URIError',
]);
function getErrorMessage(error) {
    if (typeof error === 'object' && error !== null && 'message' in error) {
        return String(error.message ?? 'Unknown error');
    }
    return String(error ?? 'Unknown error');
}
function getErrorName(error) {
    if (typeof error === 'object' && error !== null && 'name' in error) {
        return String(error.name ?? '');
    }
    return '';
}
function getErrorStatusCode(error) {
    if (typeof error !== 'object' || error === null) {
        return undefined;
    }
    const record = error;
    const raw = record['statusCode'] ??
        record['status'] ??
        (typeof record['response'] === 'object' && record['response'] !== null
            ? record['response']['status']
            : undefined);
    const numeric = Number(raw);
    return Number.isFinite(numeric) ? numeric : undefined;
}
export function normalizeAIError(error) {
    const message = getErrorMessage(error);
    const name = getErrorName(error);
    const lower = message.toLowerCase();
    const statusCode = getErrorStatusCode(error);
    if (name === 'AbortError') {
        return { ename: 'AbortError', evalue: message };
    }
    if (name === 'TimeoutError' || lower.includes('timeout')) {
        return { ename: 'TimeoutError', evalue: message };
    }
    if (RUNTIME_ERROR_NAMES.has(name)) {
        return { ename: 'RuntimeError', evalue: message };
    }
    if (lower.includes('api key') ||
        lower.includes('authorization') ||
        lower.includes('unauthorized') ||
        statusCode === 401) {
        return { ename: 'ProviderAuthError', evalue: message };
    }
    return { ename: 'ProviderError', evalue: message };
}
export function normalizeServiceError(error) {
    const normalized = normalizeAIError(error);
    const statusCode = getErrorStatusCode(error);
    switch (normalized.ename) {
        case 'ProviderAuthError':
            return { type: 'ProviderAuthError', message: normalized.evalue, retryable: false };
        case 'TimeoutError':
            return { type: 'TimeoutError', message: normalized.evalue, retryable: true };
        case 'AbortError':
            return { type: 'AbortError', message: normalized.evalue, retryable: false };
        case 'RuntimeError':
            return { type: 'RuntimeError', message: normalized.evalue, retryable: false };
        case 'ProviderError':
        default:
            return {
                type: 'ProviderError',
                message: normalized.evalue,
                retryable: statusCode === 429 || (statusCode !== undefined && statusCode >= 500),
            };
    }
}
export function getErrorStatusInfo(error) {
    return {
        message: getErrorMessage(error),
        status: getErrorStatusCode(error),
        name: getErrorName(error),
    };
}
//# sourceMappingURL=ai-error-utils.js.map