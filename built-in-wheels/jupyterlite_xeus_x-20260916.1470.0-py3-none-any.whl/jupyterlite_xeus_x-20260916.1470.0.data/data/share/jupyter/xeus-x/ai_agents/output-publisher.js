/**
 * Output Publisher — output normalization utilities.
 *
 * Publishing functions (publishOutputItem, publishRunOutputs, publishExecutionError)
 * have been moved to xeus-x's execution layer (wasm_patches/datax-exec.js).
 * This module retains only the normalization helpers.
 */
// ---------------------------------------------------------------------------
// Normalization
// ---------------------------------------------------------------------------
/**
 * Normalize a raw output object (which may arrive as a JSON string, or
 * wrapped in an extra `data` envelope) into a standard IJupyterOutput shape.
 *
 * Returns `null` when the value cannot be recognized.
 */
export function normalizeRunOutput(output) {
    if (!output)
        return null;
    let item = output;
    if (typeof item === 'string') {
        try {
            item = JSON.parse(item);
        }
        catch {
            return null;
        }
    }
    if (item && typeof item === 'object') {
        // Unwrap { data: "<json>" } envelope
        if (typeof item.data === 'string') {
            try {
                const parsed = JSON.parse(item.data);
                if (parsed && typeof parsed === 'object' && parsed.output_type) {
                    return parsed;
                }
            }
            catch {
                // fall through
            }
        }
        // Unwrap { data: { output_type: ... } } envelope
        if (item.data && typeof item.data === 'object' && item.data.output_type) {
            return item.data;
        }
        // Already a Jupyter output
        if (item.output_type) {
            return item;
        }
    }
    return null;
}
// ---------------------------------------------------------------------------
// Publishing helpers
// ---------------------------------------------------------------------------
/**
 * Normalize a traceback value (array or string) into a single `\n`-joined string.
 */
export function normalizeTraceback(traceback) {
    if (Array.isArray(traceback)) {
        return traceback.map((line) => String(line ?? '')).join('\n');
    }
    if (traceback == null)
        return '';
    return String(traceback);
}
//# sourceMappingURL=output-publisher.js.map