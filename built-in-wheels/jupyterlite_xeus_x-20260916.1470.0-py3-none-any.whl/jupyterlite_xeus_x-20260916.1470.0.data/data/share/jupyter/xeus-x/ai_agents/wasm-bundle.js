/**
 * WASM Bundle for xeus-x JavaScript Sub-Kernel
 *
 * This file creates a self-contained bundle of the ai_agents library
 * that can be injected into the WASM module's post.js file.
 *
 * It exposes the ai_agents functionality on the global Module object
 * so it's accessible from the JavaScript sub-kernel in xeus-x.
 */
// Import all core functionality
import { Purpose, ScriptType, askAI, genCode as internalGenCode, fixCode, implementCode } from './ai_agents.js';
import { genCode } from './datax-api.js';
import { compressOutput, wrapCode, wrapJSON, wrapSection, extractCode, customTrim, convertToString } from './output-processor.js';
import * as utilities from './utilities.js';
import { CodeCommandExecutor } from './code-commands.js';
import { applyWidgetStateUpdate, pendingWidgetStateByID, widgetStateByID } from './display/anywidget.js';
import { callService, serviceRegistry } from './service-registry.js';
import { TypedAgent, createTypedAgent, typedObject, typedText } from './typed-agent.js';
import { generateAgentCodeForLanguage, generateJsPromiseAllBlock, generateGoCodeForLanguage, } from './agent-code-generators.js';
import packageJson from './package.json' with { type: 'json' };
const AI_AGENTS_REPO_VERSION = packageJson.version;
/**
 * Create a lazily-initialized dataxApi that wraps CodeCommandExecutor
 * The executor is created on first use with globalThis.datax
 */
function createDataxApi() {
    let executor = null;
    const getExecutor = () => {
        if (!executor) {
            const datax = globalThis.datax;
            if (!datax) {
                throw new Error('datax not available - kernel not fully initialized');
            }
            const config = {
                datax,
                maxRetries: 5,
            };
            executor = new CodeCommandExecutor(config);
        }
        return executor;
    };
    // Expose executor methods as thin async wrappers.
    const methodNames = [
        'pygo', 'jsgo', 'rgo',
        'pygen', 'jsgen', 'rgen', 'gen',
        'wildgen',
    ];
    const api = {};
    for (const name of methodNames) {
        api[name] = async (requirement, metadata) => getExecutor()[name](requirement, metadata ?? {});
    }
    api.ask = async (question, options) => getExecutor().ask(question, options);
    api.getExecutor = getExecutor;
    return api;
}
/**
 * Initialize the ai_agents module on the WASM Module object
 * This makes it accessible from C++ via EM_ASM or from JavaScript sub-kernel
 */
export function initializeAIAgents(moduleObj) {
    // Expose ai_agents on Module.jupyterAIAgents
    moduleObj.jupyterAIAgents = {
        compressOutput,
        wrapCode,
        wrapJSON,
        wrapSection,
        extractCode,
        customTrim,
        convertToString,
        Purpose,
        ScriptType,
        utilities,
        CodeCommandExecutor,
        genCode,
        fixCode,
        implementCode,
        callService,
        serviceRegistry,
        TypedAgent,
        createTypedAgent,
        typedText,
        typedObject,
        dataxApi: createDataxApi(),
        widgetStateByID, // Required for anywidget bidirectional state sync
        pendingWidgetStateByID,
        applyWidgetStateUpdate,
        // Agent code generators (ported from C++ agent_executor.cpp)
        generateAgentCodeForLanguage,
        generateJsPromiseAllBlock,
        generateGoCodeForLanguage,
        version: AI_AGENTS_REPO_VERSION,
    };
    // Expose fixCode directly on Module so C++ can call Module["fixCode"]
    moduleObj.fixCode = fixCode;
    moduleObj.implementCode = implementCode;
    moduleObj.callService = callService;
    // Also expose on globalThis for easier access
    if (typeof globalThis !== 'undefined') {
        globalThis._dataxnow_ = globalThis._dataxnow_ || {};
        globalThis._dataxnow_.jupyterAIAgents = moduleObj.jupyterAIAgents;
        globalThis._dataxnow_.fixCode = fixCode;
        globalThis._dataxnow_.implementCode = implementCode;
        globalThis._dataxnow_.askAI = askAI;
        globalThis._dataxnow_.smartAsk = dataxApi.smartAsk;
        globalThis._dataxnow_.callService = callService;
        globalThis._dataxnow_.serviceRegistry = serviceRegistry;
    }
}
// Auto-initialize if Module is available
if (typeof globalThis.Module !== 'undefined') {
    initializeAIAgents(globalThis.Module);
}
else if (typeof globalThis !== 'undefined') {
    // If Module doesn't exist yet, wait for it
    Object.defineProperty(globalThis, 'Module', {
        configurable: true,
        enumerable: true,
        set(value) {
            Object.defineProperty(globalThis, 'Module', {
                value,
                writable: true,
                configurable: true,
                enumerable: true,
            });
            initializeAIAgents(value);
        },
    });
}
// Export for use in other contexts
export { compressOutput, wrapCode, wrapJSON, wrapSection, extractCode, customTrim, convertToString, Purpose, ScriptType, utilities, CodeCommandExecutor, internalGenCode as genCode, fixCode, implementCode, callService, serviceRegistry, createDataxApi, };
// Create dataxApi instance for the default export
const dataxApi = createDataxApi();
// Default export that includes everything (webpack uses 'export: default')
export default {
    compressOutput,
    wrapCode,
    wrapJSON,
    wrapSection,
    extractCode,
    customTrim,
    convertToString,
    Purpose,
    ScriptType,
    utilities,
    CodeCommandExecutor,
    genCode: internalGenCode,
    fixCode,
    implementCode,
    callService,
    serviceRegistry,
    TypedAgent,
    createTypedAgent,
    typedText,
    typedObject,
    createDataxApi,
    dataxApi,
    initializeAIAgents,
    version: AI_AGENTS_REPO_VERSION,
};
//# sourceMappingURL=wasm-bundle.js.map