/**
 * RequirementSanitization - Sanitizes requirement strings for prompt inclusion
 *
 * Handles JSON.parse patterns in requirements to prevent XSS and ensure
 * safe string representation in prompts. Extracted from ai_agents.ts as part of deepening Candidate 1.
 */
export function sanitizeRequirement(requirement) {
    return requirement.replace(/JSON\.parse\(("(?:\\.|[^"\\])*")\)/g, (match, stringLiteral) => {
        try {
            const jsonText = JSON.parse(stringLiteral);
            // Deep stringify approach - the full implementation would use
            // ContextService.sanitizeContextValue for proper handling
            const parsed = JSON.parse(jsonText
                .replace(/\r/g, '\\r')
                .replace(/\n/g, '\\n')
                .replace(/\t/g, '\\t'));
            // For now, simplified sanitization
            if (typeof parsed === 'object' && parsed !== null) {
                return match; // Would normally call ContextService.sanitizeContextValue
            }
            return `JSON.parse(${JSON.stringify(JSON.stringify(parsed))})`;
        }
        catch {
            return match;
        }
    });
}
//# sourceMappingURL=requirement-sanitizer.js.map