import { createOpenAI } from '@ai-sdk/openai';
import type { EmbeddingModel, LanguageModel } from 'ai';
export type OpenAICompatibleConfig = {
    provider?: string;
    apiKey?: string;
    baseURL?: string;
    headers?: Record<string, string>;
};
export declare const DUMMY_API_KEY = "sk-no-key-required";
export declare function isNonEmptyString(value: unknown): value is string;
type CompatibleFetchOptions = {
    stripUnsupportedOptions?: boolean;
};
export declare function createCompatibleFetch(options?: CompatibleFetchOptions): typeof globalThis.fetch;
export declare function createCompatibleFetchWithAuthBehavior(options?: {
    stripAuthorization?: boolean;
    stripUnsupportedOptions?: boolean;
}): typeof globalThis.fetch;
export declare function buildOpenAICompatibleProviderOptions(config: OpenAICompatibleConfig): Parameters<typeof createOpenAI>[0];
export declare function createOpenAICompatibleLanguageModel(config: OpenAICompatibleConfig, modelName: string): LanguageModel;
export declare function createOpenAICompatibleEmbeddingModel(config: OpenAICompatibleConfig, modelName: string): EmbeddingModel;
export {};
//# sourceMappingURL=openai-compatible.d.ts.map