import { type CallWarning, type FinishReason, type FlexibleSchema, type GenerateTextResult, type LanguageModel, type LanguageModelUsage, type ModelMessage, Output, type StopCondition, type StreamTextResult, type ToolChoice, type ToolSet } from 'ai';
import type { ProviderOptions } from '@ai-sdk/provider-utils';
type NativeTextOutput = ReturnType<typeof Output.text>;
type NativeToolNames<TOOLS extends ToolSet> = Array<Extract<keyof TOOLS, string>>;
type IBaseNativeAgentOptions<TOOLS extends ToolSet = {}> = {
    model: LanguageModel;
    instructions?: string;
    temperature?: number;
    maxOutputTokens?: number;
    providerOptions?: ProviderOptions;
    tools?: TOOLS;
    toolChoice?: ToolChoice<TOOLS>;
    stopWhen?: StopCondition<TOOLS> | Array<StopCondition<TOOLS>>;
    activeTools?: NativeToolNames<TOOLS>;
};
type IObjectNativeAgentOptions<OBJECT, TOOLS extends ToolSet = {}> = IBaseNativeAgentOptions<TOOLS> & {
    schema: FlexibleSchema<OBJECT>;
    schemaName?: string;
    schemaDescription?: string;
};
type INativeCallOptions = {
    messages?: ModelMessage[];
    prompt?: string;
    abortSignal?: AbortSignal;
};
type NativeRuntimeContext = Record<string, never>;
type NativeTextGenerateResult<TOOLS extends ToolSet = {}> = GenerateTextResult<TOOLS, NativeRuntimeContext, NativeTextOutput>;
type NativeTextStreamResult<TOOLS extends ToolSet = {}> = StreamTextResult<TOOLS, NativeRuntimeContext, NativeTextOutput>;
type NativeObjectOutput<OBJECT> = ReturnType<typeof Output.object<OBJECT>>;
type NativeObjectGenerateSDKResult<OBJECT, TOOLS extends ToolSet = {}> = GenerateTextResult<TOOLS, NativeRuntimeContext, NativeObjectOutput<OBJECT>>;
type NativeObjectStreamSDKResult<OBJECT, TOOLS extends ToolSet = {}> = StreamTextResult<TOOLS, NativeRuntimeContext, NativeObjectOutput<OBJECT>>;
export type INativeTextGenerateResult<TOOLS extends ToolSet = {}> = {
    text: string;
    finishReason: FinishReason;
    usage: LanguageModelUsage;
    warnings?: CallWarning[];
    sdkResult: NativeTextGenerateResult<TOOLS>;
};
export type INativeTextStreamResult<TOOLS extends ToolSet = {}> = {
    textStream: NativeTextStreamResult<TOOLS>['textStream'];
    fullStream: NativeTextStreamResult<TOOLS>['fullStream'];
    sdkResult: NativeTextStreamResult<TOOLS>;
};
export type INativeObjectGenerateResult<OBJECT, TOOLS extends ToolSet = {}> = {
    output: OBJECT;
    text: string;
    finishReason: FinishReason;
    usage: LanguageModelUsage;
    warnings?: CallWarning[];
    sdkResult: NativeObjectGenerateSDKResult<OBJECT, TOOLS>;
};
export type INativeObjectStreamResult<OBJECT, TOOLS extends ToolSet = {}> = {
    partialObjectStream: NativeObjectStreamSDKResult<OBJECT, TOOLS>['partialOutputStream'];
    textStream: NativeObjectStreamSDKResult<OBJECT, TOOLS>['textStream'];
    fullStream: NativeObjectStreamSDKResult<OBJECT, TOOLS>['fullStream'];
    object: Promise<OBJECT>;
    sdkResult: NativeObjectStreamSDKResult<OBJECT, TOOLS>;
};
export declare function createNativeTextAgent<TOOLS extends ToolSet = {}>(options: IBaseNativeAgentOptions<TOOLS>): {
    stream: (callOptions: INativeCallOptions) => Promise<INativeTextStreamResult<TOOLS>>;
    generate: (callOptions: INativeCallOptions) => Promise<INativeTextGenerateResult<TOOLS>>;
};
export declare function createNativeObjectAgent<OBJECT, TOOLS extends ToolSet = {}>(options: IObjectNativeAgentOptions<OBJECT, TOOLS>): {
    stream: (callOptions: INativeCallOptions) => Promise<INativeObjectStreamResult<OBJECT, TOOLS>>;
    generate: (callOptions: INativeCallOptions) => Promise<INativeObjectGenerateResult<OBJECT, TOOLS>>;
};
export {};
//# sourceMappingURL=native-agent.d.ts.map