import { LLMRegistry, model as resolveRegisteredModel, registerFromJupyterAI, } from './llm-registry.js';
import { createOpenAICompatibleEmbeddingModel, createOpenAICompatibleLanguageModel, isNonEmptyString, } from './openai-compatible.js';
import { createFrontendDelegatedLanguageModel } from './frontend-delegated-model.js';
import { resolveWindow } from './utilities.js';
const DEFAULT_MODEL = 'gpt-5-mini';
export { DUMMY_API_KEY, createCompatibleFetch, isNonEmptyString } from './openai-compatible.js';
function getFiniteNumber(value) {
    return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
}
const TEMPERATURE_UNSUPPORTED_REASONING_MODELS = new Set([
    'gpt-5-mini',
]);
function getEffectiveModelName(config, modelOverride) {
    const trimmedOverride = typeof modelOverride === 'string' ? modelOverride.trim() : '';
    if (trimmedOverride.length === 0) {
        return typeof config?.model === 'string' ? config.model.trim().toLowerCase() : '';
    }
    const overrideModel = trimmedOverride.includes('/')
        ? trimmedOverride.slice(trimmedOverride.indexOf('/') + 1)
        : trimmedOverride;
    return overrideModel.trim().toLowerCase();
}
function sanitizeLLMRequestOptions(options, config, modelOverride) {
    const modelName = getEffectiveModelName(config, modelOverride);
    if (options.temperature !== undefined &&
        TEMPERATURE_UNSUPPORTED_REASONING_MODELS.has(modelName)) {
        const { temperature: _temperature, ...remainingOptions } = options;
        return remainingOptions;
    }
    return options;
}
/**
 * Resolve effective generation-call options from explicit per-request overrides
 * and the active provider's configured defaults.
 *
 * The AI SDK consumes these at call / agent-construction time rather than when
 * creating the provider-backed `LanguageModel` instance.
 */
export function resolveLLMRequestOptions(overrides = {}, config = getActiveProviderConfig(), modelOverride) {
    const providerTemperature = getFiniteNumber(config?.parameters?.temperature);
    const providerMaxOutputTokens = getFiniteNumber(config?.parameters?.maxOutputTokens);
    const overrideTemperature = getFiniteNumber(overrides.temperature);
    const overrideMaxOutputTokens = getFiniteNumber(overrides.maxOutputTokens);
    const resolvedOptions = {
        ...(overrideTemperature !== undefined
            ? { temperature: overrideTemperature }
            : providerTemperature !== undefined
                ? { temperature: providerTemperature }
                : {}),
        ...(overrideMaxOutputTokens !== undefined
            ? { maxOutputTokens: overrideMaxOutputTokens }
            : providerMaxOutputTokens !== undefined
                ? { maxOutputTokens: providerMaxOutputTokens }
                : {}),
    };
    return sanitizeLLMRequestOptions(resolvedOptions, config, modelOverride);
}
// ---------------------------------------------------------------------------
// Read the active provider from window.jupyter_ai
// ---------------------------------------------------------------------------
function getWindowCandidates() {
    const g = globalThis;
    return [...new Set([g?._window, g?.window, g].filter(Boolean))];
}
function getFirstRuntimeString(candidates, property) {
    for (const candidate of candidates) {
        if (isNonEmptyString(candidate?.[property])) {
            return candidate[property].trim();
        }
    }
    return undefined;
}
function normalizeBaseURL(value) {
    return typeof value === 'string' ? value.trim().replace(/\/+$/, '').toLowerCase() : '';
}
/**
 * Build a synthetic provider config from the `OPENAI_API_BASE` /
 * `OPENAI_API_KEY` / `OPENAI_API_MODEL` globals.
 *
 * These globals are seeded by `wasm_patches/post.js` (and consumed by the
 * synchronous XHR AI dispatch path in `xinterpreter_js.cpp`) so that a
 * default AI provider (the shared DataX proxy, or a locally configured
 * OpenAI/Azure-OpenAI-compatible endpoint) is available even when no
 * `window.jupyter_ai` settings provider has been configured.
 *
 * The async code paths (`askAI`, `genCode`, etc.) previously had no
 * equivalent fallback and would fail with "No active provider configured"
 * even though the same globals already let the synchronous service bridge
 * succeed. Mirroring that fallback here keeps both paths consistent.
 *
 * Returns `null` when `OPENAI_API_BASE` has not been set.
 */
function getEnvFallbackProviderConfig() {
    const candidates = getWindowCandidates();
    const base = getFirstRuntimeString(candidates, 'OPENAI_API_BASE') ?? '';
    if (!base) {
        return null;
    }
    const apiKey = getFirstRuntimeString(candidates, 'OPENAI_API_KEY') ?? 'datax.now';
    const model = getFirstRuntimeString(candidates, 'OPENAI_API_MODEL') ?? DEFAULT_MODEL;
    return {
        id: 'datax-fallback',
        provider: 'openai',
        model,
        name: 'DataX Fallback',
        baseURL: base.replace(/\/+$/, ''),
        apiKey,
        headers: {},
    };
}
const API_KEY_PLACEHOLDERS = new Set(['nokey', 'no-key', 'sk-no-key-required']);
function resolveProviderApiKey(providerApiKeys, windowObjects, provider, baseURL) {
    for (const providerApiKey of providerApiKeys) {
        if (isNonEmptyString(providerApiKey)
            && !API_KEY_PLACEHOLDERS.has(providerApiKey.trim().toLowerCase())) {
            return providerApiKey.trim();
        }
    }
    const providerBaseURL = normalizeBaseURL(baseURL);
    for (const windowObject of windowObjects) {
        const fallbackBaseURL = normalizeBaseURL(windowObject?.OPENAI_API_BASE);
        if (providerBaseURL
            && fallbackBaseURL === providerBaseURL
            && isNonEmptyString(windowObject?.OPENAI_API_KEY)) {
            return windowObject.OPENAI_API_KEY.trim();
        }
    }
    if (provider === 'generic'
        && typeof baseURL === 'string'
        && /^https:\/\/dataxnow\.helloway\.workers\.dev\/v1\/?$/i.test(baseURL.trim())) {
        return 'datax.now';
    }
    return undefined;
}
/**
 * Read the currently active provider configuration from `window.jupyter_ai`.
 *
 * Combines `jupyter_ai.active_provider` (or legacy `active_providers`)
 * with the matching entry in `jupyter_ai.settings.providers` to pick up
 * headers, parameters, and apiKey (when the upstream exposes it).
 *
 * Falls back to {@link getEnvFallbackProviderConfig} when no provider is
 * configured or `window.jupyter_ai` is not yet available, and returns
 * `null` only when neither source yields a usable provider.
 */
export function getActiveProviderConfig() {
    const windows = getWindowCandidates();
    const jupyterAI = windows
        .map((windowObject) => windowObject?.jupyter_ai)
        .find(Boolean);
    if (!jupyterAI) {
        return getEnvFallbackProviderConfig();
    }
    // Newer jupyter_ai builds expose `active_provider`; older ones used
    // `active_providers`. Prefer the configured default over the legacy field
    // because the latter can remain stale while settings are being restored.
    const providers = jupyterAI.settings?.providers ?? [];
    const defaultProviderId = typeof jupyterAI.settings?.defaultProvider === 'string'
        ? jupyterAI.settings.defaultProvider
        : '';
    const active = providers.find((p) => p?.id === defaultProviderId) ??
        jupyterAI.active_provider ??
        jupyterAI.active_providers ??
        providers[0];
    if (!active) {
        return getEnvFallbackProviderConfig();
    }
    // Find the full (sanitized) provider entry for headers / parameters / apiKey.
    const fullConfigs = windows.flatMap((windowObject) => {
        const configuredProviders = windowObject?.jupyter_ai?.settings?.providers;
        return Array.isArray(configuredProviders) ? configuredProviders : [];
    });
    const fullConfig = fullConfigs.find((p) => p?.id === active.id && isNonEmptyString(p?.apiKey))
        ?? fullConfigs.find((p) => p?.id === active.id);
    return {
        id: String(active.id),
        provider: String(active.provider),
        model: String(active.model),
        name: String(active.name),
        baseURL: active.baseURL ?? fullConfig?.baseURL,
        apiKey: resolveProviderApiKey([active.apiKey, fullConfig?.apiKey], windows, active.provider, active.baseURL ?? fullConfig?.baseURL),
        headers: active.headers ?? fullConfig?.headers,
        parameters: active.parameters ?? fullConfig?.parameters,
    };
}
function registerProviderAlias(registry, config, alias) {
    registry.registerProvider(alias, {
        apiKey: config.apiKey,
        baseURL: config.baseURL,
        headers: config.headers,
        defaultModel: config.model,
    }, (_auth, modelName) => createOpenAICompatibleLanguageModel(config, modelName));
}
function createRegistryFromProvider(config) {
    const registry = new LLMRegistry();
    registerProviderAlias(registry, config, config.provider || 'default');
    registerProviderAlias(registry, config, 'default');
    return registry;
}
function resolveModelFromConfig(config, modelId) {
    const trimmedModel = typeof modelId === 'string' ? modelId.trim() : '';
    const requestedModel = trimmedModel.includes('/')
        ? trimmedModel.slice(trimmedModel.indexOf('/') + 1)
        : trimmedModel || config.model || DEFAULT_MODEL;
    if (!isNonEmptyString(config.apiKey)
        && !Object.entries(config.headers ?? {}).some(([name, value]) => name.toLowerCase() === 'authorization' && isNonEmptyString(value))) {
        return createFrontendDelegatedLanguageModel(config, requestedModel);
    }
    const registry = createRegistryFromProvider(config);
    if (trimmedModel.length > 0) {
        if (trimmedModel.includes('/')) {
            return registry.model(trimmedModel);
        }
        return registry.model(`${config.provider}/${trimmedModel}`);
    }
    return registry.model(`${config.provider}/${config.model || DEFAULT_MODEL}`);
}
// ---------------------------------------------------------------------------
// LLM creation (Vercel AI SDK)
// ---------------------------------------------------------------------------
/**
 * Create a Vercel AI SDK `LanguageModelV1` instance from a provider config.
 *
 * Models are resolved through a per-provider registry first so that
 * `provider/model` identifiers and future native-provider factories have a
 * canonical path. The OpenAI-compatible transport remains the fallback
 * implementation behind that registry entry.
 */
export function createLLMFromProvider(config, _temperatureOverride) {
    return resolveModelFromConfig(config);
}
export function createEmbeddingModelFromProvider(config) {
    return createOpenAICompatibleEmbeddingModel(config, config.model || 'text-embedding-3-small');
}
// ---------------------------------------------------------------------------
// Per-request model override
// ---------------------------------------------------------------------------
/**
 * Public default model identifier used by the DataX API when no `model`
 * option is provided by the caller.
 */
export const DEFAULT_API_MODEL = 'openai/gpt-5-mini';
/** Legacy process-level model override for compatibility with older callers. */
let _modelOverride = undefined;
/**
 * Override the model used by the next LLM call.
 * Pass `undefined` to clear the override and restore the active provider's
 * configured model.
 *
 * @deprecated Prefer passing `modelOverride` directly to {@link getLLM} to
 * avoid shared mutable request state.
 */
export function setModelOverride(model) {
    _modelOverride = model;
}
function isRegistryModelOverride(modelOverride) {
    if (typeof modelOverride !== 'string') {
        return false;
    }
    const trimmed = modelOverride.trim();
    if (trimmed.length === 0) {
        return false;
    }
    const slashIdx = trimmed.indexOf('/');
    return slashIdx > 0 && slashIdx < trimmed.length - 1;
}
// ---------------------------------------------------------------------------
// Cached LLM getter
// ---------------------------------------------------------------------------
let _cachedLLM = null;
let _cachedConfigSnapshot = null;
let _cachedEmbeddingModel = null;
let _cachedEmbeddingConfigSnapshot = null;
/**
 * Get (or create) a cached LLM instance from the active `window.jupyter_ai`
 * provider.
 *
 * The cache is invalidated when the `jupyter_ai` reference changes (the
 * global-api replaces the frozen object on every settings update).
 *
 * When `modelOverride` is supplied (preferred) or when a per-request model
 * override is active via {@link setModelOverride} (legacy, WASM-only), the
 * cache is bypassed and a fresh instance is returned using the overridden
 * model with the rest of the active provider's settings.
 *
 * Prefer passing `modelOverride` directly rather than using
 * {@link setModelOverride} — the direct parameter is safe for concurrent
 * callers, whereas the module-level override is not.
 *
 * @param temperatureOverride  Optional temperature; falls back to the
 *                             provider's configured temperature.
 * @param modelOverride        Optional model id; bypasses the cache and
 *                             overrides the provider's configured model for
 *                             this single call.
 * @returns A `LanguageModel` or `null` when no provider is configured.
 */
export function getLLM(temperatureOverride, modelOverride) {
    const config = getActiveProviderConfig();
    if (!config) {
        return null;
    }
    // Explicit per-call model override takes precedence over the legacy global.
    const effectiveModelOverride = typeof modelOverride === 'string' && modelOverride.trim().length > 0
        ? modelOverride.trim()
        : _modelOverride;
    // When any model override is active, skip the cache entirely so
    // the specified model is always used without polluting the shared cache.
    if (effectiveModelOverride !== undefined) {
        if (isRegistryModelOverride(effectiveModelOverride)) {
            registerFromJupyterAI(undefined, 'default');
            return resolveRegisteredModel(effectiveModelOverride);
        }
        return resolveModelFromConfig({ ...config, model: effectiveModelOverride }, effectiveModelOverride);
    }
    // Invalidate cache when the jupyter_ai snapshot is replaced.
    const w = resolveWindow();
    const currentSnapshot = w?.jupyter_ai;
    if (_cachedLLM && _cachedConfigSnapshot === currentSnapshot && temperatureOverride === undefined) {
        return _cachedLLM;
    }
    const llm = createLLMFromProvider(config, temperatureOverride);
    // Only cache when no temperature override (callers with overrides get fresh instances).
    if (temperatureOverride === undefined) {
        _cachedLLM = llm;
        _cachedConfigSnapshot = currentSnapshot;
    }
    return llm;
}
export function getLLMRequestOptions(overrides = {}, modelOverride) {
    return resolveLLMRequestOptions(overrides, getActiveProviderConfig(), modelOverride);
}
export function getEmbeddingModel(modelOverride) {
    const config = getActiveProviderConfig();
    if (!config) {
        return null;
    }
    const effectiveModelOverride = typeof modelOverride === 'string' && modelOverride.trim().length > 0
        ? modelOverride.trim()
        : _modelOverride;
    if (effectiveModelOverride !== undefined) {
        return createEmbeddingModelFromProvider({ ...config, model: effectiveModelOverride });
    }
    const w = resolveWindow();
    const currentSnapshot = w?.jupyter_ai;
    if (_cachedEmbeddingModel && _cachedEmbeddingConfigSnapshot === currentSnapshot) {
        return _cachedEmbeddingModel;
    }
    const embeddingModel = createEmbeddingModelFromProvider(config);
    _cachedEmbeddingModel = embeddingModel;
    _cachedEmbeddingConfigSnapshot = currentSnapshot;
    return embeddingModel;
}
//# sourceMappingURL=llm-factory.js.map