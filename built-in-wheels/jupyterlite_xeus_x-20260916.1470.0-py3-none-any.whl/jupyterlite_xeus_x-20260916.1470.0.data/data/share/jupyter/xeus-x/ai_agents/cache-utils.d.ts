import type { JSONValue } from '@lumino/coreutils';
export type AIAgentsRequestType = 'pygen' | 'jsgen' | 'rgen' | 'gen' | 'wildgen' | 'pygo' | 'jsgo' | 'rgo' | 'go' | 'wildgo';
export type AIAgentsSource = AIAgentsRequestType;
export type CachedDisplayData = {
    output_type?: string;
    data?: Record<string, any>;
    metadata?: Record<string, any>;
    transient?: Record<string, any>;
};
export type GenCacheResult = {
    cached: true;
    generated: string;
    displayData: CachedDisplayData[];
};
type PackageConstraints = {
    required?: string[];
    optional?: string[];
    prohibited?: string[];
};
export declare function getRuntimeGenCache(options: {
    cellId?: string;
    requestType: AIAgentsRequestType;
    requirement: string;
    detectedLanguage?: string;
    replayAllowed?: boolean;
    packageConstraints?: PackageConstraints;
}): GenCacheResult | null;
export declare function clearRuntimeGenCache(options: {
    cellId?: string;
    requestType: AIAgentsRequestType;
    requirement: string;
    detectedLanguage?: string;
    packageConstraints?: PackageConstraints;
}): void;
export declare function setRuntimeGenCache(options: {
    cellId?: string;
    requestType: AIAgentsRequestType;
    requirement: string;
    detectedLanguage?: string;
    packageConstraints?: PackageConstraints;
    generated: string;
    displayData: CachedDisplayData[];
}): void;
export declare function normalizePrompt(prompt: string): string;
/**
 * Determine whether a cached source tag is compatible with the current request type.
 *
 * **Design principles:**
 * - `*gen` agents (pygen, jsgen, rgen) are compatible with their `*go` counterparts
 *   because both generate code for the same language.
 * - `go` (auto-detect) is compatible with ALL language-specific `*go` agents
 *   (`pygo`, `jsgo`, `rgo`) when the detected language matches, because `@variable`
 *   patterns (e.g. `@df_iris`) route through the C++ kernel as language-specific
 *   `*go` calls, but semantically they are variants of `go` (auto-detect).
 * - `wildgen` / `wildgo` are only compatible with each other because they handle
 *   mixed-language output which cannot be meaningfully cross-matched.
 *
 * **Compatibility matrix (requestType → allowed cached sources):**
 *
 * | Request | Compatible cached sources | Notes |
 * |---------|--------------------------|-------|
 * | `pygen` | `pygen`, `pygo` | Gen can replay go-produced code |
 * | `jsgen` | `jsgen`, `jsgo` | Same |
 * | `rgen`  | `rgen`, `rgo` | Same |
 * | `gen`   | `gen`, `go` | Pure auto-detect only |
 * | `wildgen` | `wildgen`, `wildgo` | Mixed-language only |
 * | `pygo`  | `pygo`, `pygen`, `go` | Go-produced code reusable if language matches |
 * | `jsgo`  | `jsgo`, `jsgen`, `go` | Same |
 * | `rgo`   | `rgo`, `rgen`, `go` | Same |
 * | `go`    | `go`, `pygo`, `jsgo`, `rgo`, `pygen`, `jsgen`, `rgen` | Auto-detect can reuse any language-specific cache |
 * | `wildgo` | `wildgo`, `wildgen` | Mixed-language only |
 */
export declare function isSourceCompatible(requestType: AIAgentsRequestType, cachedSource: AIAgentsSource, requestDetectedLanguage?: string, cachedDetectedLanguage?: string): boolean;
export declare function checkGenCache(options: {
    requestType: AIAgentsRequestType;
    requirement: string;
    lastExecuteIO?: JSONValue;
    detectedLanguage?: string;
    replayAllowed?: boolean;
    packageConstraints?: PackageConstraints;
}): GenCacheResult | null;
export declare function replayDisplayData(items: CachedDisplayData[]): void;
export {};
//# sourceMappingURL=cache-utils.d.ts.map