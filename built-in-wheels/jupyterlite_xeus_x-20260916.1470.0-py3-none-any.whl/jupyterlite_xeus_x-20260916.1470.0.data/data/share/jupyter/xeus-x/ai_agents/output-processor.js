import { extractFencedBlocks } from './utilities.js';
const PRIORITY_KEYS = [
    'text/markdown',
    'text/html',
    'application/json',
    'text/latex',
    'image/svg+xml',
    'text/plain',
];
/**
 * Transforms a JSON object or array according to specific rules.
 * Standalone pure function.
 * @param json - The input JSON value to transform
 * @returns The transformed JSON value
 */
export function compressOutput(json) {
    // Handle arrays
    if (Array.isArray(json)) {
        return json
            .map((item) => compressOutput(item))
            .filter((item) => !item?.metadata?.display_id?.startsWith('go_'));
    }
    // Handle non-object values
    if (typeof json !== 'object' || json === null) {
        return json;
    }
    const result = {};
    for (const [key, value] of Object.entries(json)) {
        // Skip empty values, including empty objects and arrays
        if (value === null ||
            value === undefined ||
            value === '' ||
            (typeof value === 'object' && Object.keys(value).length === 0)) {
            continue;
        }
        // Handle special case for 'data' key
        if (key === 'data') {
            const priorityEntry = findHighestPriorityEntry(value);
            if (priorityEntry) {
                result[key] = { [priorityEntry[0]]: priorityEntry[1] };
            }
            else {
                const transformed = compressOutput(value);
                if (Object.keys(transformed).length > 0) {
                    result[key] = transformed;
                }
            }
            continue;
        }
        // Recursively transform other objects
        const transformed = compressOutput(value);
        // Only add non-empty transformed values
        if (transformed !== null &&
            !(typeof transformed === 'object' && Object.keys(transformed).length === 0)) {
            result[key] = transformed;
        }
    }
    return result;
}
/**
 * Finds the highest priority entry in an object based on PRIORITY_KEYS.
 * Standalone pure helper.
 * @param obj - The object to search through
 * @returns A tuple of [key, value] or null if no priority entry is found
 */
function findHighestPriorityEntry(obj) {
    for (const priorityKey of PRIORITY_KEYS) {
        if (priorityKey in obj && obj[priorityKey] !== null && obj[priorityKey] !== '') {
            return [priorityKey, obj[priorityKey]];
        }
    }
    return null;
}
function matchesFenceLanguageTag(token, language) {
    const normalizedToken = String(token ?? '').trim().toLowerCase();
    const normalizedLanguage = String(language ?? '').trim().toLowerCase();
    if (normalizedToken.length === 0 || normalizedLanguage.length === 0) {
        return false;
    }
    const aliasMap = {
        python: ['python', 'py'],
        javascript: ['javascript', 'js'],
        typescript: ['typescript', 'ts'],
        r: ['r', 'rlang'],
    };
    const aliases = aliasMap[normalizedLanguage] ?? [normalizedLanguage];
    return aliases.includes(normalizedToken);
}
function normalizeCodeBodyForDisplay(code, language) {
    let text = String(code ?? '').replace(/\r\n?/g, '\n').replace(/^\n+/, '');
    const openingFenceMatch = text.match(/^\s*(?:```|~~~)([^\n]*)/);
    if (openingFenceMatch) {
        const fenceSuffix = openingFenceMatch[1] ?? '';
        let remainder = text.slice(openingFenceMatch[0].length);
        if (remainder.startsWith('\n')) {
            remainder = remainder.slice(1);
        }
        const trimmedSuffix = fenceSuffix.trim();
        if (trimmedSuffix.length === 0) {
            text = remainder;
        }
        else {
            const languageAndInlineCode = trimmedSuffix.match(/^([A-Za-z0-9_+-]+)(?:\s+([\s\S]*))?$/);
            if (languageAndInlineCode &&
                matchesFenceLanguageTag(languageAndInlineCode[1], language)) {
                const inlineCode = languageAndInlineCode[2] ?? '';
                text = inlineCode.length > 0
                    ? `${inlineCode}${remainder.length > 0 ? `\n${remainder}` : ''}`
                    : remainder;
            }
            else {
                text = `${trimmedSuffix}${remainder.length > 0 ? `\n${remainder}` : ''}`;
            }
        }
    }
    return text.replace(/\n?(?:```|~~~)\s*$/, '');
}
/**
 * Utility methods for wrapping content.
 * Standalone pure function.
 */
export function wrapCode(code, language) {
    return `\`\`\`${language}\n${code}\n\`\`\`\n`;
}
/**
 * Wrap content for notebook markdown display, normalizing any pre-existing
 * fence so the display never nests duplicate language fences.
 */
export function wrapCodeForDisplay(code, language, closeFence = true) {
    const body = normalizeCodeBodyForDisplay(code, language);
    const normalizedBody = body.endsWith('\n') ? body : `${body}\n`;
    return closeFence
        ? `\`\`\`${language}\n${normalizedBody}\`\`\`\n`
        : `\`\`\`${language}\n${normalizedBody}`;
}
/**
 * Standalone pure function.
 */
export function wrapJSON(j) {
    return '```json\n' + j + '\n```\n';
}
/**
 * Standalone pure function.
 */
export function wrapSection(content, sectionName = 'text') {
    return '```' + sectionName + '\n' + content + '\n```\n';
}
/**
 * Standalone pure function.
 */
export function customTrim(str) {
    // regular expression to match leading and trailing " and space
    const regex = /^[\s"]+|[\s"]+$/g;
    return str.replace(regex, '');
}
/**
 * Standalone pure function.
 */
export function convertToString(preview) {
    if (!preview) {
        return '';
    }
    if (typeof preview === 'string') {
        return preview;
    }
    if (Array.isArray(preview) && preview.every((item) => typeof item === 'string')) {
        return preview.join('\n');
    }
    return '';
}
/**
 * Extract code from markdown content.
 * Extracts the last fenced code block from markdown.
 * Standalone pure function.
 */
export function extractCode(markdownContent) {
    const blocks = extractFencedBlocks(markdownContent);
    if (blocks.length > 0) {
        return blocks[blocks.length - 1].code.trim();
    }
    return markdownContent.trim();
}
//# sourceMappingURL=output-processor.js.map