export async function retryUntil(maxAttempts, attempt, isSuccess, delayMs = 0) {
    if (maxAttempts < 1) {
        throw new RangeError(`retryUntil requires maxAttempts >= 1, got ${maxAttempts}`);
    }
    let lastResult;
    let attemptIndex = 0;
    while (attemptIndex < maxAttempts) {
        if (attemptIndex > 0 && delayMs > 0) {
            // Exponential backoff: delayMs, 2*delayMs, 4*delayMs, ...
            await new Promise(r => setTimeout(r, delayMs * Math.pow(2, attemptIndex - 1)));
        }
        attemptIndex++;
        lastResult = await attempt(attemptIndex);
        if (isSuccess(lastResult)) {
            return { result: lastResult, attempts: attemptIndex };
        }
    }
    return {
        result: lastResult,
        attempts: attemptIndex,
    };
}
//# sourceMappingURL=retry.js.map