export declare const GENAI_MAX_ATTEMPTS = 10;
export declare const GENAI_MAX_RETRIES: number;
export declare const GENAI_MAX_429_RETRIES = 50;
export declare const GENAI_INITIAL_429_RETRY_DELAY_MS = 500;
export declare const GENAI_MAX_429_RETRY_DELAY_MS = 10000;
//# sourceMappingURL=genai-retry.d.ts.map