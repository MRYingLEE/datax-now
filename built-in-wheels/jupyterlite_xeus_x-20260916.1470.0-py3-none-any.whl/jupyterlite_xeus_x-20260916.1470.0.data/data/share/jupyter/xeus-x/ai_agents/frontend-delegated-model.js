const CHANNEL_NAME = 'datax-now.ai-provider.v1';
const REQUEST_TIMEOUT_MS = 120000;
function createRequestId() {
    const cryptoObject = globalThis.crypto;
    if (typeof cryptoObject?.randomUUID === 'function') {
        return cryptoObject.randomUUID();
    }
    return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
function createChannel() {
    if (typeof BroadcastChannel === 'undefined') {
        throw new Error('The configured Jupyter AI provider requires the DataX frontend bridge, but BroadcastChannel is unavailable.');
    }
    return new BroadcastChannel(CHANNEL_NAME);
}
function withoutAbortSignal(options) {
    const { abortSignal: _abortSignal, ...serializableOptions } = options;
    return serializableOptions;
}
function bridgeError(message) {
    return new Error(`Jupyter AI provider bridge failed: ${message}`);
}
function postCancel(channel, requestId) {
    const message = { type: 'cancel', requestId };
    channel.postMessage(message);
}
async function generateViaFrontend(config, model, options) {
    const channel = createChannel();
    const requestId = createRequestId();
    return new Promise((resolve, reject) => {
        const finish = () => {
            clearTimeout(timeout);
            options.abortSignal?.removeEventListener('abort', abort);
            channel.close();
        };
        const abort = () => {
            postCancel(channel, requestId);
            finish();
            reject(options.abortSignal?.reason ?? new DOMException('The operation was aborted.', 'AbortError'));
        };
        const timeout = setTimeout(() => {
            postCancel(channel, requestId);
            finish();
            reject(bridgeError('timed out waiting for the frontend'));
        }, REQUEST_TIMEOUT_MS);
        channel.onmessage = (event) => {
            const message = event.data;
            if (!message || message.requestId !== requestId) {
                return;
            }
            if (message.type === 'result') {
                finish();
                resolve(message.result);
            }
            else if (message.type === 'error') {
                finish();
                reject(bridgeError(message.message));
            }
        };
        options.abortSignal?.addEventListener('abort', abort, { once: true });
        if (options.abortSignal?.aborted) {
            abort();
            return;
        }
        const request = {
            type: 'request',
            requestId,
            operation: 'generate',
            providerId: config.id,
            model,
            options: withoutAbortSignal(options),
        };
        try {
            channel.postMessage(request);
        }
        catch (error) {
            finish();
            reject(bridgeError(error instanceof Error ? error.message : String(error)));
        }
    });
}
async function streamViaFrontend(config, model, options) {
    const channel = createChannel();
    const requestId = createRequestId();
    let finish = () => {
        channel.close();
    };
    const stream = new ReadableStream({
        start(controller) {
            finish = () => {
                clearTimeout(timeout);
                options.abortSignal?.removeEventListener('abort', abort);
                channel.close();
            };
            const fail = (error) => {
                finish();
                controller.error(error);
            };
            const abort = () => {
                postCancel(channel, requestId);
                fail(options.abortSignal?.reason ?? new DOMException('The operation was aborted.', 'AbortError'));
            };
            const timeout = setTimeout(() => {
                postCancel(channel, requestId);
                fail(bridgeError('timed out waiting for the frontend'));
            }, REQUEST_TIMEOUT_MS);
            channel.onmessage = (event) => {
                const message = event.data;
                if (!message || message.requestId !== requestId) {
                    return;
                }
                if (message.type === 'stream-part') {
                    controller.enqueue(message.part);
                }
                else if (message.type === 'stream-end') {
                    finish();
                    controller.close();
                }
                else if (message.type === 'error') {
                    fail(bridgeError(message.message));
                }
            };
            options.abortSignal?.addEventListener('abort', abort, { once: true });
            if (options.abortSignal?.aborted) {
                abort();
                return;
            }
            const request = {
                type: 'request',
                requestId,
                operation: 'stream',
                providerId: config.id,
                model,
                options: withoutAbortSignal(options),
            };
            try {
                channel.postMessage(request);
            }
            catch (error) {
                fail(bridgeError(error instanceof Error ? error.message : String(error)));
            }
        },
        cancel() {
            postCancel(channel, requestId);
            finish();
        },
    });
    return { stream };
}
export function createFrontendDelegatedLanguageModel(config, model) {
    return {
        specificationVersion: 'v4',
        provider: `frontend:${config.provider}`,
        modelId: model,
        supportedUrls: {},
        doGenerate: options => generateViaFrontend(config, model, options),
        doStream: options => streamViaFrontend(config, model, options),
    };
}
//# sourceMappingURL=frontend-delegated-model.js.map