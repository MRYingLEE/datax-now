/**
 * Code Command Execution API
 * Provides @pygo, @jsgo, @rgo, @go command functionality
 *
 * These commands generate code using AI and automatically execute it with retry logic.
 *
 * Heavy generation and execution logic lives in:
 *   - code-gen-engine.ts  (generation with retry, caching, display)
 *   - code-exec-engine.ts (proxy execution, fenced-block runners)
 */
import { Purpose, ScriptType, generateSessionId } from './ai_agents.js';
import { resolveMetadata as resolveMetadataShared } from './cell-ai_agents-context.js';
import { createLogger } from './logger.js';
import { makeErrorResult } from './result-factory.js';
import { CONSTANTS, LanguageType_Lowercase, detectLanguage, extractFencedBlocks, normalizeFenceLanguage, } from './utilities.js';
import { executeGenCodeGen, executeSingleLangGen, executeMixedGen, } from './code-gen-engine.js';
import { buildRuntimeRepairCallback, executeGeneratedCodeWithRetry, } from './go-execution.js';
const { debug: _debug } = createLogger('[AI_Agents]');
/**
 * Code Command Executor
 * Manages AI code generation and execution for multiple languages
 */
export class CodeCommandExecutor {
    constructor(config) {
        this.languageConfig = {
            python: {
                command: '@pygo',
                genCommand: '@pygen',
                scriptType: ScriptType.PyOnly,
                languageType: LanguageType_Lowercase.Python,
                languageKey: 'python',
                generatingMessage: CONSTANTS.GENERATING_PYTHON_CODE,
                generatedMessage: CONSTANTS.GENERATED_PYTHON_CODE,
                emptyErrorMessage: CONSTANTS.AI_CODE_GENERATION_EMPTY_RESULT,
            },
            javascript: {
                command: '@jsgo',
                genCommand: '@jsgen',
                scriptType: ScriptType.JsOnly,
                languageType: LanguageType_Lowercase.JavaScript,
                languageKey: 'javascript',
                generatingMessage: CONSTANTS.GENERATING_JAVASCRIPT_CODE,
                generatedMessage: CONSTANTS.GENERATED_JAVASCRIPT_CODE,
                emptyErrorMessage: CONSTANTS.AI_JAVASCRIPT_GENERATION_EMPTY_RESULT,
            },
            r: {
                command: '@rgo',
                genCommand: '@rgen',
                scriptType: ScriptType.ROnly,
                languageType: LanguageType_Lowercase.R,
                languageKey: 'r',
                generatingMessage: CONSTANTS.GENERATING_R_CODE,
                generatedMessage: CONSTANTS.GENERATED_R_CODE,
                emptyErrorMessage: CONSTANTS.AI_R_GENERATION_EMPTY_RESULT,
            },
        };
        this.config = config;
    }
    // ---------------------------------------------------------------------------
    // ICodeCommandContext implementation (shared with engine modules)
    // ---------------------------------------------------------------------------
    createSessionId(prefix) {
        const normalized = String(prefix ?? '')
            .replace(/^@/, '')
            .replace(/[^a-z0-9_]+/gi, '_')
            .replace(/^_+|_+$/g, '');
        return generateSessionId(normalized || 'code');
    }
    resolveSourceTag(command) {
        return String(command ?? '').replace(/^@/, '').trim();
    }
    resolveMetadata(metadata = {}) {
        const resolved = resolveMetadataShared(metadata);
        const cellId = resolved.cellId;
        if (typeof cellId === 'string') {
            _debug(`resolved cellId: ${cellId}`);
        }
        else {
            _debug('No cellId available in metadata or cell context');
        }
        return resolved;
    }
    /**
     * Update configuration
     */
    updateConfig(config) {
        this.config = { ...this.config, ...config };
    }
    getExecutionCount() {
        return this.config.getExecutionCount?.() ?? 0;
    }
    resolveLanguageProxy(languageKey) {
        return this.config.datax?.[languageKey] ?? null;
    }
    // ---------------------------------------------------------------------------
    // Code generation (delegates to code-gen-engine.ts)
    // ---------------------------------------------------------------------------
    /**
     * Generate code for a single language.
     * Shared by pygen, jsgen, and rgen to avoid duplicating the delegation call.
     */
    langGen(language, requirement, metadata = {}, packageConstraints, model) {
        const cfg = this.languageConfig[language];
        return executeGenCodeGen(this, cfg.genCommand, requirement, cfg.scriptType, cfg.languageType, cfg.languageKey, cfg.generatingMessage, cfg.generatedMessage, cfg.emptyErrorMessage, Purpose.FirstGen, this.config.maxRetries ?? 5, undefined, metadata, packageConstraints, model);
    }
    /** Python code generation only (@pygen) */
    pygen(requirement, metadata = {}, packageConstraints, model) {
        return this.langGen('python', requirement, metadata, packageConstraints, model);
    }
    /** JavaScript code generation only (@jsgen) */
    jsgen(requirement, metadata = {}, packageConstraints, model) {
        return this.langGen('javascript', requirement, metadata, packageConstraints, model);
    }
    /** R code generation only (@rgen) */
    rgen(requirement, metadata = {}, packageConstraints, model) {
        return this.langGen('r', requirement, metadata, packageConstraints, model);
    }
    /**
     * Generate and execute code for a single language with runtime-error retry.
     * Shared by pygo, jsgo, and rgo.
     */
    async langGo(language, requirement, metadata = {}, packageConstraints, model) {
        const cfg = this.languageConfig[language];
        const proxy = this.resolveLanguageProxy(cfg.languageKey);
        if (!proxy) {
            return makeErrorResult(this.config.getExecutionCount, 'ConfigurationError', `Unsupported language: ${cfg.languageKey}`, [`${cfg.command} does not support language: ${cfg.languageKey}`]);
        }
        const resolvedMetadata = this.resolveMetadata(metadata);
        const genResult = await executeGenCodeGen(this, cfg.command, requirement, cfg.scriptType, cfg.languageType, cfg.languageKey, cfg.generatingMessage, cfg.generatedMessage, cfg.emptyErrorMessage, Purpose.FirstGen, this.config.maxRetries ?? 5, undefined, resolvedMetadata, packageConstraints, model);
        return executeGeneratedCodeWithRetry({
            genResult,
            command: cfg.command,
            requirement,
            languageKey: cfg.languageKey,
            languageType: cfg.languageType,
            proxy,
            metadata: resolvedMetadata,
            maxAttempts: this.config.maxRetries ?? 5,
            getExecutionCount: this.config.getExecutionCount,
            repairCode: buildRuntimeRepairCallback({
                command: cfg.command,
                languageKey: cfg.languageKey,
                languageType: cfg.languageType,
            }),
        });
    }
    /** Generate and execute Python code (@pygo) */
    pygo(requirement, metadata = {}, packageConstraints, model) {
        return this.langGo('python', requirement, metadata, packageConstraints, model);
    }
    /** Generate and execute JavaScript code (@jsgo) */
    jsgo(requirement, metadata = {}, packageConstraints, model) {
        return this.langGo('javascript', requirement, metadata, packageConstraints, model);
    }
    /** Generate and execute R code (@rgo) */
    rgo(requirement, metadata = {}, packageConstraints, model) {
        return this.langGo('r', requirement, metadata, packageConstraints, model);
    }
    /**
     * Auto-detect language and generate code in single language (@gen)
     * Auto-detects the target language and generates code without executing it
     */
    async gen(requirement, metadata = {}, packageConstraints, model) {
        return executeSingleLangGen(this, this.languageConfig, requirement, this.config.maxRetries ?? 5, metadata, packageConstraints, model);
    }
    /** Auto-detect language, generate, and execute code (@go). */
    async go(requirement, metadata = {}, packageConstraints, model) {
        const generated = await executeSingleLangGen(this, this.languageConfig, requirement, this.config.maxRetries ?? 5, metadata, packageConstraints, model);
        if (generated.status !== 'ok' || !generated.generated || !generated.detectedLanguage) {
            return generated;
        }
        const language = detectLanguage(requirement);
        const proxy = this.resolveLanguageProxy(language);
        if (!proxy) {
            return makeErrorResult(this.config.getExecutionCount, 'ConfigurationError', `Unsupported language: ${language}`, [`@go does not support language: ${language}`]);
        }
        const cfg = this.languageConfig[language];
        return executeGeneratedCodeWithRetry({
            genResult: generated,
            command: '@go',
            requirement,
            languageKey: cfg.languageKey,
            languageType: cfg.languageType,
            proxy,
            metadata: this.resolveMetadata(metadata),
            maxAttempts: this.config.maxRetries ?? 5,
            getExecutionCount: this.config.getExecutionCount,
            repairCode: buildRuntimeRepairCallback({
                command: '@go',
                languageKey: cfg.languageKey,
                languageType: cfg.languageType,
            }),
        });
    }
    /**
     * Mixed-language code generation only (@wildgen)
     * Generates fenced markdown with multiple languages without executing it
     */
    async wildgen(requirement, metadata = {}, packageConstraints, model) {
        return executeMixedGen(this, requirement, this.config.maxRetries ?? 5, metadata, packageConstraints, model);
    }
    /** Generate and execute mixed-language fenced code (@wildgo). */
    async wildgo(requirement, metadata = {}, packageConstraints, model) {
        const generated = await executeMixedGen(this, requirement, this.config.maxRetries ?? 5, metadata, packageConstraints, model, '@wildgo');
        if (generated.status !== 'ok' || !generated.generated) {
            return generated;
        }
        const blocks = extractFencedBlocks(generated.generated);
        let executionCount = generated.execution_count;
        for (const block of blocks) {
            const language = normalizeFenceLanguage(block.language);
            const languageKey = language === 'python' || language === 'javascript' || language === 'r'
                ? language
                : undefined;
            if (!languageKey) {
                continue;
            }
            const proxy = this.resolveLanguageProxy(languageKey);
            if (!proxy) {
                return makeErrorResult(this.config.getExecutionCount, 'ConfigurationError', `Unsupported language: ${languageKey}`, [`@wildgo does not support language: ${languageKey}`]);
            }
            const cfg = this.languageConfig[languageKey];
            const result = await executeGeneratedCodeWithRetry({
                genResult: { status: 'ok', generated: block.code, detectedLanguage: languageKey },
                command: '@wildgo',
                requirement,
                languageKey,
                languageType: cfg.languageType,
                proxy,
                metadata: this.resolveMetadata(metadata),
                maxAttempts: this.config.maxRetries ?? 5,
                getExecutionCount: this.config.getExecutionCount,
                repairCode: buildRuntimeRepairCallback({
                    command: '@wildgo',
                    languageKey,
                    languageType: cfg.languageType,
                }),
            });
            if (result.status !== 'ok') {
                return result;
            }
            executionCount = result.execution_count;
        }
        return { ...generated, execution_count: executionCount };
    }
    // ---------------------------------------------------------------------------
    // Ask
    // ---------------------------------------------------------------------------
    /**
     * Ask AI a question with optional metadata context
     * @param question The question to ask
     * @param options Options including metadata, streaming, and displayId
     * @returns AI's response as a string
     *
     * @example
     * ```typescript
     * const answer = await executor.ask("What is a prime number?");
     * const contextAnswer = await executor.ask("How did you generate that?", {
     *   metadata: { lastExecuteIO: previousExecution }
     * });
     * ```
     */
    async ask(question, metadata = {}) {
        const streaming = metadata?.streaming ?? true;
        const displayId = metadata?.displayId ?? '';
        const { askAI } = await import('./ai_agents.js');
        return askAI(question, streaming, displayId, metadata);
    }
}
//# sourceMappingURL=code-commands.js.map