/**
 * AI Code Generation and Processing
 
 */
import type { JSONValue, JSONObject } from '@lumino/coreutils';
import { LanguageType_Lowercase } from './utilities.js';
export declare function getAIAgentsConfigSummary(): any;
/**
 * Generate a unique session ID - standalone utility function
 */
export declare function generateSessionId(prefix: string): string;
/**
 * Ask AI a question - standalone function
 * @param question The question to ask
 * @param streaming Whether to stream the response
 * @param displayId Display ID for output updates
 * @param metadata Optional metadata including lastExecuteIO for context
 * @param systemPromptOverride Optional override for the default ask system prompt
 */
export declare function askAI(question: string, streaming?: boolean, displayId?: string, metadata?: JSONObject, abortSignal?: AbortSignal, timeoutMs?: number, showStopButton?: boolean, systemPromptOverride?: string): Promise<string>;
/**
 * Get language configuration for script type - standalone utility function
 */
export declare function getLanguageConfig(scriptType: ScriptType): {
    wrapLanguage: string;
    suggestedLanguage: string;
};
export declare function usesDetailsProgressDisplay(purpose: Purpose): boolean;
export declare function buildInProgressCodeMarkdown(scriptType: ScriptType, fullText: string): string;
/**
 * Get kernel configuration for script type - standalone utility function.
 * Now async because kernel context is loaded from Handlebars templates at runtime.
 *
 * @param scriptType     Target script type
 * @param disallowedPackages  Legacy: Python-only disallowed packages (Set). Preserved for
 *                            backward compatibility. When `packageConstraints` is supplied
 *                            this parameter is ignored.
 * @param packageConstraints  Full required/optional/prohibited package constraints for all
 *                            languages. Supersedes `disallowedPackages` when present.
 */
export declare function getKernelConfig(scriptType: ScriptType, disallowedPackages?: Set<string>, packageConstraints?: {
    required?: string[];
    optional?: string[];
    prohibited?: string[];
}): Promise<{
    kernel: string;
    disallowedPackagesStr: string;
}>;
/**
 * A single extracted code block from the AI response.
 */
export interface ISmartAskCodeBlock {
    /** Detected language of the fenced block */
    language: 'python' | 'javascript' | 'r' | 'unknown';
    /** Raw code content (without fence markers) */
    code: string;
    /** Populated only when the caller opted into execution */
    executionResult?: any;
}
export interface ISmartAskStructuredResponse {
    answer: string;
    codeBlocks: Array<{
        language: 'python' | 'javascript' | 'r' | 'unknown';
        code: string;
    }>;
    shouldExecute: boolean;
    executionReason: string;
}
/**
 * Structured result from smartAsk.
 *
 * Combines a prose answer with zero-or-more executable code blocks
 * so the caller can inspect and optionally run them.
 */
export interface ISmartAskResult {
    status: 'ok' | 'error';
    /** Full raw markdown returned by the AI (prose + fenced code interleaved) */
    rawResponse: string;
    /** Prose-only portion (fenced code blocks stripped) */
    answer: string;
    /** Extracted fenced code blocks in order of appearance */
    codeBlocks: ISmartAskCodeBlock[];
    /** Convenience flag: true when codeBlocks.length > 0 */
    hasCode: boolean;
    /** Final execution decision for this response */
    shouldExecute: boolean;
    /** Where execution decision came from */
    executionDecisionSource: 'ai' | 'policy-always' | 'policy-never' | 'legacy-execute';
    /** Short explanation for the execution decision */
    executionReason?: string;
    /** True if code blocks were executed */
    executed: boolean;
    /** Error info (when status='error') */
    ename?: string;
    evalue?: string;
    traceback?: string[];
}
/**
 * Options for {@link smartAsk}.
 */
export interface ISmartAskOptions {
    /**
     * Execution policy for generated code blocks.
     * - `ai` (default): model decides whether execution should happen
     * - `always`: always execute when executable code blocks exist
     * - `never`: never execute automatically
     */
    executionPolicy?: 'ai' | 'always' | 'never';
    /**
     * @deprecated Use `executionPolicy` instead.
     * - `execute: true`  → `executionPolicy: 'always'`
     * - `execute: false` → `executionPolicy: 'never'`
     * This field will be removed in a future version.
     * @see executionPolicy
     */
    execute?: boolean;
    /** Stream tokens to the display as they arrive (default: true) */
    streaming?: boolean;
    /** Jupyter display_id for output updates */
    displayId?: string;
    /** Execution metadata (lastExecuteIO, cellId, etc.) */
    metadata?: JSONObject;
    /** Language hint — helps the AI prefer a language; it may still choose others */
    preferredLanguage?: 'python' | 'r' | 'javascript';
    /** Available variables the AI can reference when generating code */
    context?: Record<string, any> | string;
    /**
     * Override the default smartAsk system prompt.
     * When omitted, the built-in rendered prompt is used.
     */
    system_prompt?: string;
    /** Maximum retries on transient LLM failures (default: 3) */
    maxRetries?: number;
    /** Model identifier for this request. */
    model?: string;
    /**
     * Abort an in-progress call by passing an `AbortController.signal` here,
     * then calling `controller.abort()` from outside. The function will stop
     * streaming / generating and return an error result with `ename: 'AbortError'`.
     *
     * @example
     * ```typescript
     * const controller = new AbortController();
     * // Start call in background
     * const promise = smartAsk('...', { abortSignal: controller.signal });
     * // Cancel it at any time (e.g. user clicks Stop button)
     * controller.abort();
     * const result = await promise; // status: 'error', ename: 'AbortError'
     * ```
     */
    abortSignal?: AbortSignal;
    /**
     * Hard time limit in milliseconds. If the AI call does not complete within
     * this duration the function stops and returns an error result with
     * `ename: 'TimeoutError'`.
     *
     * @example
     * ```typescript
     * // Fail after 30 seconds
     * const result = await smartAsk('...', { timeoutMs: 30_000 });
     * ```
     */
    timeoutMs?: number;
    /**
     * Show an inline "Stop" button (anywidget) in the cell output.
     * Clicking it cancels the in-progress AI call immediately.
     * Defaults to `true`. Set to `false` to suppress the button (e.g. in
     * automated / programmatic scenarios where there is no human viewer).
     */
    showStopButton?: boolean;
}
/**
 * Internal extension of {@link ISmartAskOptions} for the executor wrapper.
 * Not part of the public API — external callers should not set _skipExecution.
 */
interface _ISmartAskInternalOptions extends ISmartAskOptions {
    /** Skip direct execution even when policy says execute (delegated to CodeCommandExecutor). */
    _skipExecution?: boolean;
}
/**
 * Extract all fenced code blocks from a markdown string.
 * Returns them in order of appearance with a normalised language tag.
 * Delegates to the shared extractFencedBlocks parser (utilities.ts) so that
 * cache lookups and smartAsk both parse identically.
 */
export declare function extractCodeBlocks(markdown: string): ISmartAskCodeBlock[];
/**
 * Strip fenced code blocks from markdown, returning prose only.
 * Preserves paragraph spacing.
 */
export declare function extractProse(markdown: string): string;
/**
 * Unified AI interaction that lets the model decide whether to respond with
 * prose, code, or both.  The caller receives a structured result and can
 * optionally execute any generated code blocks.
 *
 * @param question  Natural-language question or instruction
 * @param options   See {@link ISmartAskOptions}
 * @returns         Structured result — see {@link ISmartAskResult}
 *
 * @example
 * ```typescript
 * // Prose-only answer (AI decides no code is needed)
 * const r1 = await smartAsk('What is a DataFrame?');
 * console.log(r1.answer);     // explanation text
 * console.log(r1.hasCode);    // false
 *
 * // Code included (AI decides code helps)
 * const r2 = await smartAsk('Sort a list in Python');
 * console.log(r2.codeBlocks); // [{ language: 'python', code: '...' }]
 *
 * // Auto-execute the returned code blocks
 * const r3 = await smartAsk('Create a bar chart of sales data', {
 *   execute: true,
 *   preferredLanguage: 'python',
 *   context: { sales: [10, 20, 30] },
 * });
 * // r3.executed === true, r3.codeBlocks[0].executionResult populated
 * ```
 */
export declare function smartAsk(question: string, options?: ISmartAskOptions | _ISmartAskInternalOptions): Promise<ISmartAskResult>;
export declare enum Purpose {
    FirstGen = 0,
    FixRuntimeIssue = 1,
    FixStaticIssue = 2,
    Review = 3,
    AutoSuggest = 4,
    AutoSuggestOrFirstGen = 5,//TODO: Implement logic for AutoSuggestOrFirstGen. When the code could be default language or AI instruction.
    AutoImplement = 6
}
export declare enum ScriptType {
    JsOnly = "web Javascript",
    PyOnly = "python",
    ROnly = "R",
    PyJS = "both Python and web Javascript",
    PyR = "both Python and R",
    PyRJS = "Python, R and web Javascript"
}
/**
 * Generate code using AI based on requirements
 * @param currentPrompt The user's code generation request
 * @param realCode Whether this is real code or a test
 * @param currentContext Execution context (variables, modules)
 * @param modules Available modules in the environment
 * @param scriptType Target script type (Python, R, JavaScript, etc.)
 * @param sessionId Session identifier for display updates
 * @param summary_going Progress message during generation
 * @param summary_done Completion message
 * @param closed Whether display should start collapsed
 * @param maxTries Maximum retry attempts
 * @param purpose Generation purpose (FirstGen, FixRuntimeIssue, etc.)
 * @param usingPackages Packages being used
 * @param disallowedPackages Packages not allowed
 * @param metadata Pre-resolved or raw metadata (will be resolved via resolveMetadata)
 */
export interface ICodeGenDirectOptions {
    currentPrompt: string;
    realCode: boolean;
    currentContext: Record<string, any> | string;
    modules?: string[];
    scriptType: ScriptType;
    sessionId?: string;
    summary_going?: string;
    summary_done?: string;
    closed?: boolean;
    finalClosed?: boolean;
    maxTries?: number;
    purpose?: Purpose;
    usingPackages?: string[];
    disallowedPackages?: Set<string>;
    metadata?: JSONObject;
    cellIdOverride?: string;
    abortSignal?: AbortSignal;
    showStopButton?: boolean;
    /** Model identifier for this request. */
    model?: string;
}
export declare function genCode(options: ICodeGenDirectOptions): Promise<string>;
/**
 * Attempts to automatically fix failed code execution by regenerating code with AI
 *
 * @param result The execution result from code execution
 * @param code The original code that failed
 * @param metadata Execution metadata including lastExecuteIO
 * @param language Language type (Python, JavaScript, or R)
 * @param globalVars Global variables (for Python)
 * @param imports Available imports (for Python)
 * @param sharedNamespace Shared namespace (for JS/R)
 * @returns Standardized execution result (error result)
 */
export declare function fixCode(result: any, code: string, metadata: JSONObject, language: LanguageType_Lowercase, context?: Record<string, any> | string, imports?: string[], cellIdOverride?: string): Promise<any>;
/**
 * Auto-implementation: given a code cell containing placeholder markers, ask the AI
 * to generate a concrete implementation and replace the cell source in-place (just like
 * auto-fix). The generated code is streamed back via genCode / Purpose.AutoSuggest so
 * the unified-diff view works the same way as auto-fix.
 *
 * @param request   Parsed auto-implementation request (placeholders, etc.)
 * @param code      The full cell source (after magic stripping)
 * @param metadata  Cell metadata (must contain cellId so the cell can be updated)
 * @param language  Target language ('python' | 'javascript' | 'r')
 * @param globalVars  Current global variables for the active sub-kernel
 * @param imports     Detected imports / loaded packages
 * @param sharedNamespace  Shared cross-language namespace snapshot
 * @param cellIdOverride  Optional cell id override (takes priority over metadata.cellId)
 */
export declare function implementCode(request: any, code: string, metadata: JSONObject, language: LanguageType_Lowercase, context?: Record<string, any> | string, imports?: string[], cellIdOverride?: string): Promise<any>;
/**
 * Create prompt for code review/generation
 */
export declare function createPromptForCodeReview(lastRun: JSONValue | undefined, currentRequirement: string, realCode: boolean, currentContext: Record<string, any> | string, modules: string[] | undefined, purpose: Purpose, scriptType: ScriptType, usingPackages?: string[]): Promise<string>;
/**
 * Returns the TypedAgent wrapper syntax example for the given language.
 * Includes both a pure semantic (single-wrapper) example and a hybrid example
 * where deterministic code embeds `datax.typedagent()` calls for semantic sub-steps.
 * @internal exported for testing
 */
export declare function buildTypedAgentExample(scriptType: ScriptType): string;
/**
 * Returns the system prompt that classifies a function as semantic / algorithmic / hybrid
 * and instructs the LLM on how to implement each pattern.
 * @internal exported for testing
 */
export declare function buildAutoImplementTask(scriptType: ScriptType): string;
/**
 * Generate code using LLM
 */
export declare function generateCodeWithLLM(prompt: string, purpose: Purpose, scriptType: ScriptType, sessionId?: string, summary_going?: string, summary_done?: string, closed?: boolean, finalClosed?: boolean, disallowedPackages?: Set<string>, currentPrompt?: string, metadata?: JSONObject, abortSignal?: AbortSignal, model?: string): Promise<string>;
export {};
//# sourceMappingURL=ai_agents.d.ts.map