/**
 * DataX API - Clean, Promise-based API for AI code generation
 *
 * Public exports from this module are re-exported in `src/index.ts`.
 * Keep the export surface stable.
 */
import type { JSONValue, JSONObject } from '@lumino/coreutils';
import { CodeCommandExecutor, type ICodeGoResult } from './code-commands.js';
export { generateSessionId } from './ai_agents.js';
export type { ISmartAskResult, ISmartAskCodeBlock, ISmartAskOptions, } from './ai_agents.js';
export interface IAskOptions {
    metadata?: JSONObject;
    streaming?: boolean;
    displayId?: string;
    abortSignal?: AbortSignal;
    timeoutMs?: number;
    showStopButton?: boolean;
}
/**
 * Ask AI a question with optional metadata context.
 */
export declare function ask(question: string, options?: IAskOptions): Promise<string>;
/**
 * Package constraints for code generation.
 *
 * - `required`   — packages the AI MUST import (statically verified; violation retries)
 * - `optional`   — packages the AI is encouraged to prefer (hint only, no enforcement)
 * - `prohibited` — packages the AI MUST NOT import (statically verified; violation retries)
 */
export interface IPackageConstraints {
    required?: string[];
    optional?: string[];
    prohibited?: string[];
}
/**
 * Options for code generation operations
 */
export interface ICodeGenOptions {
    /** Target language for code generation */
    language?: 'python' | 'r' | 'javascript';
    /** Maximum retry attempts (default: 5) */
    maxRetries?: number;
    /**
     * Model identifier passed to the Vercel AI SDK.
     * Supports any model ID accepted by the active provider, e.g. `'openai/gpt-4o'`.
     * When omitted, the active provider's configured model is used.
     */
    model?: string;
    /**
     * Full execute_request metadata from the kernel (contains lastExecuteIO, cellId, etc.).
     * Originates from execute_request_impl of xeus-x.
     */
    metadata?: JSONObject;
    /**
     * Fine-grained package constraints for the generated code.
     * The AI is instructed accordingly and generated code is validated against
     * `required` and `prohibited` lists inside the retry loop.
     */
    packageConstraints?: IPackageConstraints;
}
/**
 * Result from code generation
 */
export interface ICodeGenResult extends ICodeGoResult {
    /** Generated code (if available) */
    generatedCode?: string;
}
/**
 * Get namespace variables for a language
 */
export declare function getNamespace(language: 'python' | 'javascript' | 'r'): JSONValue;
/**
 * Generate code for a given requirement
 */
export declare function genCode(requirement: string, options?: ICodeGenOptions): Promise<ICodeGoResult>;
/** Generate Python code without execution */
export declare function pygen(requirement: string, options?: Omit<ICodeGenOptions, 'language'>): Promise<ICodeGoResult>;
/** Generate JavaScript code without execution */
export declare function jsgen(requirement: string, options?: Omit<ICodeGenOptions, 'language'>): Promise<ICodeGoResult>;
/** Generate R code without execution */
export declare function rgen(requirement: string, options?: Omit<ICodeGenOptions, 'language'>): Promise<ICodeGoResult>;
/** Generate and execute Python code */
export declare function pygo(requirement: string, options?: Omit<ICodeGenOptions, 'language'>): Promise<ICodeGoResult>;
/** Generate and execute JavaScript code */
export declare function jsgo(requirement: string, options?: Omit<ICodeGenOptions, 'language'>): Promise<ICodeGoResult>;
/** Generate and execute R code */
export declare function rgo(requirement: string, options?: Omit<ICodeGenOptions, 'language'>): Promise<ICodeGoResult>;
/** Generate and execute code in the detected language */
export declare function go(requirement: string, options?: Omit<ICodeGenOptions, 'language'>): Promise<ICodeGoResult>;
/** Auto-detect language and generate code without execution */
export declare function gen(requirement: string, options?: Omit<ICodeGenOptions, 'language'>): Promise<ICodeGoResult>;
/** Mixed-language code generation without execution (@wildgen) */
export declare function wildgen(requirement: string, options?: Omit<ICodeGenOptions, 'language'>): Promise<ICodeGoResult>;
/** Generate and execute mixed-language code */
export declare function wildgo(requirement: string, options?: Omit<ICodeGenOptions, 'language'>): Promise<ICodeGoResult>;
/** Get namespace variables for a language (alias for getNamespace) */
export declare function getVars(language: 'python' | 'javascript' | 'r'): JSONValue;
export declare function publicGetExecutor(): CodeCommandExecutor;
/**
 * Unified AI interaction: the model decides whether to respond with
 * prose, code, or both. Returns the decision and generated code blocks
 * WITHOUT executing them — execution is handled by xeus-x's execution layer.
 */
export declare function smartAsk(question: string, options?: import('./ai_agents.js').ISmartAskOptions): Promise<import('./ai_agents.js').ISmartAskResult>;
/**
 * DataX API - convenient object that groups all API functions.
 * Generation-only — execution is handled by xeus-x's execution layer.
 */
export declare const dataxApi: {
    pygo: typeof pygo;
    jsgo: typeof jsgo;
    rgo: typeof rgo;
    pygen: typeof pygen;
    jsgen: typeof jsgen;
    rgen: typeof rgen;
    gen: typeof gen;
    wildgen: typeof wildgen;
    genCode: typeof genCode;
    ask: typeof ask;
    smartAsk: typeof smartAsk;
    getNamespace: typeof getNamespace;
    getVars: typeof getVars;
    getExecutor: typeof publicGetExecutor;
};
//# sourceMappingURL=datax-api.d.ts.map