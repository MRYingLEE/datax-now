/**
 * Agent Skills Integration
 *
 * Reads available skills from `window.jupyter_ai.skills` (provided by
 * the @jupyterlite/ai global API) and injects them into the system
 * prompt so the LLM is aware of any domain-specific instructions.
 *
 * For the current codebase, most calls are one-shot prompt-style
 * invocations rather than persisted UI chat state. Keep the public
 * helper centered on AI SDK v6's top-level instructions/prompt model
 * and only construct `ModelMessage[]` directly when a caller explicitly
 * needs them.
 */
import { resolveWindow } from './utilities.js';
// ──────────────────────────────────────────── helpers ────
/**
 * Read the current skills snapshot from `window.jupyter_ai.skills`.
 *
 * Returns an empty array when the global API is not yet initialised or
 * when no skills are registered.
 */
function getJupyterAISkills() {
    try {
        const w = resolveWindow();
        const skills = w?.jupyter_ai?.skills;
        if (Array.isArray(skills)) {
            return skills;
        }
    }
    catch {
        // ignore — not available in current environment
    }
    return [];
}
function buildAugmentedSystemPrompt(systemContent) {
    const skills = getJupyterAISkills();
    if (skills.length === 0) {
        return systemContent;
    }
    const skillList = skills
        .map((skill) => `- **${skill.name}**: ${skill.description}`)
        .join('\n');
    return `${systemContent}\n\n## Available Agent Skills\n\n${skillList}`;
}
export function buildMessagesWithSkills(systemContent, userContent) {
    return [
        {
            role: 'system',
            content: buildAugmentedSystemPrompt(systemContent),
        },
        {
            role: 'user',
            content: [{ type: 'text', text: String(userContent ?? '') }],
        },
    ];
}
export function buildSkillAwarePrompt(systemContent, userContent) {
    return {
        instructions: buildAugmentedSystemPrompt(systemContent),
        prompt: String(userContent ?? ''),
    };
}
//# sourceMappingURL=agent-skills.js.map