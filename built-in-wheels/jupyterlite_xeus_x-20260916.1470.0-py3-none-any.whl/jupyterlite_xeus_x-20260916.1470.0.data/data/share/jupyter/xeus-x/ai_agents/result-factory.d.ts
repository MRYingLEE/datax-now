import type { ICodeGoResult } from './code-commands-types.js';
export type ExecutionCountGetter = (() => number) | undefined;
export declare function getExecutionCount(getter?: ExecutionCountGetter, fallback?: number): number;
export declare function makeErrorResult(getter: ExecutionCountGetter, ename: string, evalue: string, traceback?: string[], extra?: Partial<ICodeGoResult>): ICodeGoResult;
export declare function makeOkResult(getter: ExecutionCountGetter, executionCount?: number, extra?: Partial<ICodeGoResult>): ICodeGoResult;
//# sourceMappingURL=result-factory.d.ts.map