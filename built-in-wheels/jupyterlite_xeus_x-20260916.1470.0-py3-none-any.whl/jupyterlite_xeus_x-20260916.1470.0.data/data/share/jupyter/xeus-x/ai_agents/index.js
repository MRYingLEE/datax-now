/**
 * @jupyterlite/ai_agents - AI Agents for Jupyter Kernels
 *
 * Public API exports.
 * This module provides code generation, single-language go execution helpers,
 * and LLM utilities. Mixed-language execution and output publishing remain in
 * xeus-x's execution layer (datax-exec.js).
 */
// ============================================================================
// DataX API - Clean, Promise-based API
// ============================================================================
export { getNamespace, ask, pygo, jsgo, rgo, pygen, go, wildgo, jsgen, rgen, gen, wildgen, smartAsk, genCode, getVars, dataxApi, publicGetExecutor as getExecutor, } from './datax-api.js';
// ============================================================================
// Core Code Generation
// ============================================================================
// Main code generator
export { Purpose, ScriptType } from './ai_agents.js';
export { generateSessionId, askAI, genCode as genCodeDirect, fixCode, implementCode, getAIAgentsConfigSummary, getLanguageConfig, getKernelConfig, extractCodeBlocks, extractProse, } from './ai_agents.js';
// ============================================================================
// Code Command Generation / single-language execution
// ============================================================================
export { CodeCommandExecutor, } from './code-commands.js';
// Output processing
export { compressOutput, wrapCode, wrapJSON, wrapSection, extractCode, customTrim, convertToString, } from './output-processor.js';
// Utilities
export { CONSTANTS, LanguageType_Lowercase, isStringList, resolveWindow, deFencedCode, extractFencedBlocks, normalizeFenceLanguage, } from './utilities.js';
// LLM factory (jupyter_ai provider)
export { getActiveProviderConfig, getLLM, } from './llm-factory.js';
export { callService, serviceRegistry, } from './service-registry.js';
// ============================================================================
// Typed Agent (structured output wrapper)
// ============================================================================
export { TypedAgent, createTypedAgent, typedText, typedObject, } from './typed-agent.js';
// LLM registry (multi-provider model resolution)
export { LLMRegistry, getDefaultRegistry, registerProvider, model, modelStrict, registerFromJupyterAI, createNativeFactory, openaiCompatibleFactory, } from './llm-registry.js';
// Template engine (runtime Handlebars prompt rendering)
export { render, renderKernel, setTemplateBaseURL, ensureTemplatesLoaded, } from './prompts/template-engine.js';
// ============================================================================
// Agent Code Generators (ported from C++ agent_executor.cpp)
// ============================================================================
export { generateAgentCodeForLanguage, generateJsPromiseAllBlock, generateGoCodeForLanguage, } from './agent-code-generators.js';
// ============================================================================
// Display Utilities
// ============================================================================
export { toPlainObject, } from './display/display.js';
export { widget, widgetStateByID, Model, _internals, } from './display/anywidget.js';
// ============================================================================
// Output Normalization (publishing moved to xeus-x datax-exec.js)
// ============================================================================
export { normalizeRunOutput, normalizeTraceback, } from './output-publisher.js';
//# sourceMappingURL=index.js.map