/**
 * WASM Bundle for xeus-x JavaScript Sub-Kernel
 *
 * This file creates a self-contained bundle of the ai_agents library
 * that can be injected into the WASM module's post.js file.
 *
 * It exposes the ai_agents functionality on the global Module object
 * so it's accessible from the JavaScript sub-kernel in xeus-x.
 */
import { Purpose, ScriptType, genCode as internalGenCode, fixCode, implementCode } from './ai_agents.js';
import { genCode } from './datax-api.js';
import { compressOutput, wrapCode, wrapJSON, wrapSection, extractCode, customTrim, convertToString } from './output-processor.js';
import * as utilities from './utilities.js';
import { CodeCommandExecutor } from './code-commands.js';
import { applyWidgetStateUpdate, pendingWidgetStateByID, widgetStateByID } from './display/anywidget.js';
import { callService, serviceRegistry } from './service-registry.js';
import { TypedAgent, createTypedAgent, typedObject, typedText } from './typed-agent.js';
declare global {
    interface IModule {
        jupyterAIAgents?: {
            compressOutput: typeof compressOutput;
            wrapCode: typeof wrapCode;
            wrapJSON: typeof wrapJSON;
            wrapSection: typeof wrapSection;
            extractCode: typeof extractCode;
            customTrim: typeof customTrim;
            convertToString: typeof convertToString;
            Purpose: typeof Purpose;
            ScriptType: typeof ScriptType;
            utilities: typeof utilities;
            CodeCommandExecutor: typeof CodeCommandExecutor;
            genCode: typeof genCode;
            fixCode: typeof fixCode;
            implementCode: typeof implementCode;
            callService: typeof callService;
            serviceRegistry: typeof serviceRegistry;
            TypedAgent: typeof TypedAgent;
            createTypedAgent: typeof createTypedAgent;
            typedText: typeof typedText;
            typedObject: typeof typedObject;
            dataxApi: any;
            widgetStateByID: typeof widgetStateByID;
            pendingWidgetStateByID: typeof pendingWidgetStateByID;
            applyWidgetStateUpdate: typeof applyWidgetStateUpdate;
            version: string;
        };
        fixCode?: typeof fixCode;
        implementCode?: typeof implementCode;
        callService?: typeof callService;
    }
}
/**
 * Create a lazily-initialized dataxApi that wraps CodeCommandExecutor
 * The executor is created on first use with globalThis.datax
 */
declare function createDataxApi(): any;
/**
 * Initialize the ai_agents module on the WASM Module object
 * This makes it accessible from C++ via EM_ASM or from JavaScript sub-kernel
 */
export declare function initializeAIAgents(moduleObj: any): void;
export { compressOutput, wrapCode, wrapJSON, wrapSection, extractCode, customTrim, convertToString, Purpose, ScriptType, utilities, CodeCommandExecutor, internalGenCode as genCode, fixCode, implementCode, callService, serviceRegistry, createDataxApi, };
declare const _default: {
    compressOutput: typeof compressOutput;
    wrapCode: typeof wrapCode;
    wrapJSON: typeof wrapJSON;
    wrapSection: typeof wrapSection;
    extractCode: typeof extractCode;
    customTrim: typeof customTrim;
    convertToString: typeof convertToString;
    Purpose: typeof Purpose;
    ScriptType: typeof ScriptType;
    utilities: typeof utilities;
    CodeCommandExecutor: typeof CodeCommandExecutor;
    genCode: typeof internalGenCode;
    fixCode: typeof fixCode;
    implementCode: typeof implementCode;
    callService: typeof callService;
    serviceRegistry: {
        call: typeof callService;
    };
    TypedAgent: typeof TypedAgent;
    createTypedAgent: typeof createTypedAgent;
    typedText: typeof typedText;
    typedObject: typeof typedObject;
    createDataxApi: typeof createDataxApi;
    dataxApi: any;
    initializeAIAgents: typeof initializeAIAgents;
    version: string;
};
export default _default;
//# sourceMappingURL=wasm-bundle.d.ts.map