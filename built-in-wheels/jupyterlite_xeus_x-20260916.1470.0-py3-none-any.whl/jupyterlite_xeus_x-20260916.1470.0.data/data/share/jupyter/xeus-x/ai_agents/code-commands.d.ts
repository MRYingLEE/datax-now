/**
 * Code Command Execution API
 * Provides @pygo, @jsgo, @rgo, @go command functionality
 *
 * These commands generate code using AI and automatically execute it with retry logic.
 *
 * Heavy generation and execution logic lives in:
 *   - code-gen-engine.ts  (generation with retry, caching, display)
 *   - code-exec-engine.ts (proxy execution, fenced-block runners)
 */
import type { JSONObject } from '@lumino/coreutils';
import type { IPackageConstraints } from './datax-api.js';
import type { AIAgentsRequestType } from './cache-utils.js';
export type { RunStatus, DisplayChoice, IRunResult, IRunOptions, ILanguageProxy, IDataxNamespace, ICodeCommandConfig, ICodeGoResult, } from './code-commands-types.js';
import type { ILanguageProxy, ICodeCommandConfig, ICodeGoResult, ICodeCommandContext } from './code-commands-types.js';
/**
 * Code Command Executor
 * Manages AI code generation and execution for multiple languages
 */
export declare class CodeCommandExecutor implements ICodeCommandContext {
    config: ICodeCommandConfig;
    private readonly languageConfig;
    constructor(config: ICodeCommandConfig);
    createSessionId(prefix: string): string;
    resolveSourceTag(command: string): AIAgentsRequestType;
    resolveMetadata(metadata?: JSONObject): JSONObject;
    /**
     * Update configuration
     */
    updateConfig(config: Partial<ICodeCommandConfig>): void;
    getExecutionCount(): number;
    resolveLanguageProxy(languageKey: 'python' | 'javascript' | 'r'): ILanguageProxy | null;
    /**
     * Generate code for a single language.
     * Shared by pygen, jsgen, and rgen to avoid duplicating the delegation call.
     */
    private langGen;
    /** Python code generation only (@pygen) */
    pygen(requirement: string, metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string): Promise<ICodeGoResult>;
    /** JavaScript code generation only (@jsgen) */
    jsgen(requirement: string, metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string): Promise<ICodeGoResult>;
    /** R code generation only (@rgen) */
    rgen(requirement: string, metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string): Promise<ICodeGoResult>;
    /**
     * Generate and execute code for a single language with runtime-error retry.
     * Shared by pygo, jsgo, and rgo.
     */
    private langGo;
    /** Generate and execute Python code (@pygo) */
    pygo(requirement: string, metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string): Promise<ICodeGoResult>;
    /** Generate and execute JavaScript code (@jsgo) */
    jsgo(requirement: string, metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string): Promise<ICodeGoResult>;
    /** Generate and execute R code (@rgo) */
    rgo(requirement: string, metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string): Promise<ICodeGoResult>;
    /**
     * Auto-detect language and generate code in single language (@gen)
     * Auto-detects the target language and generates code without executing it
     */
    gen(requirement: string, metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string): Promise<ICodeGoResult>;
    /** Auto-detect language, generate, and execute code (@go). */
    go(requirement: string, metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string): Promise<ICodeGoResult>;
    /**
     * Mixed-language code generation only (@wildgen)
     * Generates fenced markdown with multiple languages without executing it
     */
    wildgen(requirement: string, metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string): Promise<ICodeGoResult>;
    /** Generate and execute mixed-language fenced code (@wildgo). */
    wildgo(requirement: string, metadata?: JSONObject, packageConstraints?: IPackageConstraints, model?: string): Promise<ICodeGoResult>;
    /**
     * Ask AI a question with optional metadata context
     * @param question The question to ask
     * @param options Options including metadata, streaming, and displayId
     * @returns AI's response as a string
     *
     * @example
     * ```typescript
     * const answer = await executor.ask("What is a prime number?");
     * const contextAnswer = await executor.ask("How did you generate that?", {
     *   metadata: { lastExecuteIO: previousExecution }
     * });
     * ```
     */
    ask(question: string, metadata?: JSONObject): Promise<string>;
}
//# sourceMappingURL=code-commands.d.ts.map