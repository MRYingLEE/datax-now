/**
 * Handlebars Template Engine for AI Prompts
 *
 * Runtime-fetch design: templates are loaded via fetch() from a configurable
 * base URL so that end users can edit .hbs files without rebuilding.
 *
 * Initialisation is lazy — the first call to render() triggers fetch of
 * manifest.json and all referenced template / partial files, then caches
 * the compiled Handlebars functions in memory.
 */
import Handlebars from 'handlebars';
// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
let _initialized = false;
let _initializing = null;
let _baseURL = './prompts/templates/';
const _templateCache = new Map();
// ---------------------------------------------------------------------------
// Custom helpers
// ---------------------------------------------------------------------------
// Disable HTML escaping — prompts are plain text, not HTML.
Handlebars.Utils.escapeExpression = (str) => str;
function stripCodeFence(value) {
    const trimmed = value.trim();
    const match = trimmed.match(/^```[^\n]*\n([\s\S]*?)\n```$/);
    return match ? match[1].trim() : trimmed;
}
function hasMeaningfulContent(value) {
    if (value == null)
        return false;
    if (typeof value === 'string') {
        const stripped = stripCodeFence(value);
        if (stripped.length === 0)
            return false;
        if (/^[\[{]/.test(stripped)) {
            try {
                return hasMeaningfulContent(JSON.parse(stripped));
            }
            catch {
                return true;
            }
        }
        return true;
    }
    if (Array.isArray(value)) {
        return value.some((item) => hasMeaningfulContent(item));
    }
    if (typeof value === 'object') {
        return Object.values(value).some((item) => hasMeaningfulContent(item));
    }
    return true;
}
/**
 * {{#if (notBlank val)}} … {{/if}}
 * Treats null, undefined, empty string, and whitespace-only as "blank".
 */
Handlebars.registerHelper('notBlank', function (value) {
    if (value == null)
        return false;
    if (typeof value === 'string')
        return value.trim().length > 0;
    return true;
});
Handlebars.registerHelper('hasRealContent', function (value) {
    return hasMeaningfulContent(value);
});
// ---------------------------------------------------------------------------
// Initialisation
// ---------------------------------------------------------------------------
/**
 * Set the base URL for template fetching.
 * Must be called BEFORE the first render() if a non-default location is used.
 */
export function setTemplateBaseURL(url) {
    if (!url.endsWith('/'))
        url += '/';
    _baseURL = url;
    // Allow re-init with new base URL
    _initialized = false;
    _initializing = null;
    _templateCache.clear();
}
function resolveCandidateBaseURLs() {
    const explicit = _baseURL.trim();
    // If host injected an absolute URL via setTemplateBaseURL(), use only that.
    if (/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(explicit)) {
        return [explicit];
    }
    // Module-relative fallbacks for non-browser / development environments.
    const moduleDir = import.meta.url.replace(/[^/]*$/, '');
    const distBaseURL = moduleDir.includes('/lib-esm/prompts/')
        ? moduleDir.replace('/lib-esm/prompts/', '/dist/prompts/templates/')
        : '';
    // Browser fallback: hosts should call setTemplateBaseURL() for reliable
    // resolution.  These are kept only for backward compatibility.
    const browserBaseCandidates = typeof globalThis.location?.href === 'string'
        ? [
            new URL('/vendor/ai_agents/prompts/templates/', globalThis.location.href).toString(),
            new URL('/packages/ai_agents/prompts/templates/', globalThis.location.href).toString(),
        ]
        : [];
    const usesDefaultRelativeBase = explicit === './prompts/templates/';
    const candidates = [
        ...(usesDefaultRelativeBase ? browserBaseCandidates : [explicit]),
        ...(usesDefaultRelativeBase ? [explicit] : browserBaseCandidates),
        `${moduleDir}prompts/templates/`,
        distBaseURL,
    ];
    return [...new Set(candidates.filter((candidate) => candidate.trim().length > 0))];
}
async function _fetchText(url) {
    const res = await fetch(url);
    if (!res.ok) {
        throw new Error(`Failed to fetch template: ${url} (${res.status})`);
    }
    return res.text();
}
async function _init() {
    const errors = [];
    for (const candidateBaseURL of resolveCandidateBaseURLs()) {
        try {
            const manifestURL = `${candidateBaseURL}manifest.json`;
            const manifest = await _fetchText(manifestURL).then((t) => JSON.parse(t));
            _templateCache.clear();
            // 1. Register partials (must come first — templates may reference them).
            const partialNames = Object.keys(manifest.partials);
            await Promise.all(partialNames.map(async (name) => {
                const source = await _fetchText(`${candidateBaseURL}${manifest.partials[name]}`);
                Handlebars.registerPartial(name, source);
            }));
            // 2. Compile & cache templates.
            const templateNames = Object.keys(manifest.templates);
            await Promise.all(templateNames.map(async (name) => {
                const source = await _fetchText(`${candidateBaseURL}${manifest.templates[name]}`);
                _templateCache.set(name, Handlebars.compile(source));
            }));
            _baseURL = candidateBaseURL;
            _initialized = true;
            return;
        }
        catch (error) {
            errors.push(`${candidateBaseURL}: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    throw new Error(`Failed to initialize prompt templates. Tried: ${errors.join(' | ')}`);
}
/**
 * Ensure templates are loaded. Safe to call multiple times — only the first
 * invocation fetches; concurrent callers share the same promise.
 */
export async function ensureTemplatesLoaded() {
    if (_initialized)
        return;
    if (!_initializing) {
        _initializing = _init().catch((error) => {
            _initializing = null;
            _initialized = false;
            _templateCache.clear();
            throw error;
        });
    }
    await _initializing;
}
// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
/**
 * Render a template by name with the given data.
 *
 * ```ts
 * const text = await render('system/smartAsk', { defaultConvention, languageHint });
 * ```
 */
export async function render(name, data = {}) {
    await ensureTemplatesLoaded();
    const fn = _templateCache.get(name);
    if (!fn) {
        throw new Error(`[TemplateEngine] Template "${name}" not found. Available: [${[..._templateCache.keys()].join(', ')}]`);
    }
    return fn(data);
}
/**
 * Render a kernel context template and return the plain text.
 * Convenience wrapper used by getKernelConfig().
 */
export async function renderKernel(name) {
    return render(name, {});
}
//# sourceMappingURL=template-engine.js.map