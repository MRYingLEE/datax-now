import { genCode as internalGenCode, Purpose, ScriptType } from './ai_agents.js';
import { setRuntimeGenCache } from './cache-utils.js';
import { createLogger } from './logger.js';
import { normalizeRunOutput } from './output-publisher.js';
import { wrapCodeForDisplay } from './output-processor.js';
import { makeErrorResult, makeOkResult } from './result-factory.js';
import { collectModulesFromContext, } from './utilities.js';
const { info: _info } = createLogger('[AI_Agents]');
function quietRunOptions(language, sessionId, streamRedirectDisplayId = '') {
    const options = {
        language,
        variable_sync: 'off',
        session_id: sessionId,
        streaming: { enabled: true, display: { initial: 'invisible', end: 'invisible' } },
    };
    if (streamRedirectDisplayId) {
        options.stream_redirect_display_id = streamRedirectDisplayId;
    }
    return options;
}
function getGlobal() {
    return globalThis;
}
function getInterpreter() {
    const g = getGlobal();
    const moduleRef = g?._dataxnow_?._xeus_module ?? g?.Module;
    const direct = moduleRef?.js_interpreter ?? moduleRef?.xkernel ?? moduleRef?.interpreter;
    if (direct) {
        return direct;
    }
    if (typeof moduleRef?._get_interpreter === 'function') {
        try {
            return moduleRef._get_interpreter();
        }
        catch (error) {
            _info(`go-execution: Module._get_interpreter() failed: ${String(error?.message || error)}`);
        }
    }
    if (typeof g?._get_interpreter === 'function') {
        try {
            return g._get_interpreter();
        }
        catch (error) {
            _info(`go-execution: globalThis._get_interpreter() failed: ${String(error?.message || error)}`);
        }
    }
    return null;
}
function publishStreamFallbackDisplay(name, text) {
    const g = getGlobal();
    const dxDisplay = g?.datax?.display ?? null;
    const displayData = dxDisplay?.display_data ?? g?.display_data;
    if (typeof displayData !== 'function') {
        return false;
    }
    const normalizedText = name === 'stderr' ? `[stderr]\n${text}` : text;
    displayData({ 'text/plain': normalizedText }, {
        source: 'ai_agents_stream_fallback',
        stream_name: name,
    }, {});
    return true;
}
function publishRunOutput(output, executionCount) {
    const g = getGlobal();
    const dxDisplay = g?.datax?.display ?? null;
    const interpreter = getInterpreter();
    const moduleRef = g?._dataxnow_?._xeus_module ?? g?.Module;
    switch (output.output_type) {
        case 'stream': {
            const text = Array.isArray(output.text) ? output.text.join('') : output.text;
            const streamName = output.name || 'stdout';
            if (text && typeof interpreter?.publish_stream === 'function') {
                interpreter.publish_stream(streamName, text);
            }
            else if (text && publishStreamFallbackDisplay(streamName, text)) {
                _info(`go-execution: publish_stream unavailable; rendered ${streamName} via display_data fallback`);
            }
            else if (text) {
                _info(`go-execution: dropped ${streamName} because no publish_stream/display_data route was available`);
            }
            break;
        }
        case 'display_data': {
            const displayData = dxDisplay?.display_data ?? g?.display_data ?? interpreter?.display_data;
            if (typeof displayData === 'function') {
                displayData(output.data || {}, output.metadata || {}, output.transient || {});
            }
            break;
        }
        case 'update_display_data': {
            const updateDisplayData = dxDisplay?.update_display_data ?? g?.update_display_data ?? interpreter?.update_display_data;
            if (typeof updateDisplayData === 'function') {
                updateDisplayData(output.data || {}, output.metadata || {}, output.transient || {});
            }
            break;
        }
        case 'execute_result': {
            if (typeof moduleRef?._js_publish_execution_result === 'function') {
                moduleRef._js_publish_execution_result(executionCount ?? output.execution_count ?? 0, JSON.stringify(output.data || {}), JSON.stringify(output.metadata || {}));
            }
            else if (typeof interpreter?.publish_execution_result === 'function') {
                interpreter.publish_execution_result(executionCount ?? output.execution_count ?? 0, output.data || {}, output.metadata || {});
            }
            else {
                const displayData = dxDisplay?.display_data ?? g?.display_data;
                if (typeof displayData === 'function') {
                    displayData(output.data || {}, output.metadata || {}, {});
                }
            }
            break;
        }
        case 'error': {
            const traceback = Array.isArray(output.traceback)
                ? output.traceback
                : output.traceback == null
                    ? []
                    : [String(output.traceback)];
            if (typeof moduleRef?._js_publish_execution_error === 'function') {
                moduleRef._js_publish_execution_error(String(output.ename || 'ExecutionError'), String(output.evalue || ''), JSON.stringify(traceback));
            }
            else if (typeof interpreter?.publish_execution_error === 'function') {
                interpreter.publish_execution_error(output.ename || 'ExecutionError', output.evalue || '', traceback.join('\n'));
            }
            break;
        }
    }
}
function publishRunOutputs(outputs, executionCount) {
    for (const output of outputs) {
        publishRunOutput(output, executionCount);
    }
}
function remapRedirectedDisplayOutputs(outputs, execDisplayId) {
    if (!Array.isArray(outputs) || typeof execDisplayId !== 'string' || execDisplayId.length === 0) {
        return Array.isArray(outputs) ? outputs : [];
    }
    let primaryDisplayId = '';
    for (const candidate of outputs) {
        if (!candidate || typeof candidate !== 'object')
            continue;
        if (candidate.output_type !== 'display_data' && candidate.output_type !== 'update_display_data')
            continue;
        const candidateDisplayId = typeof candidate.transient?.display_id === 'string'
            ? candidate.transient.display_id
            : '';
        if (candidateDisplayId) {
            primaryDisplayId = candidateDisplayId;
            break;
        }
    }
    const seenDisplayIds = Object.create(null);
    let primaryChainStarted = false;
    const remapped = [];
    for (const output of outputs) {
        if (!output || typeof output !== 'object') {
            remapped.push(output);
            continue;
        }
        if (output.output_type !== 'display_data'
            && output.output_type !== 'update_display_data'
            && output.output_type !== 'execute_result') {
            remapped.push(output);
            continue;
        }
        const transient = output.output_type === 'execute_result'
            ? {}
            : (output.transient && typeof output.transient === 'object' ? output.transient : {});
        const displayId = typeof transient.display_id === 'string'
            ? transient.display_id
            : '';
        if (displayId && displayId === primaryDisplayId) {
            primaryChainStarted = true;
            seenDisplayIds[displayId] = true;
            remapped.push({
                ...output,
                output_type: 'update_display_data',
                transient: { ...transient, display_id: execDisplayId },
            });
            continue;
        }
        if (!displayId) {
            if (!primaryDisplayId || !primaryChainStarted) {
                remapped.push({
                    ...output,
                    output_type: 'update_display_data',
                    transient: { ...transient, display_id: execDisplayId },
                });
                continue;
            }
            remapped.push(output);
            continue;
        }
        const firstSeenDisplayId = !seenDisplayIds[displayId];
        seenDisplayIds[displayId] = true;
        if (output.output_type === 'update_display_data' && firstSeenDisplayId) {
            remapped.push({
                ...output,
                output_type: 'display_data',
                transient: { ...transient },
            });
            continue;
        }
        remapped.push(output);
    }
    return remapped;
}
function seedExecDisplaySlot(execDisplayId) {
    const g = getGlobal();
    const displayData = g?.datax?.display?.display_data ?? g?.display_data;
    if (typeof displayData !== 'function' || !execDisplayId) {
        return;
    }
    displayData({ 'text/plain': '⏳ Running...' }, {}, { display_id: execDisplayId });
}
function hideExecDisplaySlot(execDisplayId) {
    const g = getGlobal();
    const updateDisplayData = g?.datax?.display?.update_display_data ?? g?.update_display_data;
    if (typeof updateDisplayData !== 'function' || !execDisplayId) {
        return;
    }
    updateDisplayData({ 'text/html': '<div style="display:none;"></div>' }, {}, { display_id: execDisplayId });
}
function hasRuntimeRedirectedDisplayOutputs(outputs, execDisplayId) {
    if (!execDisplayId) {
        return false;
    }
    return outputs.some((output) => ((output.output_type === 'display_data' || output.output_type === 'update_display_data')
        && typeof output.transient?.display_id === 'string'
        && output.transient.display_id === execDisplayId));
}
function filterRepublishedOutputs(outputs, runtimeOutputs, execDisplayId) {
    if (!hasRuntimeRedirectedDisplayOutputs(runtimeOutputs, execDisplayId)) {
        return outputs;
    }
    return outputs.filter((output) => output.output_type !== 'stream');
}
function isGeneratedWidgetDisplay(generated) {
    return generated.includes('display_widget(')
        || generated.includes('datax.widget(')
        || generated.includes('datax.widgets.anywidget(');
}
function shouldSuppressGeneratedCodeFallback(metadata, detectedLanguage) {
    if (metadata?.systemPromptAlias === true) {
        return true;
    }
    return detectedLanguage === 'javascript';
}
function publishGeneratedCodeFallback(generated) {
    if (typeof generated !== 'string' || generated.trim().length === 0) {
        return false;
    }
    if (isGeneratedWidgetDisplay(generated)) {
        return false;
    }
    publishRunOutput({
        output_type: 'display_data',
        data: { 'text/plain': generated },
        metadata: {},
        transient: { display_id: '__xeus_ai_cmd_display' },
    });
    return true;
}
function toDisplayDataPayload(value) {
    if (value == null)
        return { 'text/plain': '' };
    if (typeof value === 'string')
        return { 'text/plain': value };
    if (typeof value === 'number' || typeof value === 'boolean') {
        return { 'text/plain': String(value) };
    }
    if (typeof value === 'object') {
        try {
            return {
                'application/json': value,
                'text/plain': JSON.stringify(value, null, 2),
            };
        }
        catch {
            return { 'text/plain': String(value) };
        }
    }
    return { 'text/plain': String(value) };
}
function synthesizeRunOutputs(runResult) {
    const normalized = Array.isArray(runResult.outputs)
        ? runResult.outputs
            .map((item) => normalizeRunOutput(item))
            .filter((item) => item !== null)
        : [];
    if (normalized.length > 0) {
        return normalized;
    }
    const synthesized = [];
    if (Array.isArray(runResult.display_outputs)) {
        for (const display of runResult.display_outputs) {
            if (display && typeof display === 'object' && display.data && typeof display.data === 'object') {
                synthesized.push({
                    output_type: 'display_data',
                    data: display.data,
                    metadata: display.metadata || {},
                    transient: display.transient || {},
                });
            }
        }
    }
    if (typeof runResult.stdout === 'string' && runResult.stdout.length > 0) {
        synthesized.push({
            output_type: 'stream',
            name: 'stdout',
            text: runResult.stdout,
        });
    }
    if (typeof runResult.stderr === 'string' && runResult.stderr.length > 0) {
        synthesized.push({
            output_type: 'stream',
            name: 'stderr',
            text: runResult.stderr,
        });
    }
    if (synthesized.length === 0 && runResult.result !== undefined && runResult.result !== null) {
        synthesized.push({
            output_type: 'execute_result',
            execution_count: runResult.execution_count ?? null,
            data: toDisplayDataPayload(runResult.result),
            metadata: {},
        });
    }
    if (synthesized.length === 0 && runResult.error_name) {
        synthesized.push({
            output_type: 'error',
            ename: runResult.error_name || 'ExecutionError',
            evalue: runResult.error_value || '',
            traceback: Array.isArray(runResult.traceback) ? runResult.traceback : [],
        });
    }
    return synthesized;
}
function hasExplicitRunError(runResult, outputs) {
    if (runResult.error_name || runResult.error_value) {
        return true;
    }
    if (outputs.some((output) => output.output_type === 'error')) {
        return true;
    }
    return extractTracebackFromOutputs(outputs).length > 0;
}
function extractStderrTexts(outputs) {
    return outputs
        .filter((output) => output.output_type === 'stream' &&
        output.name === 'stderr' &&
        typeof output.text === 'string' &&
        output.text.length > 0)
        .map((output) => output.text);
}
function looksLikeTracebackLine(line) {
    const trimmed = line.trim();
    if (!trimmed) {
        return false;
    }
    return /traceback \(most recent call last\):/i.test(trimmed) ||
        /^[A-Za-z_][A-Za-z0-9_.]*(Error|Exception):/.test(trimmed) ||
        /^Error:/.test(trimmed);
}
function extractTracebackFromOutputs(outputs) {
    const traceback = [];
    for (const stderrText of extractStderrTexts(outputs)) {
        const lines = String(stderrText)
            .split(/\r?\n/)
            .map((line) => line.trimEnd())
            .filter((line) => line.length > 0);
        if (lines.some(looksLikeTracebackLine)) {
            traceback.push(...lines);
        }
    }
    return traceback;
}
function summarizeRuntimeError(runResult, outputs) {
    const traceback = Array.isArray(runResult.traceback) && runResult.traceback.length > 0
        ? runResult.traceback
        : extractTracebackFromOutputs(outputs);
    const fallbackErrorLine = traceback.length > 0
        ? traceback[traceback.length - 1]
        : extractStderrTexts(outputs)
            .flatMap((text) => String(text).split(/\r?\n/))
            .map((line) => line.trim())
            .filter((line) => line.length > 0)
            .pop();
    return {
        ename: runResult.error_name || 'ExecutionError',
        evalue: runResult.error_value || fallbackErrorLine || 'Code execution failed',
        traceback,
    };
}
function extractMissingModuleName(message) {
    const patterns = [
        /No module named ['"]([^'"]+)['"]/i,
        /Cannot find module ['"]([^'"]+)['"]/i,
        /there is no package called ['"]([^'"]+)['"]/i,
    ];
    for (const pattern of patterns) {
        const match = pattern.exec(message);
        if (match?.[1]) {
            return match[1];
        }
    }
    return null;
}
function buildRepairRequirement(failure) {
    const runtimeError = summarizeRuntimeError(failure.runResult, failure.outputs);
    const messages = [
        runtimeError.evalue,
        ...runtimeError.traceback,
    ]
        .filter((value) => typeof value === 'string' && value.trim().length > 0);
    for (const message of messages) {
        const missingModule = extractMissingModuleName(message);
        if (missingModule) {
            return `${failure.requirement}\n\nRepair guidance: The previous code failed because module "${missingModule}" is unavailable in this runtime. Do not import or depend on "${missingModule}" in the fix. Use packages that are already available in the current environment or rewrite the solution without that dependency.`;
        }
    }
    return failure.requirement;
}
function hasMeaningfulRunOutputs(outputs) {
    for (const output of outputs) {
        if (output.output_type === 'error')
            continue;
        if (output.output_type === 'stream') {
            if (output.name === 'stdout' && typeof output.text === 'string' && output.text.length > 0)
                return true;
            continue;
        }
        if (output.output_type === 'display_data' ||
            output.output_type === 'update_display_data' ||
            output.output_type === 'execute_result') {
            if (output.data && typeof output.data === 'object')
                return true;
            continue;
        }
        return true;
    }
    return false;
}
function hasSuccessfulRunStatus(status) {
    if (typeof status !== 'string') {
        return false;
    }
    const normalized = status.trim().toLowerCase();
    return normalized === 'completed' || normalized === 'succeeded' || normalized === 'success' || normalized === 'ok';
}
function hasMissingRunStatus(status) {
    return typeof status !== 'string' || status.trim().length === 0;
}
function resolveMaxAttempts(metadata, fallback = 5) {
    const raw = metadata?.maxRetries ?? metadata?.max_retries;
    const parsed = Number(raw);
    if (!Number.isFinite(parsed) || parsed < 1) {
        return Math.max(1, Math.floor(fallback));
    }
    return Math.max(1, Math.floor(parsed));
}
function summaryForCommand(command) {
    switch (command) {
        case '@pygo':
            return 'Generated Python code';
        case '@jsgo':
            return 'Generated JavaScript code';
        case '@tsgo':
            return 'Generated TypeScript code';
        case '@rgo':
            return 'Generated R code';
        case '@go':
            return 'Generated code';
        case '@wildgo':
            return 'Generated mixed-language code';
        default:
            return 'Generated code';
    }
}
function buildGeneratedCodeDisplayOutput(command, requirement, generated, languageKey) {
    return {
        output_type: 'display_data',
        data: {
            'text/markdown': `<details ><summary>${summaryForCommand(command)}</summary><br>\n\n${wrapCodeForDisplay(generated, languageKey)}\n</details>`,
        },
        metadata: {
            source: String(command || '').replace(/^@/, ''),
            prompt: requirement,
        },
    };
}
function requestTypeForCommand(command) {
    const normalized = String(command ?? '').replace(/^@/, '').trim().toLowerCase();
    switch (normalized) {
        case 'pygo':
        case 'jsgo':
        case 'tsgo':
        case 'rgo':
        case 'go':
        case 'wildgo':
            return normalized;
        default:
            return null;
    }
}
function refreshRuntimeReplayCache(options, generated) {
    const cellId = typeof options.metadata?.cellId === 'string'
        ? options.metadata.cellId
        : undefined;
    const requestType = requestTypeForCommand(options.command);
    if (!cellId || !requestType || !generated) {
        return;
    }
    const displayRecord = buildGeneratedCodeDisplayOutput(options.command, options.requirement, generated, options.genResult.detectedLanguage || options.languageKey);
    setRuntimeGenCache({
        cellId,
        requestType,
        requirement: options.requirement,
        detectedLanguage: options.genResult.detectedLanguage || options.languageKey,
        generated,
        displayData: [displayRecord],
    });
}
function buildLastExecuteIOForRetry(failure) {
    const runtimeError = summarizeRuntimeError(failure.runResult, failure.outputs);
    return {
        status: 'error',
        prompt: failure.requirement,
        code: failure.currentCode,
        generated_code: failure.currentCode,
        code_language: failure.languageKey,
        output_model: [
            buildGeneratedCodeDisplayOutput(failure.command, failure.requirement, failure.currentCode, failure.languageKey),
            ...failure.outputs,
        ],
        execution_result: {
            status: 'error',
            ename: runtimeError.ename,
            evalue: runtimeError.evalue,
            traceback: runtimeError.traceback,
        },
    };
}
function retryScriptType(languageKey) {
    switch (languageKey) {
        case 'python':
            return ScriptType.PyOnly;
        case 'javascript':
            return ScriptType.JsOnly;
        case 'r':
            return ScriptType.ROnly;
    }
}
function retrySummaries(command) {
    switch (command) {
        case '@pygo':
            return { going: 'Fixing Python code...', done: 'Fixed Python code' };
        case '@jsgo':
            return { going: 'Fixing JavaScript code...', done: 'Fixed JavaScript code' };
        case '@tsgo':
            return { going: 'Fixing TypeScript code...', done: 'Fixed TypeScript code' };
        case '@rgo':
            return { going: 'Fixing R code...', done: 'Fixed R code' };
        default:
            return { going: 'Fixing generated code...', done: 'Fixed generated code' };
    }
}
function getProxyContext(languageKey, proxy) {
    const markdownContext = typeof proxy.context === 'string' && proxy.context.trim().length > 0
        ? proxy.context
        : null;
    if (markdownContext) {
        const modules = languageKey === 'python'
            ? collectModulesFromContext(languageKey, proxy.vars || {})
            : [];
        return { context: markdownContext, modules };
    }
    const rawVars = proxy.vars || {};
    const modules = collectModulesFromContext(languageKey, rawVars);
    return { context: rawVars, modules };
}
export function buildRuntimeRepairCallback(options) {
    return async (failure) => {
        const retryMetadata = {
            ...(failure.metadata || {}),
            lastExecuteIO: buildLastExecuteIOForRetry(failure),
        };
        const proxyContext = getProxyContext(options.languageKey, failure.proxy);
        const summary = retrySummaries(options.command);
        try {
            return await internalGenCode({
                currentPrompt: buildRepairRequirement(failure),
                realCode: false,
                currentContext: proxyContext.context,
                modules: proxyContext.modules,
                scriptType: retryScriptType(options.languageKey),
                sessionId: `fix_${crypto.randomUUID().replace(/-/g, '_')}`,
                summary_going: summary.going,
                summary_done: summary.done,
                finalClosed: true,
                purpose: Purpose.FixRuntimeIssue,
                metadata: retryMetadata,
                showStopButton: false,
            });
        }
        catch (error) {
            _info(`runtime repair failed for ${options.command}: ${String(error?.message || error)}`);
            throw error;
        }
    };
}
export async function executeGeneratedCodeWithRetry(options) {
    if (options.genResult.status !== 'ok' || !options.genResult.generated) {
        return options.genResult;
    }
    const maxAttempts = resolveMaxAttempts(options.metadata, options.maxAttempts ?? 5);
    const sessionPrefix = options.command.replace(/^@/, '');
    const execDisplayId = `exec_${sessionPrefix}_${crypto.randomUUID().replace(/-/g, '_')}`;
    let currentCode = options.genResult.generated;
    let lastError = null;
    seedExecDisplaySlot(execDisplayId);
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        let runResult;
        try {
            runResult = await options.proxy.run(currentCode, quietRunOptions(options.languageType, `${sessionPrefix}_${attempt}`, execDisplayId));
        }
        catch (error) {
            hideExecDisplaySlot(execDisplayId);
            return makeErrorResult(options.getExecutionCount, 'ExecutionError', `Execution failed: ${String(error?.message || error)}`, [String(error?.stack || error)]);
        }
        const runtimeOutputs = synthesizeRunOutputs(runResult);
        const normalizedOutputs = remapRedirectedDisplayOutputs(runtimeOutputs, execDisplayId);
        const runStatus = runResult.status;
        const executionSucceeded = !hasExplicitRunError(runResult, normalizedOutputs) &&
            (hasSuccessfulRunStatus(runStatus) ||
                (hasMissingRunStatus(runStatus) && hasMeaningfulRunOutputs(normalizedOutputs)));
        if (executionSucceeded) {
            if (currentCode !== options.genResult.generated) {
                refreshRuntimeReplayCache(options, currentCode);
            }
            const detectedLanguage = options.genResult.detectedLanguage || options.languageKey;
            const runtimeAlreadyPublished = runResult.outputs_published === true;
            const outputsToRepublish = filterRepublishedOutputs(normalizedOutputs, runtimeOutputs, execDisplayId);
            const republishOutputs = !runtimeAlreadyPublished && outputsToRepublish.length > 0;
            if (runtimeAlreadyPublished || republishOutputs) {
                hideExecDisplaySlot(execDisplayId);
            }
            if (republishOutputs) {
                publishRunOutputs(outputsToRepublish, runResult.execution_count);
            }
            const shouldPublishFallback = !runtimeAlreadyPublished &&
                !republishOutputs &&
                !shouldSuppressGeneratedCodeFallback(options.metadata, detectedLanguage);
            if (!runtimeAlreadyPublished && !republishOutputs) {
                hideExecDisplaySlot(execDisplayId);
            }
            const publishedFallback = shouldPublishFallback
                ? publishGeneratedCodeFallback(currentCode)
                : false;
            const outputsPublished = runtimeAlreadyPublished || republishOutputs || publishedFallback;
            return makeOkResult(options.getExecutionCount, runResult.execution_count, {
                user_expressions: {},
                outputs: normalizedOutputs,
                outputs_published: outputsPublished,
                generated: currentCode,
                detectedLanguage,
            });
        }
        const runtimeError = summarizeRuntimeError(runResult, normalizedOutputs);
        lastError = makeErrorResult(options.getExecutionCount, runtimeError.ename, runtimeError.evalue, runtimeError.traceback, {
            outputs: normalizedOutputs,
            generated: currentCode,
            detectedLanguage: options.genResult.detectedLanguage || options.languageKey,
        });
        if (attempt >= maxAttempts) {
            hideExecDisplaySlot(execDisplayId);
            return lastError;
        }
        const repairedCode = await options.repairCode({
            command: options.command,
            requirement: options.requirement,
            currentCode,
            languageKey: options.languageKey,
            languageType: options.languageType,
            proxy: options.proxy,
            metadata: options.metadata ?? {},
            runResult,
            outputs: normalizedOutputs,
        });
        const normalizedCurrentCode = currentCode.trim();
        const normalizedRepairedCode = typeof repairedCode === 'string'
            ? repairedCode.trim()
            : '';
        if (normalizedRepairedCode.length === 0) {
            _info(`runtime repair returned empty code for ${options.command}; continuing retry loop`);
            continue;
        }
        if (normalizedRepairedCode === normalizedCurrentCode) {
            _info(`runtime repair returned unchanged code for ${options.command}; continuing retry loop`);
            continue;
        }
        currentCode = repairedCode;
    }
    hideExecDisplaySlot(execDisplayId);
    return (lastError ||
        makeErrorResult(options.getExecutionCount, 'ExecutionError', 'Code execution failed', []));
}
//# sourceMappingURL=go-execution.js.map