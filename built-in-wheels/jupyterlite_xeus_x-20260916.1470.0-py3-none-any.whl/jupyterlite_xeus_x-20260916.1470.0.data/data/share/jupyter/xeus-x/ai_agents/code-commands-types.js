/**
 * Type definitions for the Code Command Execution API.
 *
 * Extracted from code-commands.ts for reuse across modules.
 */
export {};
//# sourceMappingURL=code-commands-types.js.map