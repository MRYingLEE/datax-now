/**
 * Agent Code Generators
 *
 * Port of string template functions from xeus-x agent_executor.cpp to TypeScript.
 * These generate language-specific code strings for agent command execution.
 *
 * By living in TypeScript, agent API changes no longer require WASM rebuilds.
 */
/**
 * Resolved agent command descriptor.
 * C++ fills these fields after kernel introspection, then passes them to TS.
 */
export interface IResolvedAgentCommand {
    command: string;
    code: string;
    is_expression: boolean;
    pre_text: string;
    post_text: string;
    language: string;
    system_prompt?: string;
    /** Resolved param count: -1=INVALID, 0=NO_PARAMS, 1=SINGLE_PARAM, 2+=MULTI */
    param_count: number;
    /** Whether the function is async (relevant for JS) */
    is_async: boolean;
}
export declare function generateAgentDisplayCodeForLanguage(cmd: IResolvedAgentCommand, lang: string): string;
/**
 * Generate code for a single agent command in a specific language.
 * Mirrors the C++ generate_agent_code_for_language() function.
 */
export declare function generateAgentCodeForLanguage(cmd: IResolvedAgentCommand, lang: string): string;
/**
 * Generate a JS Promise.allSettled block for multiple async agent commands.
 * Mirrors the C++ generate_js_promise_all_block() function.
 */
export declare function generateJsPromiseAllBlock(asyncCmds: IResolvedAgentCommand[]): string;
/**
 * Generate code for a go-style command (pygo/jsgo/rgo) in a specific language.
 * Mirrors the C++ generate_go_code_for_language() function.
 */
export declare function generateGoCodeForLanguage(cmd: IResolvedAgentCommand, codeLang: string, goLang: string): string;
//# sourceMappingURL=agent-code-generators.d.ts.map