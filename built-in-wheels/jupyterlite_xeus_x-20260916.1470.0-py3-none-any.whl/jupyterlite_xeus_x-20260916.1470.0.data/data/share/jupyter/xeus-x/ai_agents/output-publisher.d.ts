/**
 * Output Publisher — output normalization utilities.
 *
 * Publishing functions (publishOutputItem, publishRunOutputs, publishExecutionError)
 * have been moved to xeus-x's execution layer (wasm_patches/datax-exec.js).
 * This module retains only the normalization helpers.
 */
import type { IJupyterOutput } from './code-commands-types.js';
/**
 * Normalize a raw output object (which may arrive as a JSON string, or
 * wrapped in an extra `data` envelope) into a standard IJupyterOutput shape.
 *
 * Returns `null` when the value cannot be recognized.
 */
export declare function normalizeRunOutput(output: unknown): IJupyterOutput | null;
/**
 * Normalize a traceback value (array or string) into a single `\n`-joined string.
 */
export declare function normalizeTraceback(traceback: string | string[] | null | undefined): string;
//# sourceMappingURL=output-publisher.d.ts.map