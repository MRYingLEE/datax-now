/**
 * ContextService - Handles context sanitization and formatting for AI prompts
 *
 * Extracted from ai_agents.ts to demonstrate deepening by separating
 * context management from the core AI agent logic. This module provides
 * utilities for safely preparing context data for LLM consumption.
 */
export interface DataFrameProfile {
    __xeus_x_dataframe_profile__: true;
    format?: string;
    columns?: string[];
    ncols?: number;
    sample_rows?: Record<string, any>[];
    nrows?: number;
}
export declare class ContextService {
    private static readonly SAMPLE_ROWS;
    /** Check if a value looks like a DataFrame for prompt purposes */
    static isDataframeLike(value: unknown): value is Record<string, any>;
    /** Parse a CSV line into an array of values */
    static parseCsvLine(line: string): string[];
    /** Build a profile of a DataFrame for prompt inclusion */
    static buildDataframeProfileForPrompt(value: Record<string, any>): DataFrameProfile;
    /** Sanitize a context value for safe inclusion in prompts */
    static sanitizeContextValue(value: unknown): unknown;
    /** Convert context to a JSON string suitable for prompts */
    static stringifyContext(context: Record<string, any> | string): string;
}
export default ContextService;
//# sourceMappingURL=context-service.d.ts.map