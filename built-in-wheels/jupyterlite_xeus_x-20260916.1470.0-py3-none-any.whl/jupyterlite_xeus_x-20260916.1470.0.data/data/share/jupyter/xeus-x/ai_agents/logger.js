/**
 * Shared logging utilities for the AI Agents module.
 *
 * Routes through `globalThis._console` when available (Coincident worker proxy)
 * and falls back to the native `console` otherwise.
 */
export function createLogger(tag) {
    function _log(level, ...args) {
        const g = globalThis;
        const logger = (g?._console?.[level] ?? console[level] ?? console.log);
        logger?.(tag, ...args);
    }
    function _logWhenEnabled(level, ...args) {
        if (globalThis?.__AI_AGENTS_DEBUG__ !== true) {
            return;
        }
        _log(level, ...args);
    }
    return {
        debug: (...args) => _logWhenEnabled('debug', ...args),
        info: (...args) => _logWhenEnabled('info', ...args),
        diagnostic: (...args) => _logWhenEnabled('debug', ...args),
        warn: (...args) => _log('warn', ...args),
        error: (...args) => _log('error', ...args),
        log: (...args) => _log('log', ...args),
    };
}
/** Truncate and sanitize text for debug logging. */
export function preview(text, maxLen = 50) {
    return text.slice(0, maxLen).replace(/\n/g, '↵');
}
//# sourceMappingURL=logger.js.map