import type { LanguageModelV4 } from '@ai-sdk/provider';
import type { JupyterAIProviderConfig } from './llm-factory.js';
export declare function createFrontendDelegatedLanguageModel(config: JupyterAIProviderConfig, model: string): LanguageModelV4;
//# sourceMappingURL=frontend-delegated-model.d.ts.map