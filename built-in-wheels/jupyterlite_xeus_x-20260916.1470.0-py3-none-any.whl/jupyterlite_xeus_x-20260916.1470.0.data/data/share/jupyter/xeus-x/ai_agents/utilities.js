//
// Utilities for the AI Agents module.
// Provides constants, string processing helpers, and the window resolver.
// Centralized constants for reuse across the kernel codebase
// Keep string literals as const to preserve literal types
export const CONSTANTS = {
    // Status constants
    STATUS_OK: 'ok',
    STATUS_ERROR: 'error',
    // Language constants
    LANGUAGE_PYTHON: 'Python',
    LANGUAGE_JAVASCRIPT: 'javascript',
    LANGUAGE_R: 'R',
    // UI Messages
    THINKING_MESSAGE: 'thinking...',
    // Error messages
    EMPTY_AI_REQUEST: 'Empty AI request',
    EMPTY_CODE_GENERATION_REQUEST: 'Empty code generation request',
    EMPTY_JAVASCRIPT_GENERATION_REQUEST: 'Empty JavaScript generation request',
    EMPTY_R_GENERATION_REQUEST: 'Empty R generation request',
    EMPTY_GENERATION_REQUEST: 'Empty generation request',
    FAILED_TO_GENERATE_CODE: 'Failed to generate code',
    FAILED_TO_GENERATE_JAVASCRIPT_CODE: 'Failed to generate JavaScript code',
    FAILED_TO_GENERATE_R_CODE: 'Failed to generate R code',
    AI_CODE_GENERATION_EMPTY_RESULT: 'AI code generation returned empty result',
    AI_JAVASCRIPT_GENERATION_EMPTY_RESULT: 'AI JavaScript generation returned empty result',
    AI_R_GENERATION_EMPTY_RESULT: 'AI R generation returned empty result',
    AI_MIXED_CODE_GENERATION_EMPTY_RESULT: 'AI mixed code generation returned empty result',
    // Generation messages
    GENERATING_PYTHON_CODE: 'Generating Python code...',
    GENERATED_PYTHON_CODE: 'Generated Python code',
    GENERATING_JAVASCRIPT_CODE: 'Generating JavaScript code...',
    GENERATED_JAVASCRIPT_CODE: 'Generated JavaScript code',
    GENERATING_R_CODE: 'Generating R code...',
    GENERATED_R_CODE: 'Generated R code',
    GENERATING_MIXED_CODE: 'Generating mixed code...',
    GENERATED_MIXED_CODE: 'Generated mixed code',
    // Fix code messages
    FIXING_PYTHON_CODE: 'Fixing Python code...',
    FIXED_PYTHON_CODE: 'Fixed Python code',
    FIXING_JAVASCRIPT_CODE: 'Fixing JavaScript code...',
    FIXED_JAVASCRIPT_CODE: 'Fixed JavaScript code',
    FIXING_R_CODE: 'Fixing R code...',
    FIXED_R_CODE: 'Fixed R code',
    FIXING_MIXED_CODE: 'Fixing mixed code...',
    FIXED_MIXED_CODE: 'Fixed mixed code',
    // Empty string
    EMPTY_STRING: '',
};
export var LanguageType_Lowercase;
(function (LanguageType_Lowercase) {
    LanguageType_Lowercase["JavaScript"] = "javascript";
    LanguageType_Lowercase["Python"] = "python";
    LanguageType_Lowercase["R"] = "r";
})(LanguageType_Lowercase || (LanguageType_Lowercase = {}));
export function isStringList(variable) {
    return Array.isArray(variable) && variable.every((item) => typeof item === 'string');
}
/**
 * Resolve the main-thread `window` reference in a worker-safe way.
 *
 * In the xeus Coincident worker, the main-thread `window` proxy is stored
 * at `globalThis._window` (not `globalThis.window`, because assigning to
 * `globalThis.window` in a worker breaks tests — see coincident.worker.ts).
 *
 * This helper checks both locations so that ai_agents works whether it runs
 * in the main thread (globalThis.window) or in the Coincident web-worker
 * (globalThis._window).
 */
export function resolveWindow() {
    const g = globalThis;
    return g?._window ?? g?.window ?? null;
}
/**
 * Remove fenced code block formatting and return the code inside
 * @param fencedCode Code potentially wrapped in fenced code blocks
 * @param language Language identifier (python, javascript, r, etc.)
 * @returns Raw code without fence markers
 */
export function deFencedCode(fencedCode, language) {
    try {
        // Helper to escape regex special characters in unknown language identifiers
        const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        // Normalize and create language pattern to match aliases, using non-capturing groups
        const languageStr = String(language ?? '').trim();
        const lower = languageStr.toLowerCase();
        let languagePattern;
        if (lower === 'python' || lower === 'py') {
            languagePattern = '(?:python|py)';
        }
        else if (lower === 'javascript' || lower === 'js') {
            languagePattern = '(?:javascript|js)';
        }
        else if (lower === 'typescript' || lower === 'ts') {
            languagePattern = '(?:typescript|ts)';
        }
        else if (lower === 'r' || lower === 'rlang') {
            languagePattern = '(?:r|rlang)';
        }
        else if (lower.length > 0) {
            languagePattern = escapeRegex(lower);
        }
        else {
            // If no language provided, match any non-newline token after the backticks
            languagePattern = '[^\n]*';
        }
        // Remove the fenced code block formatting and return the code inside.
        // Use case-insensitive flag to tolerate different capitalizations of the language tag.
        // Return the LAST captured group to avoid issues if languagePattern contains capturing groups.
        const regex = new RegExp(`^\\s*(~~~|\`\`\`)${languagePattern}\\s*\\n([\\s\\S]*?)\\n\\1\\s*$`, 'mi');
        const match = fencedCode.match(regex);
        if (match && match.length > 2) {
            return match[2].trim();
        }
        // Fallback: strip any fenced block regardless of language identifier
        const generic = fencedCode.match(/^[\s\S]*?(?:```|~~~)[^\n]*\s*([\s\S]*?)\s*(?:```|~~~)[\s\S]*?$/m);
        if (generic && generic.length > 1) {
            return generic[generic.length - 1].trim();
        }
    }
    catch (e) {
        globalThis._console?.error('[Utilities] Error in deFencedCode:', e);
    }
    return fencedCode; // If no match, return the original string
}
/**
 * Extract all fenced code blocks from a markdown string.
 * Returns them in order of appearance with the raw language tag preserved.
 * Shared by cache-utils, code-commands, and ai_agents to ensure consistent parsing.
 */
export function extractFencedBlocks(markdown) {
    const blocks = [];
    const lines = String(markdown ?? '').split(/\r?\n/);
    let inBlock = false;
    let fence = '';
    let language = '';
    let buffer = [];
    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('```') || trimmed.startsWith('~~~')) {
            const marker = trimmed.slice(0, 3);
            if (!inBlock) {
                inBlock = true;
                fence = marker;
                language = trimmed.slice(3).trim();
                buffer = [];
            }
            else if (marker === fence) {
                inBlock = false;
                blocks.push({ language, code: buffer.join('\n') });
                fence = '';
                language = '';
                buffer = [];
            }
            continue;
        }
        if (inBlock) {
            buffer.push(line);
        }
    }
    // Flush an unclosed block (tolerant parsing)
    if (inBlock) {
        blocks.push({ language, code: buffer.join('\n') });
    }
    return blocks;
}
// ============================================================================
// Language detection helpers (moved from code-commands.ts)
// ============================================================================
/**
 * Python module names used to detect Python context from variable namespaces.
 */
export const PYTHON_MODULE_CANDIDATES = [
    'numpy',
    'pandas',
    'matplotlib',
    'scipy',
    'sklearn',
    'tensorflow',
    'torch',
    'requests',
    'datetime',
];
/**
 * Collect imported Python module names that appear in a variable namespace.
 * Only applies to Python; returns an empty array for other languages.
 */
export function collectModulesFromContext(languageKey, currentContext) {
    if (languageKey !== 'python' || typeof currentContext !== 'object') {
        return [];
    }
    return Object.keys(currentContext).filter((key) => PYTHON_MODULE_CANDIDATES.includes(key.toLowerCase()));
}
/**
 * Normalize a fenced code block language tag to a canonical form.
 */
export function normalizeFenceLanguage(language) {
    const lower = String(language ?? '').trim().toLowerCase();
    if (!lower || lower === 'py' || lower === 'python') {
        return 'python';
    }
    if (lower === 'js' || lower === 'javascript') {
        return 'javascript';
    }
    if (lower === 'r') {
        return 'r';
    }
    if (lower === 'ts' || lower === 'typescript') {
        return 'typescript';
    }
    if (lower === 'tsx') {
        return 'tsx';
    }
    return lower;
}
/** R-specific keywords unlikely to appear in English prose */
const R_KEYWORDS = [
    'ggplot', 'data.frame', 'dplyr', 'tidyverse', 'tidyr',
    'tibble', 'ggplot2', 'geom_', 'aes(', 'mutate(', 'summarise(',
    'library(', 'cran', 'readr', 'stringr', 'lubridate', 'purrr',
    'data.table', 'shiny',
];
/**
 * Auto-detect the target language from a natural-language requirement string.
 * Defaults to Python when no language-specific signals are found.
 */
export function detectLanguage(requirement) {
    const lowerReq = requirement.toLowerCase();
    const hasRKeyword = R_KEYWORDS.some(kw => lowerReq.includes(kw));
    const hasRPhrase = /\b(?:in|using|with|use)\s+r\b/.test(lowerReq)
        || /\br\s+(?:code|script|language|program|function|package)\b/.test(lowerReq);
    if (lowerReq.includes('javascript') || /\bjs\b/.test(lowerReq)) {
        return 'javascript';
    }
    if (hasRKeyword || hasRPhrase) {
        return 'r';
    }
    return 'python';
}
//# sourceMappingURL=utilities.js.map