import type { EmbeddingModel, LanguageModel } from 'ai';
export { DUMMY_API_KEY, createCompatibleFetch, isNonEmptyString } from './openai-compatible.js';
export type JupyterAIProviderConfig = {
    id: string;
    provider: string;
    model: string;
    name: string;
    apiKey?: string;
    baseURL?: string;
    headers?: Record<string, string>;
    parameters?: {
        temperature?: number;
        maxOutputTokens?: number;
    };
};
export type LLMRequestOptions = {
    temperature?: number;
    maxOutputTokens?: number;
};
/**
 * Resolve effective generation-call options from explicit per-request overrides
 * and the active provider's configured defaults.
 *
 * The AI SDK consumes these at call / agent-construction time rather than when
 * creating the provider-backed `LanguageModel` instance.
 */
export declare function resolveLLMRequestOptions(overrides?: LLMRequestOptions, config?: JupyterAIProviderConfig | null, modelOverride?: string): LLMRequestOptions;
/**
 * Read the currently active provider configuration from `window.jupyter_ai`.
 *
 * Combines `jupyter_ai.active_provider` (or legacy `active_providers`)
 * with the matching entry in `jupyter_ai.settings.providers` to pick up
 * headers, parameters, and apiKey (when the upstream exposes it).
 *
 * Falls back to {@link getEnvFallbackProviderConfig} when no provider is
 * configured or `window.jupyter_ai` is not yet available, and returns
 * `null` only when neither source yields a usable provider.
 */
export declare function getActiveProviderConfig(): JupyterAIProviderConfig | null;
/**
 * Create a Vercel AI SDK `LanguageModelV1` instance from a provider config.
 *
 * Models are resolved through a per-provider registry first so that
 * `provider/model` identifiers and future native-provider factories have a
 * canonical path. The OpenAI-compatible transport remains the fallback
 * implementation behind that registry entry.
 */
export declare function createLLMFromProvider(config: JupyterAIProviderConfig, _temperatureOverride?: number): LanguageModel;
export declare function createEmbeddingModelFromProvider(config: JupyterAIProviderConfig): EmbeddingModel;
/**
 * Public default model identifier used by the DataX API when no `model`
 * option is provided by the caller.
 */
export declare const DEFAULT_API_MODEL = "openai/gpt-5-mini";
/**
 * Override the model used by the next LLM call.
 * Pass `undefined` to clear the override and restore the active provider's
 * configured model.
 *
 * @deprecated Prefer passing `modelOverride` directly to {@link getLLM} to
 * avoid shared mutable request state.
 */
export declare function setModelOverride(model: string | undefined): void;
/**
 * Get (or create) a cached LLM instance from the active `window.jupyter_ai`
 * provider.
 *
 * The cache is invalidated when the `jupyter_ai` reference changes (the
 * global-api replaces the frozen object on every settings update).
 *
 * When `modelOverride` is supplied (preferred) or when a per-request model
 * override is active via {@link setModelOverride} (legacy, WASM-only), the
 * cache is bypassed and a fresh instance is returned using the overridden
 * model with the rest of the active provider's settings.
 *
 * Prefer passing `modelOverride` directly rather than using
 * {@link setModelOverride} — the direct parameter is safe for concurrent
 * callers, whereas the module-level override is not.
 *
 * @param temperatureOverride  Optional temperature; falls back to the
 *                             provider's configured temperature.
 * @param modelOverride        Optional model id; bypasses the cache and
 *                             overrides the provider's configured model for
 *                             this single call.
 * @returns A `LanguageModel` or `null` when no provider is configured.
 */
export declare function getLLM(temperatureOverride?: number, modelOverride?: string): LanguageModel | null;
export declare function getLLMRequestOptions(overrides?: LLMRequestOptions, modelOverride?: string): LLMRequestOptions;
export declare function getEmbeddingModel(modelOverride?: string): EmbeddingModel | null;
//# sourceMappingURL=llm-factory.d.ts.map