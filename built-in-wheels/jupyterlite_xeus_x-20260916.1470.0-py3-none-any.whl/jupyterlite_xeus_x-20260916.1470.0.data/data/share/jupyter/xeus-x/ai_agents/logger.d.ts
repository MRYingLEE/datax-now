/**
 * Shared logging utilities for the AI Agents module.
 *
 * Routes through `globalThis._console` when available (Coincident worker proxy)
 * and falls back to the native `console` otherwise.
 */
export declare function createLogger(tag: string): {
    debug: (...args: any[]) => void;
    info: (...args: any[]) => void;
    diagnostic: (...args: any[]) => void;
    warn: (...args: any[]) => void;
    error: (...args: any[]) => void;
    log: (...args: any[]) => void;
};
/** Truncate and sanitize text for debug logging. */
export declare function preview(text: string, maxLen?: number): string;
//# sourceMappingURL=logger.d.ts.map