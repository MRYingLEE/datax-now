/**
 * Type definitions for the Code Command Execution API.
 *
 * Extracted from code-commands.ts for reuse across modules.
 */
import type { JSONValue, JSONObject } from '@lumino/coreutils';
import type { AIAgentsRequestType } from './cache-utils.js';
/**
 * MIME bundle: maps MIME types to their content.
 * Values are plain strings (multi-line text is pre-joined by the C++ kernel).
 */
export type MimeBundle = Record<string, string>;
/**
 * Discriminated union of all Jupyter nbformat output types.
 * Use this instead of `any` wherever Jupyter output objects are stored or passed.
 */
export type IJupyterOutput = {
    output_type: 'execute_result';
    execution_count: number | null;
    data: MimeBundle;
    metadata: Record<string, unknown>;
} | {
    output_type: 'display_data';
    data: MimeBundle;
    metadata: Record<string, unknown>;
    transient?: {
        display_id?: string;
    };
} | {
    output_type: 'update_display_data';
    data: MimeBundle;
    metadata: Record<string, unknown>;
    transient: {
        display_id: string;
    };
} | {
    output_type: 'stream';
    name: 'stdout' | 'stderr';
    text: string;
} | {
    output_type: 'error';
    ename: string;
    evalue: string;
    traceback: string[];
};
/**
 * Run status from Code Interpreter API
 */
export type RunStatus = 'queued' | 'in_progress' | 'completed' | 'failed' | 'cancelled';
/**
 * Display choice for streaming output
 */
export type DisplayChoice = 'invisible' | 'running_indicator' | 'all' | 'results_only';
/**
 * Run result from Code Interpreter API
 */
export interface IRunResult {
    id: string;
    status: RunStatus;
    outputs: IJupyterOutput[];
    execution_count?: number;
    error_name?: string;
    error_value?: string;
    traceback?: string[];
    created_at: string;
    finished_at: string;
}
/**
 * Run options for Code Interpreter API
 */
export interface IRunOptions {
    language?: string;
    variable_sync?: 'on' | 'off';
    timeout_ms?: number;
    session_id?: string;
    streaming?: {
        enabled: boolean;
        display?: {
            initial?: DisplayChoice;
            end?: DisplayChoice;
        };
    };
    /** When set, stream outputs (stdout/stderr) are redirected to
     *  update_display_data targeting this display_id instead of being
     *  published as normal stream messages. */
    stream_redirect_display_id?: string;
}
/**
 * DataX language proxy interface (for TypeScript typing)
 */
export interface ILanguageProxy {
    /** All variables in this language's namespace (raw JSON object) */
    vars: Record<string, any>;
    /**
     * Markdown-formatted context string for AI prompt assembly.
     * Uses adaptive formatting (vanilla / inline-comment / structured Markdown)
     * as defined in docs/devops/feature_context.md.
     * Returns null if the kernel does not support getContextForPrompt().
     */
    context?: string | null;
    /**
     * Execute code in this language
     * @param code Code to execute
     * @param options Execution options
     * @returns Run result
     */
    run(code: string, options?: IRunOptions): Promise<IRunResult>;
    /**
     * Execute code asynchronously
     * @param code Code to execute
     * @param options Execution options
     * @returns Run result
     */
    run_async(code: string, options?: IRunOptions): Promise<IRunResult>;
    /**
     * Alias for run()
     */
    execute(code: string, options?: IRunOptions): Promise<IRunResult>;
}
/**
 * DataX namespace interface (for TypeScript typing)
 */
export interface IDataxNamespace {
    /** Python language proxy */
    python: ILanguageProxy;
    /** R language proxy */
    r: ILanguageProxy;
    /** JavaScript language proxy */
    javascript: ILanguageProxy;
}
/**
 * Configuration for CodeCommandExecutor
 */
export interface ICodeCommandConfig {
    /**
     * DataX instance for code execution and variable access
     * Must provide python, r, and javascript language proxies
     */
    datax: IDataxNamespace;
    /** Execution count provider (optional - datax provides it via run results) */
    getExecutionCount?: () => number;
    /** Maximum retry attempts for code generation (default: 5) */
    maxRetries?: number;
}
/**
 * Result from code generation and execution
 */
export interface ICodeGoResult {
    status: 'ok' | 'error';
    execution_count: number;
    user_expressions?: JSONValue;
    ename?: string;
    evalue?: string;
    traceback?: string[];
    /** Generated markdown (mixed-language) or code preview when available */
    generated?: string;
    /** Detected target language for @gen/@go flows */
    detectedLanguage?: 'python' | 'javascript' | 'r';
    /** True when a cached generation is replayed */
    cached?: boolean;
    /** Last execution outputs (optional) */
    outputs?: IJupyterOutput[];
    /** Internal bridge hint: generated-code outputs were already published to IOPub */
    outputs_published?: boolean;
}
/**
 * Shared context passed to engine functions extracted from CodeCommandExecutor.
 */
export interface ICodeCommandContext {
    config: ICodeCommandConfig;
    createSessionId(prefix: string): string;
    resolveSourceTag(command: string): AIAgentsRequestType;
    resolveMetadata(metadata?: JSONObject): JSONObject;
    resolveLanguageProxy(key: 'python' | 'javascript' | 'r'): ILanguageProxy | null;
    getExecutionCount(): number;
}
//# sourceMappingURL=code-commands-types.d.ts.map