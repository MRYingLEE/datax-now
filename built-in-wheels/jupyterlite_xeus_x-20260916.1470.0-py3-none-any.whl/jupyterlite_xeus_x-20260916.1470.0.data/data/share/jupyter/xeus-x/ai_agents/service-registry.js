import { embed, embedMany, jsonSchema, } from 'ai';
import { getEmbeddingModel, getLLM, getLLMRequestOptions, } from './llm-factory.js';
import { smartAsk } from './datax-api.js';
import { normalizeAIError, normalizeServiceError, } from './ai-error-utils.js';
import { createNativeObjectAgent, createNativeTextAgent, } from './native-agent.js';
import { GENAI_MAX_RETRIES } from './genai-retry.js';
function errorResult(service, method, type, message, retryable = false) {
    return {
        status: 'error',
        service,
        method,
        error: { type, message, retryable },
    };
}
function isObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function requireString(service, method, payload, key) {
    if (typeof payload[key] !== 'string' || String(payload[key]).trim().length === 0) {
        return errorResult(service, method, 'ValidationError', `Payload field "${key}" must be a non-empty string`);
    }
    return null;
}
function normalizeProviderError(error) {
    return normalizeServiceError(error);
}
function getConfiguredModel(service, method, model) {
    const modelName = typeof model === 'string' && model.trim().length > 0 ? model : undefined;
    const llm = getLLM(undefined, modelName);
    if (!llm) {
        return errorResult(service, method, 'ProviderAuthError', 'No active provider configured in window.jupyter_ai', false);
    }
    return llm;
}
function getGenerationOptions(payload) {
    const modelOverride = typeof payload.model === 'string' && payload.model.trim().length > 0
        ? payload.model
        : undefined;
    const requestOptions = getLLMRequestOptions({
        ...(typeof payload.temperature === 'number' ? { temperature: payload.temperature } : {}),
        ...(typeof payload.maxTokens === 'number' ? { maxOutputTokens: payload.maxTokens } : {}),
    }, modelOverride);
    return requestOptions;
}
function toSmartAskServiceOptions(payload) {
    const rawOpts = isObject(payload.options) ? payload.options : {};
    return {
        ...(typeof rawOpts.preferredLanguage === 'string' ? { preferredLanguage: rawOpts.preferredLanguage } : {}),
        ...(typeof rawOpts.executionPolicy === 'string' ? { executionPolicy: rawOpts.executionPolicy } : {}),
        ...(typeof rawOpts.execute === 'boolean' ? { execute: rawOpts.execute } : {}),
        ...(typeof rawOpts.streaming === 'boolean' ? { streaming: rawOpts.streaming } : {}),
        ...(typeof rawOpts.displayId === 'string' ? { displayId: rawOpts.displayId } : {}),
        ...(typeof rawOpts.maxRetries === 'number' ? { maxRetries: rawOpts.maxRetries } : {}),
        ...(typeof rawOpts.timeoutMs === 'number' ? { timeoutMs: rawOpts.timeoutMs } : {}),
        ...(typeof rawOpts.showStopButton === 'boolean' ? { showStopButton: rawOpts.showStopButton } : {}),
        ...(rawOpts.context !== undefined ? { context: rawOpts.context } : {}),
        ...(rawOpts.abortSignal instanceof AbortSignal ? { abortSignal: rawOpts.abortSignal } : {}),
    };
}
function isSmartAskErrorResult(result) {
    return result.status === 'error';
}
function isSmartAskSuccessResult(result) {
    return result.status === 'ok';
}
function isServiceCallResult(value) {
    return isObject(value) && value.status === 'error';
}
function toObjectSchema(schema) {
    return jsonSchema(schema);
}
function createServiceObjectAgent(model, payload) {
    const generationOptions = getGenerationOptions(payload);
    return createNativeObjectAgent({
        model,
        schema: toObjectSchema(payload.schema),
        ...(typeof payload.system === 'string' ? { instructions: payload.system } : {}),
        ...(generationOptions.temperature !== undefined ? { temperature: generationOptions.temperature } : {}),
        ...(generationOptions.maxOutputTokens !== undefined
            ? { maxOutputTokens: generationOptions.maxOutputTokens }
            : {}),
    });
}
function createServiceTextAgent(model, payload) {
    const generationOptions = getGenerationOptions(payload);
    return createNativeTextAgent({
        model,
        ...(typeof payload.system === 'string' ? { instructions: payload.system } : {}),
        ...(generationOptions.temperature !== undefined ? { temperature: generationOptions.temperature } : {}),
        ...(generationOptions.maxOutputTokens !== undefined
            ? { maxOutputTokens: generationOptions.maxOutputTokens }
            : {}),
    });
}
function getEmbeddingModelOrError(service, method, payload) {
    const modelName = typeof payload.model === 'string' && payload.model.trim().length > 0
        ? payload.model
        : undefined;
    const embeddingModel = getEmbeddingModel(modelName);
    if (!embeddingModel) {
        return errorResult(service, method, 'ProviderAuthError', 'No active provider configured in window.jupyter_ai');
    }
    return embeddingModel;
}
async function callGenerateText(service, method, payload) {
    const promptError = requireString(service, method, payload, 'prompt');
    if (promptError)
        return promptError;
    {
        const llm = getConfiguredModel(service, method, payload.model);
        if (isServiceCallResult(llm))
            return llm;
        try {
            const model = llm;
            const agent = createServiceTextAgent(model, payload);
            const result = await agent.generate({
                prompt: String(payload.prompt),
            });
            return {
                status: 'success',
                service,
                method,
                text: result.text,
                finishReason: result.finishReason,
                usage: result.usage,
                warnings: result.warnings ?? [],
                sdkResult: result.sdkResult,
            };
        }
        catch (error) {
            return { status: 'error', service, method, error: normalizeProviderError(error) };
        }
    }
}
async function callStreamText(service, method, payload) {
    const promptError = requireString(service, method, payload, 'prompt');
    if (promptError)
        return promptError;
    const llm = getConfiguredModel(service, method, payload.model);
    if (isServiceCallResult(llm))
        return llm;
    try {
        const model = llm;
        const agent = createServiceTextAgent(model, payload);
        const result = await agent.stream({
            prompt: String(payload.prompt),
        });
        return {
            status: 'success',
            service,
            method,
            textStream: result.textStream,
            fullStream: result.fullStream,
            text: result.sdkResult.text,
            finishReason: result.sdkResult.finishReason,
            usage: result.sdkResult.usage,
            warnings: result.sdkResult.warnings,
            sdkResult: result.sdkResult,
        };
    }
    catch (error) {
        return { status: 'error', service, method, error: normalizeProviderError(error) };
    }
}
async function callGenerateObject(service, method, payload) {
    const promptError = requireString(service, method, payload, 'prompt');
    if (promptError)
        return promptError;
    if (!isObject(payload.schema)) {
        return errorResult(service, method, 'ValidationError', 'Payload field "schema" must be a JSON schema object');
    }
    {
        const llm = getConfiguredModel(service, method, payload.model);
        if (isServiceCallResult(llm))
            return llm;
        try {
            const model = llm;
            const agent = createServiceObjectAgent(model, payload);
            const result = await agent.generate({
                prompt: String(payload.prompt),
            });
            return {
                status: 'success',
                service,
                method,
                object: result.output,
                text: result.text,
                finishReason: result.finishReason,
                usage: result.usage,
                warnings: result.warnings ?? [],
                sdkResult: result.sdkResult,
            };
        }
        catch (error) {
            return { status: 'error', service, method, error: normalizeProviderError(error) };
        }
    }
}
async function callStreamObject(service, method, payload) {
    const promptError = requireString(service, method, payload, 'prompt');
    if (promptError)
        return promptError;
    if (!isObject(payload.schema)) {
        return errorResult(service, method, 'ValidationError', 'Payload field "schema" must be a JSON schema object');
    }
    const llm = getConfiguredModel(service, method, payload.model);
    if (isServiceCallResult(llm))
        return llm;
    try {
        const model = llm;
        const agent = createServiceObjectAgent(model, payload);
        const result = await agent.stream({
            prompt: String(payload.prompt),
        });
        return {
            status: 'success',
            service,
            method,
            partialObjectStream: result.partialObjectStream,
            textStream: result.textStream,
            fullStream: result.fullStream,
            object: result.object,
            text: result.sdkResult.text,
            finishReason: result.sdkResult.finishReason,
            usage: result.sdkResult.usage,
            warnings: result.sdkResult.warnings,
            sdkResult: result.sdkResult,
        };
    }
    catch (error) {
        return { status: 'error', service, method, error: normalizeProviderError(error) };
    }
}
async function callEmbed(service, method, payload) {
    const text = typeof payload.text === 'string' ? payload.text : undefined;
    const values = Array.isArray(payload.values) ? payload.values.filter((value) => typeof value === 'string') : undefined;
    if (!text && !values) {
        return errorResult(service, method, 'ValidationError', 'Payload must include "text" or "values"');
    }
    {
        const embeddingModel = getEmbeddingModelOrError(service, method, payload);
        if (isServiceCallResult(embeddingModel)) {
            return embeddingModel;
        }
        try {
            if (values) {
                const result = await embedMany({
                    model: embeddingModel,
                    values,
                    maxRetries: GENAI_MAX_RETRIES,
                });
                return {
                    status: 'success',
                    service,
                    method,
                    embeddings: result.embeddings,
                    usage: result.usage,
                    warnings: result.warnings ?? [],
                    sdkResult: result,
                };
            }
            else {
                const result = await embed({
                    model: embeddingModel,
                    value: text,
                    maxRetries: GENAI_MAX_RETRIES,
                });
                return {
                    status: 'success',
                    service,
                    method,
                    embedding: result.embedding,
                    usage: result.usage,
                    warnings: result.warnings ?? [],
                    sdkResult: result,
                };
            }
        }
        catch (error) {
            return { status: 'error', service, method, error: normalizeProviderError(error) };
        }
    }
}
async function callSmartAsk(service, method, payload) {
    const questionError = requireString(service, method, payload, 'question');
    if (questionError)
        return questionError;
    {
        // smartAsk inherently handles configuration errors and checks for LLM availability
        try {
            const options = {
                ...toSmartAskServiceOptions(payload),
                ...(typeof payload.model === 'string' ? { model: payload.model } : {}),
            };
            const result = await smartAsk(String(payload.question), options);
            // ISmartAskResult uses status 'ok' for success and 'error' for failure.
            // Destructure status out before spreading so it never overwrites the
            // IServiceCallResult contract ('success' | 'error').
            if (isSmartAskErrorResult(result)) {
                const normalized = normalizeAIError({
                    name: result.ename,
                    message: result.evalue || result.ename || 'smartAsk failed',
                });
                return errorResult(service, method, normalized.ename, normalized.evalue, false);
            }
            if (isSmartAskSuccessResult(result)) {
                const { status: _smartAskStatus, ...restResult } = result;
                return {
                    status: 'success',
                    service,
                    method,
                    ...restResult,
                };
            }
            return errorResult(service, method, 'RuntimeError', 'smartAsk returned an unknown state', false);
        }
        catch (error) {
            return { status: 'error', service, method, error: normalizeProviderError(error) };
        }
    }
}
export async function callService(service, method, payload = {}, 
// _options is reserved for future cross-cutting concerns (e.g. timeout_ms, tracing).
// It is accepted but not yet consumed — callers should not rely on it having any effect.
_options = {}) {
    const serviceId = String(service ?? '');
    const methodName = String(method ?? '');
    const input = isObject(payload) ? payload : {};
    if (serviceId !== 'ai') {
        return errorResult(serviceId, methodName, 'ServiceNotFound', `Unknown service: ${serviceId}`);
    }
    switch (methodName) {
        case 'generateText':
            return callGenerateText(serviceId, methodName, input);
        case 'streamText':
            return callStreamText(serviceId, methodName, input);
        case 'generateObject':
            return callGenerateObject(serviceId, methodName, input);
        case 'streamObject':
            return callStreamObject(serviceId, methodName, input);
        case 'embed':
            return callEmbed(serviceId, methodName, input);
        case 'smartAsk':
            return callSmartAsk(serviceId, methodName, input);
        default:
            return errorResult(serviceId, methodName, 'MethodNotFound', `Unknown method for service "${serviceId}": ${methodName}`);
    }
}
export const serviceRegistry = {
    call: callService,
};
//# sourceMappingURL=service-registry.js.map