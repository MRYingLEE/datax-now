/**
 * ContextService - Handles context sanitization and formatting for AI prompts
 *
 * Extracted from ai_agents.ts to demonstrate deepening by separating
 * context management from the core AI agent logic. This module provides
 * utilities for safely preparing context data for LLM consumption.
 */
export class ContextService {
    /** Check if a value looks like a DataFrame for prompt purposes */
    static isDataframeLike(value) {
        return !!value && typeof value === 'object' && !Array.isArray(value) && value.__xeus_x_dataframe__ === true;
    }
    /** Parse a CSV line into an array of values */
    static parseCsvLine(line) {
        const values = [];
        let current = '';
        let inQuotes = false;
        for (let index = 0; index < line.length; index++) {
            const char = line[index];
            if (char === '"') {
                if (inQuotes && line[index + 1] === '"') {
                    current += '"';
                    index += 1;
                }
                else {
                    inQuotes = !inQuotes;
                }
                continue;
            }
            if (char === ',' && !inQuotes) {
                values.push(current);
                current = '';
                continue;
            }
            current += char;
        }
        values.push(current);
        return values;
    }
    /** Build a profile of a DataFrame for prompt inclusion */
    static buildDataframeProfileForPrompt(value) {
        const profile = { __xeus_x_dataframe_profile__: true };
        const format = value.format;
        if (typeof format === 'string' && format.trim().length > 0) {
            profile.format = format;
        }
        const csv = value.csv || '';
        const lines = csv.split(/\r?\n/).map((line) => line.trim()).filter((line) => line.length > 0);
        if (lines.length > 0) {
            const columns = this.parseCsvLine(lines[0]);
            profile.columns = columns;
            profile.ncols = columns.length;
            const sampleRows = lines.slice(1, 1 + this.SAMPLE_ROWS).map((line) => {
                const values = this.parseCsvLine(line);
                return Object.fromEntries(values.map((cell, i) => [columns[i] || `column_${i + 1}`, cell]));
            });
            if (sampleRows.length > 0) {
                profile.sample_rows = sampleRows;
            }
            if (typeof value.nrows === 'number' && Number.isFinite(value.nrows)) {
                profile.nrows = value.nrows;
            }
            else if (!value.nrows) {
                profile.nrows = Math.max(lines.length - 1, 0);
            }
        }
        return profile;
    }
    /** Sanitize a context value for safe inclusion in prompts */
    static sanitizeContextValue(value) {
        if (Array.isArray(value)) {
            return value.map(item => this.sanitizeContextValue(item));
        }
        if (!value || typeof value !== 'object') {
            return value;
        }
        if (this.isDataframeLike(value)) {
            return this.buildDataframeProfileForPrompt(value);
        }
        return Object.fromEntries(Object.entries(value).map(([key, entryValue]) => [key, this.sanitizeContextValue(entryValue)]));
    }
    /** Convert context to a JSON string suitable for prompts */
    static stringifyContext(context) {
        if (typeof context === 'string') {
            const trimmed = context.trim();
            if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
                try {
                    return JSON.stringify(this.sanitizeContextValue(JSON.parse(trimmed)), null, 2);
                }
                catch {
                    return context;
                }
            }
            return context;
        }
        return JSON.stringify(this.sanitizeContextValue(context), null, 2);
    }
}
ContextService.SAMPLE_ROWS = 3;
export default ContextService;
//# sourceMappingURL=context-service.js.map