import { Output, type CallWarning, type EmbedManyResult, type EmbedResult, type EmbeddingModelUsage, type FinishReason, type GenerateTextResult, type LanguageModelUsage, type StreamTextResult, type ToolSet } from 'ai';
export type ServiceErrorType = 'ValidationError' | 'ServiceNotFound' | 'MethodNotFound' | 'ProviderAuthError' | 'ProviderError' | 'TimeoutError' | 'AbortError' | 'RuntimeError';
export interface IServiceError {
    type: ServiceErrorType;
    message: string;
    retryable: boolean;
}
export interface IServiceCallErrorResult {
    status: 'error';
    service: string;
    method: string;
    error?: IServiceError;
    [key: string]: unknown;
}
type ServiceTextOutput = ReturnType<typeof Output.text>;
type ServiceObjectOutput<OBJECT> = ReturnType<typeof Output.object<OBJECT>>;
type ServiceRuntimeContext = Record<string, never>;
type ServiceTextGenerateSDKResult = GenerateTextResult<ToolSet, ServiceRuntimeContext, ServiceTextOutput>;
type ServiceTextStreamSDKResult = StreamTextResult<ToolSet, ServiceRuntimeContext, ServiceTextOutput>;
type ServiceObjectGenerateSDKResult<OBJECT> = GenerateTextResult<ToolSet, ServiceRuntimeContext, ServiceObjectOutput<OBJECT>>;
type ServiceObjectStreamSDKResult<OBJECT> = StreamTextResult<ToolSet, ServiceRuntimeContext, ServiceObjectOutput<OBJECT>>;
interface IServiceSuccessBase<METHOD extends string> {
    status: 'success';
    service: string;
    method: METHOD;
}
export interface IGenerateTextServiceSuccessResult extends IServiceSuccessBase<'generateText'> {
    text: string;
    finishReason: FinishReason;
    usage: LanguageModelUsage;
    warnings: CallWarning[];
    sdkResult: ServiceTextGenerateSDKResult;
}
export interface IStreamTextServiceSuccessResult extends IServiceSuccessBase<'streamText'> {
    textStream: ServiceTextStreamSDKResult['textStream'];
    fullStream: ServiceTextStreamSDKResult['fullStream'];
    text: ServiceTextStreamSDKResult['text'];
    finishReason: ServiceTextStreamSDKResult['finishReason'];
    usage: ServiceTextStreamSDKResult['usage'];
    warnings: ServiceTextStreamSDKResult['warnings'];
    sdkResult: ServiceTextStreamSDKResult;
}
export interface IGenerateObjectServiceSuccessResult<OBJECT = unknown> extends IServiceSuccessBase<'generateObject'> {
    object: OBJECT;
    text: string;
    finishReason: FinishReason;
    usage: LanguageModelUsage;
    warnings: CallWarning[];
    sdkResult: ServiceObjectGenerateSDKResult<OBJECT>;
}
export interface IStreamObjectServiceSuccessResult<OBJECT = unknown> extends IServiceSuccessBase<'streamObject'> {
    partialObjectStream: ServiceObjectStreamSDKResult<OBJECT>['partialOutputStream'];
    textStream: ServiceObjectStreamSDKResult<OBJECT>['textStream'];
    fullStream: ServiceObjectStreamSDKResult<OBJECT>['fullStream'];
    object: ServiceObjectStreamSDKResult<OBJECT>['output'];
    text: ServiceObjectStreamSDKResult<OBJECT>['text'];
    finishReason: ServiceObjectStreamSDKResult<OBJECT>['finishReason'];
    usage: ServiceObjectStreamSDKResult<OBJECT>['usage'];
    warnings: ServiceObjectStreamSDKResult<OBJECT>['warnings'];
    sdkResult: ServiceObjectStreamSDKResult<OBJECT>;
}
export interface IEmbedServiceSuccessResult extends IServiceSuccessBase<'embed'> {
    embedding?: number[];
    embeddings?: number[][];
    usage: EmbeddingModelUsage;
    warnings: CallWarning[];
    sdkResult: EmbedResult | EmbedManyResult;
}
export interface ISmartAskServiceSuccessResult extends IServiceSuccessBase<'smartAsk'> {
    [key: string]: unknown;
}
export type IServiceCallResult<OBJECT = unknown> = IServiceCallErrorResult | IGenerateTextServiceSuccessResult | IStreamTextServiceSuccessResult | IGenerateObjectServiceSuccessResult<OBJECT> | IStreamObjectServiceSuccessResult<OBJECT> | IEmbedServiceSuccessResult | ISmartAskServiceSuccessResult;
type Payload = Record<string, unknown>;
export declare function callService(service: 'ai', method: 'generateText', payload?: Payload, _options?: Payload): Promise<IGenerateTextServiceSuccessResult | IServiceCallErrorResult>;
export declare function callService(service: 'ai', method: 'streamText', payload?: Payload, _options?: Payload): Promise<IStreamTextServiceSuccessResult | IServiceCallErrorResult>;
export declare function callService<OBJECT = unknown>(service: 'ai', method: 'generateObject', payload?: Payload, _options?: Payload): Promise<IGenerateObjectServiceSuccessResult<OBJECT> | IServiceCallErrorResult>;
export declare function callService<OBJECT = unknown>(service: 'ai', method: 'streamObject', payload?: Payload, _options?: Payload): Promise<IStreamObjectServiceSuccessResult<OBJECT> | IServiceCallErrorResult>;
export declare function callService(service: 'ai', method: 'embed', payload?: Payload, _options?: Payload): Promise<IEmbedServiceSuccessResult | IServiceCallErrorResult>;
export declare function callService(service: 'ai', method: 'smartAsk', payload?: Payload, _options?: Payload): Promise<ISmartAskServiceSuccessResult | IServiceCallErrorResult>;
export declare function callService(service: string, method: string, payload?: Payload, _options?: Payload): Promise<IServiceCallResult>;
export declare const serviceRegistry: {
    call: typeof callService;
};
export {};
//# sourceMappingURL=service-registry.d.ts.map