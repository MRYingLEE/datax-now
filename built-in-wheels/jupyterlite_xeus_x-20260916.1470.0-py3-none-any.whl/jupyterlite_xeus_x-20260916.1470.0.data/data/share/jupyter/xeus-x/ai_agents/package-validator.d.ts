/**
 * Package Constraint Validator
 *
 * Extracts imported package names from generated code and validates them
 * against required / prohibited constraints. Used inside the retry loop of
 * executeGenCodeGen so that violations are fed back to the AI as re-prompt
 * feedback rather than silently returned to the caller.
 *
 * Language support:
 *   Python     - import X, from X import Y (top-level package name only)
 *   R          - library(X), require(X), library("X"), require('X')
 *   JavaScript - import … from 'X', require('X'), import('X')
 *               (strips @scope/ prefix for matching)
 */
/**
 * Extract the set of imported top-level package names from generated code.
 */
export declare function extractImportedPackages(code: string, language: 'python' | 'r' | 'javascript'): Set<string>;
export interface IPackageValidationResult {
    valid: boolean;
    /** Required packages that are absent from the generated code */
    missingRequired: string[];
    /** Prohibited packages that appear in the generated code */
    usedProhibited: string[];
}
/**
 * Validate package constraints against the set of packages used in the code.
 *
 * @param code         Generated source code to inspect
 * @param language     Language of the code
 * @param required     Packages that MUST be imported
 * @param prohibited   Packages that MUST NOT be imported
 */
export declare function validatePackageConstraints(code: string, language: 'python' | 'r' | 'javascript', required: string[], prohibited: string[]): IPackageValidationResult;
/**
 * Build a human-readable feedback string that can be appended to a re-prompt
 * when generated code violates package constraints.
 */
export declare function buildConstraintViolationFeedback(result: IPackageValidationResult): string;
/**
 * Build a Markdown section describing the package constraints for inclusion
 * in the AI system prompt.
 *
 * Returns an empty string when all three lists are empty.
 */
export declare function buildPackageConstraintsSection(required: string[], optional: string[], prohibited: string[]): string;
//# sourceMappingURL=package-validator.d.ts.map