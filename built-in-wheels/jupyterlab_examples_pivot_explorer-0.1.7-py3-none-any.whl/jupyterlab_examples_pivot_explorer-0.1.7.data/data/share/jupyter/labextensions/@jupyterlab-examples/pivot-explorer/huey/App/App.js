function getDuckDbLogLevel(duckdb){
  let loglevel;
  const paramLoglevel = getSearchParams().loglevel;
  if (paramLoglevel){
    loglevel = duckdb.LogLevel[paramLoglevel];
    if (typeof loglevel !== 'number'){
      loglevel = duckdb.LogLevel[loglevel];
    }
  }
  return typeof loglevel === 'number' ? loglevel : duckdb.LogLevel.INFO;
}

// unused. for convenience/debugging
function duckDbRowToJSON(object){
  let pojo;
  if (typeof object.toJSON === 'function'){
    pojo = object.toJSON();
  }
  else {
    pojo = object;
  }
  return JSON.stringify(pojo, (key, value) => {
    if (value && value.constructor === BigInt){
      return parseFloat(value.toString());
    }
    else {
      return value;
    }
  }, 2);
}

function initDuckdbVersion(){
  const libUrl = byId('duckDbLibraryUrl');
  libUrl.setAttribute('href', window.duckDbLibraryUrl);
  libUrl.textContent = `DuckDB WASM ${duckdbLibraryVersion}`;
  
  if (!window.hueyDb) {
    return;
  }
  const connection = window.hueyDb.connection;
  const versionColumn = 'version';
  const apiColumn = 'api';
  const reservedWordsColumn = 'reserved_words';
  const columns = {
    "version()": versionColumn,
    "current_setting('duckdb_api')": apiColumn,
    "list( keyword_name )": reservedWordsColumn,
  };
  const selectListSql = Object.keys(columns).map(key => {
    return `${key} AS ${getQuotedIdentifier(columns[key])}`;
  }).join('\n,');
  let sql = `SELECT ${selectListSql}`;
  sql += [
    'FROM duckdb_keywords()'
  ].join('\n');
  const result = connection.query(sql)
  .then(resultset => {
    const row = resultset.get(0);
    const version = row[versionColumn];
    const api = row[apiColumn];
    const reservedWords = String( row[reservedWordsColumn] ).slice(1, -1).split(',');
    window.hueyDb.reservedWords = reservedWords;
    
    //(?<number>(?:\d+(\.\d*)?|\.\d+))|(?<string>(?<!')'(?:''|''|[^'])*'(?!'))|(?<multiLineComment>\/\*(?:(?!\*\/)[\s\S])*\*\/)|(?<singleLineComment>--(?:(?!\n)[\s\S])*(?=\n))|(?<punctuation>[\(\)\{\}\.\:;,\-\+<>=\*])|(?<quotedIdentifier>(?<!")"(?:""|""|[^"])+"(?!"))|(?<identifier>\w+)|(?<whitespace>\s+))
    
    const duckdbTokenizer = RegXpChef.compile(
      { $flags: 'gysi' }, 
      {
        keyword: {
          $begin: /\b/,
          $content: reservedWords,
          $end: /\b/
        },
        number: /\d+(\.\d*)?|\.\d+/,
        string: {
          $begin: '\'',
          $end: '\'',
          $escape: '\\'
        },
        multiLineComment: {
          $begin: '/*',
          $end: '*/'
        },
        singleLineComment: {
          $begin: '--',
          $end: /\r\n|\n|\r/,
          $endExclusive: true
        },
        punctuation: /[\(\)\{\}\.\:;,\-\+<>=\*]/,
        quotedIdentifier: {
          $begin: '"',
          $end: '"',
          $escape: '"'
        },
        identifier: /\b\w+\b/,
        whitespace: /\s+/
      }
    );
    window.hueyDb.duckdbTokenizer = duckdbTokenizer;
    initSecretsDialog();
    initCatalogsDialog();
    initAppPageState();  
    const duckdbVersionLabel = byId('duckdbVersionLabel');
    duckdbVersionLabel.textContent = `DuckDB ${version}, API: ${api}`;
  })
  .catch(error => {
    console.error(`Error fetching duckdb version info.`);
    console.error(error);
  });
}

async function analyzeDatasource(datasource){
  try {
    TabUi.setSelectedTab('#sidebar', '#attributesTab');
    clearSearch();
    uploadUi.getDialog().close();
    queryModel.setDatasource(datasource);
  }
  catch (error) {
    attributeUi.clear(false);
    const title = `Error reading datasource ${datasource.getId()}`;
    console.error(title);
    const description = error.message;
    console.error(error);
    showErrorDialog({
      title: title,
      description: description
    });
  }
}

function initExecuteQuery(){

  byId('runQueryButton').addEventListener('click', event => {
    pivotTableUi.updatePivotTableUi();
  });
  
  byId('sidebarPin').addEventListener('change', event => {
    Routing.updateRouteFromQueryModel(queryModel);
  });

  const autoRunQuery = byId('autoRunQuery');
  const settingsPath = ['querySettings', 'autoRunQuery'];
  autoRunQuery.checked = Boolean( settings.getSettings(settingsPath) );
  autoRunQuery.addEventListener('change', event => {
    const target = event.target;
    const checked = target.checked;
    settings.assignSettings('querySettings', {
      'autoRunQuery': checked
    });
    if (checked) {
      pivotTableUi.updatePivotTableUi();
    }
  });
}

function initAppPageState(){
  const currentRoute = Routing.getCurrentRoute();
  if (currentRoute){
    pageStateManager.setPageState(currentRoute);
  }
}

function initAppQueryModelEvents(){
  bufferEvents(queryModel, 'change', (event, count) => {
    if (count !== undefined) {
      return;
    }

    console.log(`buffered Events, event:`);
    const eventData = event.eventData;
    console.log(eventData);

    let currentDatasourceCaption, datasource = queryModel.getDatasource();
    if (datasource) {
      currentDatasourceCaption = DataSourcesUi.getCaptionForDatasource(datasource);
    }
    else {
      currentDatasourceCaption = '';
    }
    const currentDatasource = byId('currentDatasource');
    currentDatasource.setAttribute('data-current-datasource', currentDatasourceCaption);
    currentDatasource.firstChild.data = currentDatasourceCaption;

    const title = ExportUi.generateExportTitle(queryModel);
    document.title = 'Huey - ' + title;

    Routing.updateRouteFromQueryModel(queryModel);
  }, null, 50);
}

function initAppPivotTableEvents(){
  const tupleNumberFormatter = createNumberFormatter(0).format;
  pivotTableUi.addEventListener('updated', async event => {
    const eventData = event.eventData;
    const status = eventData.status;
    
    let numRowsTuples = '';
    let numColumnsTuples = '';
    
    switch (status) {
      case 'error':
        showErrorDialog(eventData.error);
        break;
      case 'success':
        const tupleCounts = eventData.tupleCounts;
        const cellsInfo = tupleCounts[QueryModel.AXIS_CELLS];

        numRowsTuples = tupleCounts[QueryModel.AXIS_ROWS];
        numRowsTuples = typeof numRowsTuples === 'number' ? tupleNumberFormatter(numRowsTuples) : '';
        if (cellsInfo.count > 1 && cellsInfo.axis === QueryModel.AXIS_ROWS) {
          numRowsTuples += ` × ${cellsInfo.count}`;
        }
        
        numColumnsTuples = tupleCounts[QueryModel.AXIS_COLUMNS];
        numColumnsTuples = typeof numColumnsTuples === 'number' ? tupleNumberFormatter(numColumnsTuples) : '';
        if (cellsInfo.count > 1 && cellsInfo.axis === QueryModel.AXIS_COLUMNS) {
          numColumnsTuples += ` × ${cellsInfo.count}`;
        }

        break;
    }
    byId('queryResultRowsInfo').textContent = numRowsTuples;
    byId('queryResultColumnsInfo').textContent = numColumnsTuples;
  });

  bufferEvents(pivotTableUi, 'busy', (event, count) => {
    if (count !== undefined) {
      return;
    }
    const busy = event.eventData.busy;
    const busyDialog = byId('visualizationProgressDialog');
    busyDialog[busy ? 'showModal' : 'close']();
  });
}

function initApplication(){
  initDragableDialogs();
  initDuckdbVersion();
  initDataSourcesUi();
  initQueryModel();
  initExportDialog();
  initAttributeUi();
  initSearch();
  initFilterUi();
  initQueryUi();
  initPivotTableUi();
  initExecuteQuery();
  initPageStateManager();
  initUploadUi();
  initDatasourceSettingsDialog();
  initSessionCloner();
  initQuickQueryMenu();
  initDataSourceMenu();
  initPwa();

  initAppQueryModelEvents();
  initAppPivotTableEvents();

  initPostMessageInterface();
  if (postMessageInterface) {
    postMessageInterface.sendReadyMessage();
  }
}
