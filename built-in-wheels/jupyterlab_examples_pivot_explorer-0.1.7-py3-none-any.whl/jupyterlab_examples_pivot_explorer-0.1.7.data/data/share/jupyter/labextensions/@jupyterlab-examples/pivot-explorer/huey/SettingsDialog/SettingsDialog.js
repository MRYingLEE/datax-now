class Settings extends EventEmitter {

  static localStorageKey = 'settings';

  #id = undefined;

  static #settingsTemplate = {
    datasourceSettings: {
      useLooseColumnTypeComparison: true,
      looseColumnTypes: {
        // loosest numeric class.
        number: [],
        // loosest integer class.
        integer: [],
        // loosest signed integer class
        signed: ['BIGINT', 'INTEGER', 'HUGEINT', 'SMALLINT', 'TINYINT'],
        // loosest unsigned integer class
        unsigned: ['UBIGINT', 'UINTEGER', 'USMALLINT', 'UTINYINT'],
        // loosest fractional number
        fractional: [],
        // loosest approximat (fractional) number
        approximate: ['DOUBLE', 'REAL'],
        // loosest fixed fractional number.
        fixed: [],
        // loosest date time temporal
        dateTime: [],
        // loosest character string class
        string: [],
        // loosest binary class
        binary: []
      }
    },
    localeSettings: {
      // https://en.wikipedia.org/wiki/Null_character#:~:text=In%20documentation%2C%20the%20null%20character,2400%20%E2%90%80%20SYMBOL%20FOR%20NULL.
      nullString: String.fromCharCode(Number('0x2400')),
      // for use in ORDER BY NULLS FIRST|LAST
      nullsSortOrder: {
        value: 'FIRST',
        options: [
          { value: 'FIRST', label: 'first', title: 'Sort NULL-values before other values.'},
          { value: 'LAST', label: 'last', title: 'Sort NULL-values after other values.'}
        ]
      },
      useDefaultLocale: true,
      locale: navigator.languages,
      minimumIntegerDigits: 1,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
      linkMinimumAndMaximumDecimals: true
    },
    sqlSettings: {
      keywordLetterCase: 'upperCase',
      alwaysQuoteIdentifiers: true,
      commaStyle: 'newlineBefore'
    },
    querySettings: {
      autoRunQuery: true,
      autoRunQueryTimeout: 1000,
      filterValuePicklistPageSize: 100,
      filterSearchAutoQueryTimeoutInMilliseconds: 1000,
    },
    pivotSettings: {
      maxCellWidth: 30,
      totalsString: 'Total',
      totalsPosition: {
        value: 'AFTER',
        options: [
          { value: 'AFTER', label: 'after', title: 'Totals come after totalled items.'},
          { value: 'BEFORE', label: 'before', title: 'Totals come before totalled items.'}
        ]
      },
      hideRepeatingAxisValues: true,
      dittoMark: '〃',
      alternatingRowColors: true,
      hoverRowHighlight: true,
      hoverColumnHighlight: true,
      hoverHighlightHeaderStyle: {
        value: 'fill',
        options: [
          { value: 'fill', label: 'fill' },
          { value: 'outline', label: 'outline' }
        ]
      },
      hoverHighlightCellStyle: {
        value: 'outline',
        options: [
          { value: 'fill', label: 'fill' },
          { value: 'outline', label: 'outline' }
        ]
      }
    },
    exportUi: {
      exportTitleTemplate: '${cells-items} from ${datasource} with ${rows-items} on rows and ${columns-items} on columns',
      // radio
      exportResultShapePivot: true,
      exportResultShapeTable: false,
      // radio
      exportDestinationFile: false,
      exportDestinationClipboard: true,
      // radio
      exportDelimited: true,
      exportJson: false,
      exportParquet: false,
      exportSql: false,
      exportXlsx: false,
      // options for delimited
      exportDelimitedCompression: {
        value: 'UNCOMPRESSED'
      },
      exportDelimitedIncludeHeaders: true,
      exportDelimitedDateFormat: '%x',
      exportDelimitedTimestampFormat: '%c',
      exportDelimitedNullString: '',
      exportDelimitedColumnDelimiter: '\t',
      exportDelimitedQuote: '"',
      exportDelimitedEscape: '"',
      // options for json
      exportJsonCompression: {
        value: 'UNCOMPRESSED'
      },
      exportJsonDateFormat: '%x',
      exportJsonTimestampFormat: '%c',
      // true for array, false for newline
      exportJsonRowDelimiter: {
        value: "true"
      },
      exportSqlKeywordLettercase: {
        value: 'upperCase'
      },
      exportParquetCompression: {
        value: 'SNAPPY'
      },
      exportParquetVersion: {
        value: 'V1'
      },
      exportParquetCompressionLevel: 3,
      exportParquetRowGroupSize: 122880,
      exportParquetRowGroupSizeBytes: 1024*122880,
      exportSqlAlwaysQuoteIdentifiers: true,
      exportSqlCommaStyle: {
        value: 'newlineBefore'
      },
      exportXlsxIncludeHeaders: true,
      exportXlsxSheet: '',
      exportXlsxSheetRowLimit: 1048576,
      exportQueryEncoding: {
        value: 'JSON'
      },
      exportQueryIndentation: 2
    },
    filterDialogSettings: {
      filterSearchApplyAll: false,
      filterSearchAutoWildcards: true,
      filterSearchCaseSensitive: false
    },
    attributeSettings:{
      revealAttributesUsedInQuery: true
    },
    themeSettings: {
      themes: {
        options: [
          {
            value: {
              "--huey-text-font-family": "system-ui",
              "--huey-text-font-size": "10pt",
              "--huey-mono-font-family": "monospace",
              "--huey-foreground-color": "rgb(50,50,50)",
              "--huey-highlight-color": "white",
              "--huey-placeholder-color": "rgb(180,180,180)",
              "--huey-light-background-color": "rgb(255,255,255)",
              "--huey-medium-background-color": "rgb(245,245,245)",
              "--huey-dark-background-color": "rgb(210,210,210)",
              "--huey-highlight-background-color": "rgb(050, 150, 255)",
              "--huey-alternating-rows-brightness": "99%",
              "--huey-light-border-color": "rgb(222,222,222)",
              "--huey-dark-border-color": "rgb(175,175,175)",
              "--huey-darkest-border-color": "rgb(100,100,100)",
              "--huey-icon-color-subtle": "rgb(185,185,185)",
              "--huey-icon-color": "rgb(50,50,50)",
              "--huey-icon-color-highlight": "rgb(0,0,0)"
            },
            label: "Default"
          },
          {
            value: {
              "--huey-text-font-family": "system-ui",
              "--huey-text-font-size": "10pt",
              "--huey-mono-font-family": "monospace",
              "--huey-foreground-color": "rgb(30,144,255)", // Dodger Blue
              "--huey-highlight-color": "white",
              "--huey-placeholder-color": "rgb(173,216,230)", // Light Blue
              "--huey-light-background-color": "rgb(240,248,255)", // Alice Blue
              "--huey-medium-background-color": "rgb(224,255,255)", // Light Cyan
              "--huey-dark-background-color": "rgb(175,238,238)", // Pale Turquoise
              "--huey-highlight-background-color": "rgb(050, 150, 255)",
              "--huey-alternating-rows-brightness": "98%",
              "--huey-light-border-color": "rgb(176,224,230)", // Powder Blue
              "--huey-dark-border-color": "rgb(135,206,250)", // Light Sky Blue
              "--huey-darkest-border-color": "rgb(30,144,255)",
              "--huey-icon-color-subtle": "rgb(173,216,230)", // Light Blue
              "--huey-icon-color": "rgb(30,144,255)", // Dodger Blue
              "--huey-icon-color-highlight": "rgb(0,191,255)" // Deep Sky Blue
            },
            label: "Mint"
          },
          {
            value: {
              "--huey-text-font-family": "system-ui",
              "--huey-text-font-size": "10pt",
              "--huey-mono-font-family": "monospace",
              "--huey-foreground-color": "rgb(70,130,180)", // Steel Blue
              "--huey-highlight-color": "white",
              "--huey-placeholder-color": "rgb(176,196,222)", // Light Steel Blue
              "--huey-light-background-color": "rgb(245,245,255)", // Lavender
              "--huey-medium-background-color": "rgb(230,230,250)", // Lavender Blue
              "--huey-dark-background-color": "rgb(173,216,230)", // Light Blue
              "--huey-highlight-background-color": "rgb(050, 150, 255)",
              "--huey-alternating-rows-brightness": "98%",
              "--huey-light-border-color": "rgb(200,220,240)", // Light Sky Blue
              "--huey-dark-border-color": "rgb(135,206,235)", // Sky Blue
              "--huey-darkest-border-color": "rgb(70,130,180)",
              "--huey-icon-color-subtle": "rgb(176,196,222)", // Light Steel Blue
              "--huey-icon-color": "rgb(70,130,180)", // Steel Blue
              "--huey-icon-color-highlight": "rgb(65,105,225)" // Royal Blue
            },
            label: "Lila"
          },
          {
            value: {
              "--huey-text-font-family": "system-ui",
              "--huey-text-font-size": "10pt",
              "--huey-mono-font-family": "monospace",
              "--huey-foreground-color": "#000000",
              "--huey-highlight-color": "white",
              "--huey-placeholder-color": "#A9A9A9",
              "--huey-light-background-color": "#F0E68C",
              "--huey-medium-background-color": "#A7D3A4",
              "--huey-dark-background-color": "#5B8266",
              "--huey-highlight-background-color": "rgb(050, 150, 255)",
              "--huey-alternating-rows-brightness": "98%",
              "--huey-light-border-color": "#A5B479",
              "--huey-dark-border-color": "#334D56",
              "--huey-darkest-border-color": "#000000",
              "--huey-icon-color-subtle": "#B4AA50",
              "--huey-icon-color": "#8B4513",
              "--huey-icon-color-highlight": "#FFFFFF"
            },
            label: "Mallard"
          },
          {
            value: {
              "--huey-text-font-family": "system-ui",
              "--huey-text-font-size": "10pt",
              "--huey-mono-font-family": "monospace",
              "--huey-foreground-color": "black",
              "--huey-highlight-color": "white",
              "--huey-placeholder-color": "#A9A9A9",
              "--huey-light-background-color": "#D5D5D5",
              "--huey-medium-background-color": "#D2B48C",
              "--huey-dark-background-color": "#008080",
              "--huey-highlight-background-color": "rgb(050, 150, 255)",
              "--huey-alternating-rows-brightness": "98%",
              "--huey-light-border-color": "#8B4513",
              "--huey-dark-border-color": "#2F4F4F",
              "--huey-darkest-border-color": "black",
              "--huey-icon-color-subtle": "#50AEbA",
              "--huey-icon-color": "#FFFFFF",
              "--huey-icon-color-highlight": "#8B4513"
            },
            label: "Teal"
          },
          {
            value: {
              "--huey-text-font-family": "system-ui",
              "--huey-text-font-size": "10pt",
              "--huey-mono-font-family": "monospace",
              "--huey-foreground-color": "rgb(36,36,74)",
              "--huey-highlight-color": "white",
              "--huey-placeholder-color": "rgb(180,180,180)",
              "--huey-light-background-color": "rgb(182,187,229)",
              "--huey-medium-background-color": "rgb(108,115,183)",
              "--huey-dark-background-color": "rgb(67,71,119)",
              "--huey-highlight-background-color": "rgb(050, 150, 255)",
              "--huey-alternating-rows-brightness": "98%",
              "--huey-light-border-color": "rgb(99,46,64)",
              "--huey-dark-border-color": "rgb(42,34,55)",
              "--huey-darkest-border-color": "rgb(36,36,74)",
              "--huey-icon-color-subtle": "rgb(67,21,21)",
              "--huey-icon-color": "rgb(36,36,74)",
              "--huey-icon-color-highlight": "rgb(255,243,255)"
            },
            label: "Whio"
          },
          {
            value: {
              "--huey-text-font-family": "system-ui",
              "--huey-text-font-size": "10pt",
              "--huey-mono-font-family": "monospace",
              "--huey-foreground-color": "rgb(220, 220, 220)",
              "--huey-highlight-color": "white",
              "--huey-placeholder-color": "rgb(100, 100, 100)",
              "--huey-light-background-color": "rgb(30, 30, 30)",
              "--huey-medium-background-color": "rgb(50, 50, 50)",
              "--huey-dark-background-color": "rgb(110, 110, 110)",
              "--huey-highlight-background-color": "rgb(050, 150, 255)",
              "--huey-alternating-rows-brightness": "97%",
              "--huey-light-border-color": "rgb(80, 80, 80)",
              "--huey-dark-border-color": "rgb(110, 110, 110)",
              "--huey-darkest-border-color": "rgb(220, 220, 220)",
              "--huey-icon-color-subtle": "rgb(150, 150, 150)",
              "--huey-icon-color": "rgb(220, 220, 220)",
              "--huey-icon-color-highlight": "rgb(255, 255, 255)"
            },
            label: "Dark Mode"
          }
        ],
        value: {
          "--huey-text-font-family": "system-ui",
          "--huey-text-font-size": "10pt",
          "--huey-mono-font-family": "monospace",
          "--huey-foreground-color": "rgb(50,50,50)",
          "--huey-highlight-color": "white",
          "--huey-placeholder-color": "rgb(180,180,180)",
          "--huey-light-background-color": "rgb(255,255,255)",
          "--huey-medium-background-color": "rgb(245,245,245)",
          "--huey-dark-background-color": "rgb(210,210,210)",
          "--huey-highlight-background-color": "rgb(050, 150, 255)",
          "--huey-alternating-rows-brightness": "99%",
          "--huey-light-border-color": "rgb(222,222,222)",
          "--huey-dark-border-color": "rgb(175,175,175)",
          "--huey-darkest-border-color": "rgb(100,100,100)",
          "--huey-icon-color-subtle": "rgb(185,185,185)",
          "--huey-icon-color": "rgb(50,50,50)",
          "--huey-icon-color-highlight": "rgb(0,0,0)"
        }
      }
    }
  };

  #settings = undefined;

  constructor(id){
    super('change');
    this.#id = id;
    this.#loadFromLocalStorage();
    this.#initDialog();

    window.addEventListener('beforeunload', event => this.#storeToLocalStorage( event ) );
  }

  #getSettings(path){
    const settings = this.#settings;
    if (typeof path === 'string'){
      path = [path];
    }
    if (!(path instanceof Array)) {
      throw new Error('Invalid path');
    }
    let value = settings;
    for (let i = 0; i < path.length; i++) {
      const pathElement = path[i];
      value = value[pathElement];
      if (value === undefined){
        return undefined;
      }
    }
    return value;
  }

  // return a safe copy of a setting (one that can be abused by the receiver without messing up the actual settings)
  getSettings(path){
    let value = this.#getSettings(path);
    if (typeof value === 'object'){
      value = Object.assign({}, value);
    }
    return value;
  }

  assignSettings(path, value){
    function deepAssign(target, source){
      for (let property in source){
        const sourceValue = source[property];
        if (typeof sourceValue === 'object') {
          deepAssign(target[property], sourceValue);
        }
        else {
          target[property] = sourceValue;
        }
      }
    }

    if (typeof path === 'string'){
      path = [path];
    }
    if (!(path instanceof Array)) {
      throw new Error('Invalid path');
    }

    const property = path.pop();
    const settings = this.#getSettings(path);

    if (value === null || value === undefined){
      settings[property] = value;
    }
    else {
      const currentValue = settings[property];
      switch (typeof(currentValue)) {
        case 'object':
          if (currentValue === null){
            // fallthrough
          }
          else {
            deepAssign(currentValue, value);
            break;
          }
        case 'undefined':
        case 'string':
        case 'number':
        case 'boolean':
        case 'bigint':
          settings[property] = value;
      }
    }

    this.#storeToLocalStorage();
  }

  #getDialog(){
    const settingsDialog = byId(this.#id);
    return settingsDialog;
  }

  #initDialog(){
    const settingsDialog = this.#getDialog();

    byId('settingsDialogOkButton').addEventListener('click', event => {
      event.cancelBubble = true;
      this.#updateSettingsFromDialog();
      this.#storeToLocalStorage();
    });

    byId('settingsDialogCancelButton').addEventListener('click', event => {
      event.cancelBubble = true;
    });

    byId('settingsDialogResetButton').addEventListener('click', event => {
      this.#resetSettings();
      this.fireEvent('change', this);
    });

    byId('settingsButton').addEventListener('click', event => this.#updateDialogFromSettings() );
    this.#updateDialogFromSettings();
  }

  #resetSettings(){
    this.#settings = Settings.#settingsTemplate;
    this.#storeToLocalStorage();
    this.#updateDialogFromSettings();
  }

  #updateSettingsFromDialog(){
    this.#synchronize('settings');
  }

  #updateDialogFromSettings(){
    this.#synchronize('dialog');
  }

  #synchronize(settingsOrDialog){
    const dialog = this.#getDialog();
    const settings = this.#settings;
    Settings.synchronize(dialog, settings, settingsOrDialog);
    if (settingsOrDialog === 'settings') {
      const settingsCopy = Object.assign({}, settings);
      this.#examineChangesAndSendEvent(settingsCopy);
    }
  }

  static synchronize(dialog, settings, settingsOrDialog){
    const settingsCopy = Object.assign({}, settings);
    for (let sectionName in settings) {
      const section = settings[sectionName];
      for (let property in section) {
        const control = byId(property);
        if (!control){
          continue;
        }
        if (
          settingsOrDialog === 'settings' && 
          typeof control.checkValidity === 'function' && 
          !control.checkValidity()
        ){
          console.error(`Settings persistence issue: ${control.nodeName} for property ${property} in section ${sectionName} has invalid value.`);
          continue;
        }
        switch (control.nodeName){
          case 'INPUT':
            Settings.#synchronizeInput(settingsOrDialog, section, property, control);
            break;
          case 'SELECT':
            Settings.#synchronizeSelect(settingsOrDialog, section, property, control);
            break;
          default:
            break;
        }
      }
    }
  }

  #examineChangesAndSendEvent(oldSettings){
    // TODO:
    // figure out exactly what changed and prepare a change reccord
    // send the change record along with the change event.

    this.fireEvent('change', this);
  }

  static #synchronizeInput(settingsOrDialog, settings, property, control){
    let valueProperty = 'value';
    let defaultValueGetter, defaultValueSetter;
    switch (control.type) {
      case 'radio':
      case 'checkbox':
        valueProperty = 'checked';
        break;
      case 'text':
        break;
      case 'number':
        defaultValueGetter = function(control){
          const num = parseFloat(control.value, 10); 
          return isNaN(num) ? undefined : num;
        }
        break;
      default:
        console.error(`Don't know how to get value from INPUT of type ${control.type}, defaulting to "value".`);
        break;
    }

    let value;
    switch (settingsOrDialog){
      case 'settings':
        if (control.validityState && control.valid === false){
          break;
        }
        let valueGetter = control.getAttribute('data-value-getter');
        if (valueGetter){
          valueGetter = eval(valueGetter);
          value = valueGetter.call(null, control, this);
        }
        else
        if (defaultValueGetter) {
          value = defaultValueGetter.call(null, control, this);
        }
        else {
           value = control[valueProperty];
        }
        settings[property] = value;
        break;
      case 'dialog':
        value = settings[property];
        let valueSetter = control.getAttribute('data-value-setter');
        if (valueSetter){
          valueSetter = eval(valueSetter);
          valueSetter.call(null, control, value, this);
        }
        else
        if (defaultValueSetter) {
          value = defaultValueSetter.call(null, control, value, this);
        }
        else {
          control[valueProperty] = value;
        }
        break;
    }
  }

  static #synchronizeSelect(settingsOrDialog, settings, property, control){
    const optionsFromControl = control.options;
    let optionsFromSettings = settings[property].options;
    let index = 0;
    const numOptions = optionsFromSettings ? optionsFromSettings.length : optionsFromControl.length;
    const exists = {};
    switch (settingsOrDialog) {
      case 'settings':
        let valueGetter = control.getAttribute('data-value-getter');
        if (valueGetter){
          valueGetter = eval(valueGetter);
        }

        if (optionsFromControl) {
          optionsFromSettings = [];
          for (; index < numOptions; index++){
            const optionFromControl = optionsFromControl[index];
            let value = optionFromControl.value;
            if (exists[value]) {
              continue;
            }
            exists[value] = true;
            const label = optionFromControl.label || value;
            if (valueGetter){
              value = valueGetter.call(null, optionFromControl, this);
            }
            optionsFromSettings.push({value: value, label: label});
          }
          settings[property].options = optionsFromSettings;
        }
        
        if (valueGetter) {
          settings[property].value = valueGetter.call(null, control, this);
        }
        else {
          settings[property].value = control.value;
        }
        break;
      case 'dialog':
        const valueFromSettings = settings[property].value;

        let valueSetter = control.getAttribute('data-value-setter');
        if (valueSetter){
          valueSetter = eval(valueSetter);
        }

        if (optionsFromSettings) {
          control.options.length = 0;
          for (; index < numOptions; index++){
            const optionFromSettings = optionsFromSettings[index];
            let value = optionFromSettings.value;

            const label = optionFromSettings.label || value;
            const title = optionFromSettings.title || label;
            const option = createEl('option', {
              label: label,
              title: title
            }, label);

            if (valueSetter) {
              valueSetter.call(null, option, value, this);
            }
            else {
              option.value = value;
            }

            if (exists[option.value]) {
              continue;
            }
            else {
              exists[option.value] = true;
            }

            control.appendChild(option);
          }
        }

        if (valueSetter) {
          valueSetter.call(null, control, valueFromSettings, this);
        }
        else {
          control.value = valueFromSettings;
        }

        break;
    }
  }

  #init(settings){
    if (settings.localeSettings.useDefaultLocale) {
      settings.localeSettings.locale = navigator.languages;
    }
    this.#settings = settings;
  }

  #updateDataFromTemplate(data, template){
    //harmonize data retrieved from storage with the template.
    //goal is "upgrade" the data so that all new features in the template are added,
    //but without destroying any of the data, ever.
    if (data === null) {
      data = {};
    }
    if (template === null) {
      template = {};
    }

    //make some copies to work on so we don't mess up the originals in case something goes wrong in this method.
    data = Object.assign({}, data);
    template = Object.assign({}, template);

    //now, copy stuff from data to the template

    function copyData(source, target){
      const keys = Object.keys(source);
      keys.forEach(propertyName => {
        const sourceValue = source[propertyName];
        let targetValue = target[propertyName];
        if (targetValue === undefined){
          //target either does not have this key at all, or it is null or the empty string (which we deem safe to overwrite)
          //so we create it and simply assign the value.
          if (typeof sourceValue === "object" && sourceValue !== null) {
            // object is non-null reference type, we can use Object.assign.
            // first, instantiate a new value of the right reference type
            targetValue = sourceValue instanceof Array ? [] : {};

            // then, do the deep assignment
            Object.assign(targetValue, sourceValue);
          }
          else {
            //value is either null or not a reference type - safe to simply assign.
            targetValue = sourceValue;
          }

          //do the actual assignment to the missing key.
          target[propertyName] = targetValue;
        }
        else 
        if (sourceValue === null) {
          // we won't overwrite with null from template.
        }
        else 
        if (typeof targetValue === 'object' && targetValue.constructor === sourceValue.constructor){
          // only if the sourceValue is not null, and both targetValue and sourceValue are reference types, copy the contents.
          if (sourceValue.value && sourceValue.options === undefined && targetValue.value && targetValue.options !== undefined) {
            delete targetValue.options;
          }
          copyData(sourceValue, targetValue);
        }
        else 
        if (typeof sourceValue !== typeof targetValue){
          console.error('Property ' + propertyName + ' exists in source and target but have different types (' + (typeof sourceValue) + ';' + (typeof targetValue) +')');
        }
        else {
          //target has this property, and has a value. we do not overwrite the exiting value
        }
      });
    }
    
    copyData(template, data);
    return data;
  }

  #loadFromLocalStorage(){
    const storedSettingsJSON = localStorage.getItem(Settings.localStorageKey);
    const storedSettings = JSON.parse(storedSettingsJSON);
    const settingsTemplate = Settings.#settingsTemplate;
    const settings = this.#updateDataFromTemplate(storedSettings, settingsTemplate);
    this.#init(settings);
  }

  #storeToLocalStorage(){
    const settings = this.#settings;
    const settingsJSON = JSON.stringify(settings);
    localStorage.setItem(Settings.localStorageKey, settingsJSON);
  }
}
const settings = new Settings('settingsDialog');