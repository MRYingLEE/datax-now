import { IRenderMime } from '@jupyterlab/rendermime-interfaces';
import { Widget } from '@lumino/widgets';
/**
 * A widget that embeds pivot explorer's data exploration interface.
 */
export declare class PivotExplorerWidget extends Widget implements IRenderMime.IRenderer {
    /**
     * Construct a new output widget.
     */
    constructor(options: IRenderMime.IRendererOptions);
    private _initializeFrame;
    /**
     * Send the current data file to pivot explorer for analysis.
     */
    renderModel(model: IRenderMime.IMimeModel): Promise<void>;
    dispose(): void;
    private _sendPendingFile;
    private _showError;
    private _frame;
    private _messageHandler;
    private _pendingFile;
    private _ready;
    private _requestId;
    private _status;
    private _mimeType;
}
/**
 * A MIME renderer factory for data files supported by pivot explorer.
 */
export declare const rendererFactory: IRenderMime.IRendererFactory;
/**
 * Extension definition.
 */
declare const extension: IRenderMime.IExtension;
export default extension;
